package com.gamebooster.pro

import org.junit.Assert.assertEquals
import org.junit.Test

class BasicTest {
    @Test
    fun versionNameIsExpectedForInitialMvp() {
        val versionName = "1.0.0"
        assertEquals("1.0.0", versionName)
    }
}
