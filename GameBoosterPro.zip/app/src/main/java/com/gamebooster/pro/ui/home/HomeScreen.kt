package com.gamebooster.pro.ui.home

import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

@Composable
fun HomeScreen(onRequestShizukuPermission: () -> Unit) {
    var shizukuState by remember { mutableStateOf(readShizukuState()) }

    LaunchedEffect(Unit) {
        while (true) {
            shizukuState = readShizukuState()
            kotlinx.coroutines.delay(1200)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "GAME BOOSTER PRO",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "لوحة الألعاب",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            "أدوات لعب واضحة الصلاحيات، بدون Root مدمج أو مراقبة خفية.",
            style = MaterialTheme.typography.bodyMedium
        )

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Security, contentDescription = null)
                Text("تكامل Shizuku", style = MaterialTheme.typography.titleLarge)
                Text("الحالة: $shizukuState")
                Text(
                    "Shizuku لا يمنح التطبيق صلاحيات غير محدودة. الوظائف المتاحة تعتمد " +
                        "على هوية الخدمة (ADB أو Root) وعلى ما يسمح به Android."
                )
                Button(
                    onClick = {
                        onRequestShizukuPermission()
                        shizukuState = readShizukuState()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("طلب صلاحية Shizuku")
                }
                OutlinedButton(
                    onClick = { shizukuState = readShizukuState() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("تحديث الحالة")
                }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Gamepad, contentDescription = null)
                Text("مكتبة الألعاب", style = MaterialTheme.typography.titleLarge)
                Text("ستُضاف في المرحلة التالية مع اكتشاف التطبيقات وإضافتها يدويًا.")
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.BatteryChargingFull, contentDescription = null)
                Text("أدوات الأداء", style = MaterialTheme.typography.titleLarge)
                Text(
                    "لا يمكن ضمان رفع FPS أو خفض Ping من خلال تبديل إعداد محلي. " +
                        "سنضيف قراءات حقيقية وبدائل نظامية فقط."
                )
            }
        }
    }
}

private fun readShizukuState(): String {
    return try {
        when {
            !Shizuku.pingBinder() -> "Shizuku غير متصل؛ شغّله من تطبيق Shizuku"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                "متصل والصلاحية ممنوحة"
            else -> "متصل، لكن صلاحية التطبيق غير ممنوحة"
        }
    } catch (_: Exception) {
        "تعذّر قراءة الحالة"
    }
}
