package com.gamebooster.pro

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GameBoosterApp : Application()
