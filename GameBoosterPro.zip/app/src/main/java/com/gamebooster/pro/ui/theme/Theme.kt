package com.gamebooster.pro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9BA8FF),
    secondary = Color(0xFF80CBC4),
    background = Color(0xFF101116),
    surface = Color(0xFF1A1C24)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF536DFE),
    secondary = Color(0xFF008F83),
    background = Color(0xFFF5F6FA),
    surface = Color.White
)

@Composable
fun GameBoosterTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
