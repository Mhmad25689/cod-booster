package com.gamebooster.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import com.gamebooster.pro.ui.home.HomeScreen
import com.gamebooster.pro.ui.theme.GameBoosterTheme
import dagger.hilt.android.AndroidEntryPoint
import rikka.shizuku.Shizuku

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val requestCode = 4107

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { code, grantResult ->
            if (code == requestCode) {
                // HomeScreen refreshes its status when the Activity resumes.
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        setContent {
            GameBoosterTheme {
                Surface(
                    modifier = androidx.compose.ui.Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HomeScreen(
                        onRequestShizukuPermission = {
                            when {
                                !Shizuku.pingBinder() -> {
                                    // User must start Shizuku from its own app first.
                                }
                                Shizuku.checkSelfPermission() ==
                                    android.content.pm.PackageManager.PERMISSION_GRANTED -> {
                                    // Permission already granted.
                                }
                                else -> Shizuku.requestPermission(requestCode)
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}
