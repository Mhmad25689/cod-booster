package com.daraa.codbooster

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.util.TypedValue
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.abs

class FloatingBoosterService : Service() {

    private lateinit var windowManager: WindowManager
    private var miniCapsuleView: LinearLayout? = null
    private var miniFpsText: TextView? = null
    private var miniDotBg: GradientDrawable? = null

    private var hudCardView: View? = null
    private var crosshairView: CrosshairView? = null
    private var touchCurtainView: View? = null

    private var hudPingText: TextView? = null
    private var hudTempText: TextView? = null
    private var hudRamText: TextView? = null
    private var hudFpsText: TextView? = null
    private var crosshairBar: LinearLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var isCrosshairShown = false
    private var isDndEnabled = false
    private var isDiabloModeOn = true
    private var isHitRegOn = true
    private var currentPing = 84

    private var windowStartNanos = 0L
    private var prevFrameNanos = 0L
    private var renderedFrames = 0
    private var jankFrames = 0
    private var currentRealFps = 60
    private var lastDisplayedFps = -1

    private val vsyncFpsCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isRunning) return
            if (windowStartNanos == 0L) {
                windowStartNanos = frameTimeNanos
                prevFrameNanos = frameTimeNanos
            } else {
                val frameDeltaNs = frameTimeNanos - prevFrameNanos
                prevFrameNanos = frameTimeNanos
                renderedFrames++
                if (frameDeltaNs > 26_000_000L) {
                    val missed = ((frameDeltaNs / 16_666_667L).toInt() - 1).coerceIn(1, 5)
                    jankFrames += missed
                }

                val elapsedNs = frameTimeNanos - windowStartNanos
                if (elapsedNs >= 1_000_000_000L) {
                    val rawFps = ((renderedFrames * 1_000_000_000L) / elapsedNs).toInt()
                    val effectiveFps = (rawFps - (jankFrames / 2)).coerceIn(15, 120)
                    currentRealFps = effectiveFps
                    renderedFrames = 0
                    jankFrames = 0
                    windowStartNanos = frameTimeNanos

                    if (currentRealFps != lastDisplayedFps) {
                        lastDisplayedFps = currentRealFps
                        updateMiniFpsCapsule()
                        hudFpsText?.text = "$currentRealFps FPS"
                    }
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        NetPingHelper.enableUltraNetworkAndHitRegEngine(this)
        createSleekMiniCapsule()
        Choreographer.getInstance().postFrameCallback(vsyncFpsCallback)
        startTelemetryLoop()
    }

    private fun startForegroundNotification() {
        val channelId = "game_booster_v4_hud"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "معزز الالعاب - Shizuku X-Mode",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "معزز الألعاب الفائق يعمل بأقل استهلاك رام"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val shizukuStatus = if (ShizukuShellEngine.hasShizukuPermission()) "وضع Shizuku الخارق نشط 🔥" else "وضع الأداء الأقصى نشط ⚡"
        val notification = builder
            .setContentTitle("معزز الالعاب ($shizukuStatus)")
            .setContentText("مانع الدمج الوهمي + مسرع Mali GPU قيد التشغيل")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(404, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(404, notification)
        }
    }

    private fun createSleekMiniCapsule() {
        val capsuleBg = GradientDrawable().apply {
            setColor(Color.parseColor("#D90B0F19"))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#6600F0FF"))
        }

        val capsule = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = capsuleBg
            setLayerType(View.LAYER_TYPE_NONE, null)
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }

        val dotDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#10B981"))
        }
        miniDotBg = dotDrawable

        val dot = View(this).apply {
            background = dotDrawable
            layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                setMargins(0, 0, dp(6), 0)
            }
        }

        val text = TextView(this).apply {
            text = "60 FPS"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
        }
        miniFpsText = text

        capsule.addView(dot)
        capsule.addView(text)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(42)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isTap = false

        capsule.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    isTap = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        isTap = false
                    }
                    params.x = startX + dx
                    params.y = startY + dy
                    try { windowManager.updateViewLayout(capsule, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isTap) {
                        toggleCompactGameTurboHud()
                    }
                    true
                }
                else -> false
            }
        }

        miniCapsuleView = capsule
        windowManager.addView(capsule, params)
    }

    private fun updateMiniFpsCapsule() {
        miniFpsText?.text = "$currentRealFps FPS"
        val colorHex = when {
            currentRealFps >= 54 -> "#10B981"
            currentRealFps >= 40 -> "#F59E0B"
            else -> "#EF4444"
        }
        miniDotBg?.setColor(Color.parseColor(colorHex))
    }

    private fun toggleCompactGameTurboHud() {
        if (hudCardView != null) {
            closeCompactHud()
            return
        }

        val mainBg = GradientDrawable().apply {
            setColor(Color.parseColor("#EB0D121F"))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#4D00F0FF"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = mainBg
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(6))
        }

        val shizukuTag = if (ShizukuShellEngine.hasShizukuPermission()) "🔥 SHIZUKU DIABLO" else "⚡ معزز الالعاب PRO"
        val titleTv = TextView(this).apply {
            text = shizukuTag
            setTextColor(Color.parseColor("#00F0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#26FFFFFF"))
            cornerRadius = dp(10).toFloat()
        }
        val closeSmallBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.CENTER
            background = closeBtnBg
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
            setOnClickListener { closeCompactHud() }
        }

        topHeader.addView(titleTv)
        topHeader.addView(closeSmallBtn)
        root.addView(topHeader)

        val metricsStripBg = GradientDrawable().apply {
            setColor(Color.parseColor("#182032"))
            cornerRadius = dp(10).toFloat()
        }
        val metricsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = metricsStripBg
            setPadding(dp(6), dp(6), dp(6), dp(6))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 0, dp(8))
            layoutParams = lp
        }

        hudFpsText = createMetricText("${currentRealFps} FPS", "#10B981")
        hudPingText = createMetricText("بنغ ${currentPing}ms", "#00F0FF")
        hudTempText = createMetricText(getBatteryTempStr(), "#F59E0B")
        hudRamText = createMetricText(getAvailRamShortStr(), "#E2E8F0")

        metricsRow.addView(hudFpsText)
        metricsRow.addView(createDividerDot())
        metricsRow.addView(hudPingText)
        metricsRow.addView(createDividerDot())
        metricsRow.addView(hudTempText)
        metricsRow.addView(createDividerDot())
        metricsRow.addView(hudRamText)
        root.addView(metricsRow)

        val gridRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 3f
        }
        val gridRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 3f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, dp(6), 0, 0)
            layoutParams = lp
        }

        gridRow1.addView(createCompactTile("🔥", "Diablo GPU", isDiabloModeOn, false) { tileBg ->
            thread {
                val freed = NetPingHelper.optimizeGpuAndRam(this)
                isDiabloModeOn = true
                handler.post {
                    updateTileStyle(tileBg, true)
                    hudRamText?.text = getAvailRamShortStr()
                    val msg = if (ShizukuShellEngine.hasShizukuPermission()) {
                        "🔥 تم تفعيل وضع Shizuku Diablo وإيقاف خنق GOS وتحرير $freed MB!"
                    } else {
                        "⚡ تم تحرير $freed MB وتفريغ مسار Mali GPU!"
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
        })

        gridRow1.addView(createCompactTile("🎯", "التصويب", isCrosshairShown, false) { tileBg ->
            toggleCrosshair()
            updateTileStyle(tileBg, isCrosshairShown)
            crosshairBar?.visibility = if (isCrosshairShown) View.VISIBLE else View.GONE
        })

        gridRow1.addView(createCompactTile("💥", "مانع الدمج الوهمي", isHitRegOn, false) { tileBg ->
            isHitRegOn = true
            updateTileStyle(tileBg, true)
            NetPingHelper.enableUltraNetworkAndHitRegEngine(this)
            thread {
                val p = NetPingHelper.measureTrueGamePing(0)
                currentPing = p
                handler.post {
                    updateHudPingText()
                    Toast.makeText(this, "⚡ مسار الطلقات الفوري نشط! بنغ اللعبة: ${p}ms", Toast.LENGTH_SHORT).show()
                }
            }
        })

        gridRow2.addView(createCompactTile("🔒", "قفل اللمس", false, false) { _ ->
            closeCompactHud()
            showSamsungStyleTouchCurtain()
        })

        gridRow2.addView(createCompactTile("🔕", "عدم إزعاج", isDndEnabled, false) { tileBg ->
            toggleDndMode()
            updateTileStyle(tileBg, isDndEnabled)
        })

        gridRow2.addView(createCompactTile("🛑", "إيقاف كلي", false, true) { _ ->
            thread { ShizukuShellEngine.restoreNormalSystemState() }
            stopService(Intent(this, GuardVpnService::class.java).setAction(GuardVpnService.ACTION_STOP))
            NetPingHelper.disableUltraNetworkEngine()
            stopSelf()
        })

        root.addView(gridRow1)
        root.addView(gridRow2)

        crosshairBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = if (isCrosshairShown) View.VISIBLE else View.GONE
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, dp(8), 0, 0)
            layoutParams = lp
        }

        crosshairBar?.addView(createMiniActionChip("الشكل ┼") {
            crosshairView?.nextStyle()
        })
        crosshairBar?.addView(createMiniActionChip("اللون 🎨") {
            crosshairView?.nextColor()
        })
        crosshairBar?.addView(createMiniActionChip("الحجم ➕") {
            crosshairView?.cycleSize()
        })

        root.addView(crosshairBar)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            dp(268),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(76)
        }

        hudCardView = root
        windowManager.addView(root, params)
    }

    private fun closeCompactHud() {
        hudCardView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        hudCardView = null
    }

    private fun createMetricText(textStr: String, colorHex: String): TextView {
        return TextView(this).apply {
            text = textStr
            setTextColor(Color.parseColor(colorHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun createDividerDot(): TextView {
        return TextView(this).apply {
            text = " • "
            setTextColor(Color.parseColor("#475569"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        }
    }

    private fun createCompactTile(
        iconEmoji: String,
        label: String,
        isActive: Boolean,
        isDanger: Boolean,
        onClick: (GradientDrawable) -> Unit
    ): LinearLayout {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
        }
        if (isDanger) {
            bg.setColor(Color.parseColor("#2A1219"))
            bg.setStroke(dp(1), Color.parseColor("#7F1D1D"))
        } else {
            updateTileStyle(bg, isActive)
        }

        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(4), dp(8), dp(4), dp(8))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            layoutParams = lp
            setOnClickListener { onClick(bg) }
        }

        val iconTv = TextView(this).apply {
            text = iconEmoji
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
        }
        val labelTv = TextView(this).apply {
            text = label
            setTextColor(if (isDanger) Color.parseColor("#FCA5A5") else Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }

        tile.addView(iconTv)
        tile.addView(labelTv)
        return tile
    }

    private fun updateTileStyle(bg: GradientDrawable, active: Boolean) {
        if (active) {
            bg.setColor(Color.parseColor("#172B4D"))
            bg.setStroke(dp(1), Color.parseColor("#00F0FF"))
        } else {
            bg.setColor(Color.parseColor("#181F30"))
            bg.setStroke(dp(1), Color.parseColor("#28324B"))
        }
    }

    private fun createMiniActionChip(label: String, onClick: () -> Unit): TextView {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#1E293B"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.parseColor("#38BDF8"))
        }
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(6), dp(5), dp(6), dp(5))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun toggleCrosshair() {
        if (isCrosshairShown) {
            crosshairView?.let {
                try { windowManager.removeView(it) } catch (_: Exception) {}
            }
            crosshairView = null
            isCrosshairShown = false
            return
        }

        val chView = CrosshairView(this)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            dp(48),
            dp(48),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        crosshairView = chView
        windowManager.addView(chView, params)
        isCrosshairShown = true
    }

    private fun showSamsungStyleTouchCurtain() {
        if (touchCurtainView != null) return

        val curtain = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FC000000"))
            gravity = Gravity.CENTER
            keepScreenOn = true
        }

        val lockCardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#141A29"))
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), Color.parseColor("#334155"))
        }

        val lockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = lockCardBg
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }

        val infoTv = TextView(this).apply {
            text = "🔒 وضع حماية اللمس وتوفير الطاقة\nاللعبة تعمل بأمان في الخلفية بأقل حرارة\n\nالمس مرتين لفتح القفل"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
        }
        lockBox.addView(infoTv)
        curtain.addView(lockBox)

        var lastClick = 0L
        curtain.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastClick < 450) {
                try { windowManager.removeView(curtain) } catch (_: Exception) {}
                touchCurtainView = null
            } else {
                lastClick = now
            }
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        ).apply {
            screenBrightness = 0.01f
        }

        touchCurtainView = curtain
        windowManager.addView(curtain, params)
    }

    private fun toggleDndMode() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "يرجى تفعيل صلاحية عدم الإزعاج لمعزز الالعاب", Toast.LENGTH_LONG).show()
            val intent = Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            return
        }
        isDndEnabled = !isDndEnabled
        if (isDndEnabled) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            Toast.makeText(this, "🔕 تم كتم الإشعارات المنبثقة أثناء اللعب", Toast.LENGTH_SHORT).show()
        } else {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            Toast.makeText(this, "🔔 تم استعادة الإشعارات", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getBatteryTempStr(): String {
        val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 330) ?: 330
        return "${tenths / 10.0}°C"
    }

    private fun getAvailRamShortStr(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val availMb = mi.availMem / (1024 * 1024)
        return "رام ${availMb}M"
    }

    private fun updateHudPingText() {
        val colorHex = when {
            currentPing < 75 -> "#10B981"
            currentPing < 105 -> "#F59E0B"
            else -> "#EF4444"
        }
        hudPingText?.text = "بنغ ${currentPing}ms"
        hudPingText?.setTextColor(Color.parseColor(colorHex))
        hudTempText?.text = getBatteryTempStr()
        hudRamText?.text = getAvailRamShortStr()
    }

    private fun startTelemetryLoop() {
        isRunning = true
        val prefs = getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE)
        val task = object : Runnable {
            override fun run() {
                if (!isRunning) return
                if (hudCardView != null) {
                    thread {
                        val region = prefs.getInt("region_index", 0)
                        val p = NetPingHelper.measureTrueGamePing(region)
                        currentPing = p
                        handler.post {
                            updateHudPingText()
                        }
                    }
                }
                handler.postDelayed(this, 4000L)
            }
        }
        handler.post(task)
    }

    override fun onDestroy() {
        isRunning = false
        Choreographer.getInstance().removeFrameCallback(vsyncFpsCallback)
        handler.removeCallbacksAndMessages(null)
        NetPingHelper.disableUltraNetworkEngine()
        miniCapsuleView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        hudCardView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        crosshairView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        touchCurtainView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
