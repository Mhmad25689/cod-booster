package com.daraa.codbooster

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuShellEngine {

    private val COD_PACKAGES = listOf(
        "com.activision.callofduty.shooter",
        "com.garena.game.codm",
        "com.activision.callofduty.warzone"
    )

    // خدمات سامسونج التي تخنق المعالج الرسومي (GOS) وتطبيقات الخلفية الثقيلة
    private val SAMSUNG_THROTTLE_PACKAGES = listOf(
        "com.samsung.android.game.gos",
        "com.samsung.android.game.gametools",
        "com.samsung.android.game.gamehome",
        "com.samsung.android.scloud",
        "com.sec.android.app.samsungapps"
    )

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
    }

    fun hasShizukuPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
    }

    fun requestPermission(requestCode: Int) {
        try {
            if (isShizukuAvailable() && !hasShizukuPermission()) {
                Shizuku.requestPermission(requestCode)
            }
        } catch (_: Throwable) {}
    }

    /**
     * تنفيذ أوامر نواة أندرويد بصلاحية UID 2000 (ADB Shell) مباشرة عبر Shizuku
     */
    fun execShell(command: String): String {
        if (!hasShizukuPermission()) return ""
        var process: Process? = null
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val out = StringBuilder()
            var line: String? = reader.readLine()
            while (line != null) {
                out.append(line).append("\n")
                line = reader.readLine()
            }
            process.waitFor()
            out.toString().trim()
        } catch (_: Throwable) {
            ""
        } finally {
            try { process?.destroy() } catch (_: Throwable) {}
        }
    }

    /**
     * التفعيل الشامل لوضع RedMagic Diablo / X-Mode عبر Shizuku:
     * 1. إيقاف خنق سامسونج الحراري (Samsung GOS) الذي يضعف معالج Mali GPU
     * 2. قفل المعالج والرسوميات على وضع الأداء الأقصى (Fixed Performance Mode)
     * 3. تحجيم الرندر الهاردويري (Hardware Downscale) لإنهاء عنق الزجاجة الرسومي بنسبة 40%
     * 4. تفعيل تعريف الهاردوير الرسمي (Game Driver Opt-In)
     * 5. إيقاف إجباري حقيقي (am force-stop) لتطبيقات الخلفية الشرهة
     * 6. تفعيل الجدار الناري في النواة (Kernel Netpolicy Restrict Background) لمنع الدمج الوهمي
     */
    fun applyUltimateShizukuBoost(context: Context, downscaleRatio: String = "0.80"): Int {
        if (!hasShizukuPermission()) return 0

        val cmds = StringBuilder()

        // 1. شل حركة خادم الخنق الحراري في سامسونج (GOS) ليحصل Mali GPU على كامل طاقته
        for (gosPkg in SAMSUNG_THROTTLE_PACKAGES) {
            cmds.append("am force-stop ").append(gosPkg).append(" 2>/dev/null; ")
            cmds.append("cmd appops set ").append(gosPkg).append(" RUN_IN_BACKGROUND ignore 2>/dev/null; ")
            cmds.append("cmd appops set ").append(gosPkg).append(" RUN_ANY_IN_BACKGROUND ignore 2>/dev/null; ")
        }

        // 2. تفعيل وضع الأداء الثابت للنواة (Kernel Fixed Performance Mode)
        cmds.append("cmd power set-fixed-performance-mode-enabled true 2>/dev/null; ")
        cmds.append("cmd thermalservice override-status 0 2>/dev/null; ")

        // 3. ضبط Android 16 GameManagerService على وضع الأداء (Mode 2) مع تحجيم الرندر الهاردويري لإنهاء عنق الزجاجة
        for (codPkg in COD_PACKAGES) {
            if (downscaleRatio == "1.0") {
                cmds.append("cmd game set --mode 2 --downscale disable ").append(codPkg).append(" 2>/dev/null; ")
            } else {
                cmds.append("cmd game set --mode 2 --downscale ").append(downscaleRatio).append(" ").append(codPkg).append(" 2>/dev/null; ")
            }
            cmds.append("cmd game mode performance ").append(codPkg).append(" 2>/dev/null; ")
        }

        // 4. إجبار النظام على استخدام تعريف المعالج الرسومي الهاردويري (System Game Driver) لكود موبايل
        cmds.append("settings put global game_driver_opt_in_apps com.activision.callofduty.shooter 2>/dev/null; ")
        cmds.append("settings put global updatable_driver_production_opt_in_apps com.activision.callofduty.shooter 2>/dev/null; ")

        // 5. رفع حساسية استجابة اللمس للحد الأقصى وإلغاء أنيميشن النوافذ لتسريع الـ SurfaceFlinger
        cmds.append("settings put system pointer_speed 7 2>/dev/null; ")
        cmds.append("settings put global window_animation_scale 0.0 2>/dev/null; ")
        cmds.append("settings put global transition_animation_scale 0.0 2>/dev/null; ")
        cmds.append("settings put global animator_duration_scale 0.0 2>/dev/null; ")

        // 6. تفعيل عزل الشبكة في نواة أندرويد (Kernel Data Saver Firewall) لمنع أي تطبيق خلفي من سرقة الباندويث
        cmds.append("cmd netpolicy set restrict-background true 2>/dev/null; ")

        // 7. إيقاف إجباري حقيقي (am force-stop) لتطبيقات الخلفية غير الضرورية
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(0)
        var stoppedCount = 0
        for (app in installed) {
            val pkg = app.packageName
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                pkg != context.packageName &&
                !pkg.contains("callofduty") &&
                !pkg.contains("codm") &&
                !pkg.contains("activision") &&
                !pkg.contains("shizuku")
            ) {
                cmds.append("am force-stop ").append(pkg).append(" 2>/dev/null; ")
                stoppedCount++
            }
        }

        // 8. تفريغ الكاش والعمليات الميتة
        cmds.append("pm trim-caches 4096M 2>/dev/null; ")
        cmds.append("cmd activity kill-all 2>/dev/null; ")

        execShell(cmds.toString())
        return stoppedCount
    }

    /**
     * استعادة إعدادات النظام الطبيعية فور الانتهاء من اللعب
     */
    fun restoreNormalSystemState() {
        if (!hasShizukuPermission()) return
        val cmds = StringBuilder()
        cmds.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null; ")
        cmds.append("cmd thermalservice reset 2>/dev/null; ")
        cmds.append("cmd netpolicy set restrict-background false 2>/dev/null; ")
        cmds.append("settings put global window_animation_scale 1.0 2>/dev/null; ")
        cmds.append("settings put global transition_animation_scale 1.0 2>/dev/null; ")
        cmds.append("settings put global animator_duration_scale 1.0 2>/dev/null; ")
        execShell(cmds.toString())
    }
}
