package com.daraa.codbooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var contentFrame: FrameLayout
    private lateinit var tabBoostView: ScrollView
    private lateinit var tabGpuView: ScrollView
    private lateinit var tabHudView: ScrollView

    private lateinit var navBoostLabel: TextView
    private lateinit var navGpuLabel: TextView
    private lateinit var navHudLabel: TextView

    private lateinit var shizukuBannerTv: TextView
    private lateinit var shizukuActionBtn: TextView

    private lateinit var regionValueTv: TextView
    private lateinit var downscaleValueTv: TextView
    private lateinit var livePingGaugeTv: TextView
    private lateinit var liveJitterTv: TextView
    private lateinit var liveHitRegTv: TextView
    private lateinit var boostStatusSubTv: TextView
    private lateinit var mainBoostBtn: TextView

    private var pill4GView: TextView? = null
    private var pillAdslView: TextView? = null
    private var currentNetMode = 0

    private lateinit var gpuRamFreeTv: TextView
    private lateinit var gpuTempTv: TextView
    private val profileViews = mutableListOf<LinearLayout>()
    private var selectedGpuProfile = 0

    private val handler = Handler(Looper.getMainLooper())
    private var isBoosting = false

    private val shizukuPermListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQ) {
            runOnUiThread {
                refreshShizukuBanner()
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "🔥 تم تفعيل صلاحيات Shizuku الخارقة بنجاح!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    companion object {
        const val VPN_REQ = 2001
        const val OVERLAY_REQ = 2002
        const val SHIZUKU_REQ = 2003
        const val PREFS = "hyperboost_prefs"
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#090B10")
        window.navigationBarColor = Color.parseColor("#0E111A")

        try {
            Shizuku.addRequestPermissionResultListener(shizukuPermListener)
        } catch (_: Throwable) {}

        NetPingHelper.prewarmCodLoginAndMatchmakingServers()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#090B10"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        contentFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        tabBoostView = buildGearUpBoostTab()
        tabGpuView = buildGpuEngineTab()
        tabHudView = buildHudStudioTab()

        contentFrame.addView(tabBoostView)
        contentFrame.addView(tabGpuView)
        contentFrame.addView(tabHudView)

        root.addView(contentFrame)
        root.addView(buildBottomNavBar())

        setContentView(root)
        switchTab(0)
        refreshShizukuBanner()
        refreshLiveMetrics()
    }

    override fun onResume() {
        super.onResume()
        refreshShizukuBanner()
        refreshLiveMetrics()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermListener)
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun buildGearUpBoostTab(): ScrollView {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        currentNetMode = prefs.getInt("net_mode", 0)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#090B10"))
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
        }

        val topBar = RelativeLayout(this).apply {
            setPadding(0, 0, 0, dp(14))
        }
        val headerTitle = TextView(this).apply {
            text = "معزز الالعاب"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.CENTER_IN_PARENT)
            }
        }
        val badgeBg = GradientDrawable().apply {
            setColor(Color.parseColor("#2A1219"))
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), Color.parseColor("#F43F5E"))
        }
        val editionBadge = TextView(this).apply {
            text = "🔥 V4 Shizuku"
            setTextColor(Color.parseColor("#FB7185"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            background = badgeBg
            setPadding(dp(10), dp(4), dp(10), dp(4))
            layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.ALIGN_PARENT_LEFT)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
        }
        topBar.addView(headerTitle)
        topBar.addView(editionBadge)
        col.addView(topBar)

        // بطاقة حالة صلاحيات Shizuku (تمنح قوة تفوق معزز سامسونج و RedMagic)
        val shizukuCard = createSleekCard("#12192B", "#2563EB")
        val shizukuRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        shizukuBannerTv = TextView(this).apply {
            text = "⚡ فحص محرك Shizuku (UID 2000)..."
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(0, 0, dp(8), 0)
        }
        val shizukuBtnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#2563EB"))
            cornerRadius = dp(14).toFloat()
        }
        shizukuActionBtn = TextView(this).apply {
            text = "ربط Shizuku"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = shizukuBtnBg
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { handleShizukuButtonClick() }
        }
        shizukuRow.addView(shizukuBannerTv)
        shizukuRow.addView(shizukuActionBtn)
        shizukuCard.addView(shizukuRow)
        col.addView(shizukuCard)

        // بطاقة Call of Duty Mobile
        val codCard = createSleekCard("#141822", "#1E2536")

        val gameRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val gameIconView = ImageView(this).apply {
            setImageDrawable(loadCodIcon())
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val gameTitleTv = TextView(this).apply {
            text = "Call of Duty®: Mobile"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.DEFAULT_BOLD
        }
        boostStatusSubTv = TextView(this).apply {
            text = "إيقاف خنق GOS + مانع الدمج الوهمي + تحجيم GPU"
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(3), 0, 0)
        }
        titleCol.addView(gameTitleTv)
        titleCol.addView(boostStatusSubTv)

        val boostPillBg = GradientDrawable().apply {
            setColor(Color.parseColor("#172B4D"))
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), Color.parseColor("#2563EB"))
        }
        mainBoostBtn = TextView(this).apply {
            text = "تعزيز"
            setTextColor(Color.parseColor("#60A5FA"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = boostPillBg
            setPadding(dp(20), dp(9), dp(20), dp(9))
            setOnClickListener {
                startFullBoostSequence(launchGame = true)
            }
        }

        gameRow.addView(gameIconView)
        gameRow.addView(titleCol)
        gameRow.addView(mainBoostBtn)
        codCard.addView(gameRow)

        val divider1 = View(this).apply {
            setBackgroundColor(Color.parseColor("#1F2637"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                setMargins(0, dp(14), 0, dp(12))
            }
        }
        codCard.addView(divider1)

        val regionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { showRegionSelectorDialog() }
        }
        val regionLabelTv = TextView(this).apply {
            text = "منطقة الخادم"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val savedRegion = prefs.getInt("region_index", 0)
        regionValueTv = TextView(this).apply {
            text = "${NetPingHelper.SERVER_REGIONS[savedRegion]}  ‹"
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
        }
        regionRow.addView(regionLabelTv)
        regionRow.addView(regionValueTv)
        codCard.addView(regionRow)

        val divider2 = View(this).apply {
            setBackgroundColor(Color.parseColor("#1F2637"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                setMargins(0, dp(12), 0, dp(12))
            }
        }
        codCard.addView(divider2)

        // صف تحجيم دقة المعالج الرسومي عبر Shizuku (ميزة RedMagic Energy Cube)
        val downscaleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { showDownscaleSelectorDialog() }
        }
        val downscaleLabelTv = TextView(this).apply {
            text = "دقة رندر Mali GPU (عبر Shizuku)"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val savedDownscale = prefs.getInt("downscale_index", 0)
        downscaleValueTv = TextView(this).apply {
            text = "${NetPingHelper.getDownscaleRatioValue(savedDownscale)}x Esports  ‹"
            setTextColor(Color.parseColor("#00F0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
        }
        downscaleRow.addView(downscaleLabelTv)
        downscaleRow.addView(downscaleValueTv)
        codCard.addView(downscaleRow)

        col.addView(codCard)

        val telemetryCard = createSleekCard("#141822", "#1E2536")
        val teleHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val teleTitle = TextView(this).apply {
            text = "📡 القياس الحقيقي المطابق لعداد اللعبة (درعا)"
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val refreshBtn = TextView(this).apply {
            text = "قياس حي ↻"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { refreshLiveMetrics() }
        }
        teleHeader.addView(teleTitle)
        teleHeader.addView(refreshBtn)
        telemetryCard.addView(teleHeader)

        val metricsGrid = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }

        val box1 = createMetricBox("بنغ اللعبة الحقيقي", "-- ms", "#10B981")
        livePingGaugeTv = box1.second
        val box2 = createMetricBox("تذبذب الإشارة Jitter", "3 ms", "#38BDF8")
        liveJitterTv = box2.second
        val box3 = createMetricBox("تسجيل الطلقات", "100% فوري", "#A855F7")
        liveHitRegTv = box3.second

        metricsGrid.addView(box1.first)
        metricsGrid.addView(box2.first)
        metricsGrid.addView(box3.first)
        telemetryCard.addView(metricsGrid)
        col.addView(telemetryCard)

        val netConfigCard = createSleekCard("#141822", "#1E2536")
        val netSectionTitle = TextView(this).apply {
            text = "⚙️ محركات التعزيز الخارقة (مفعّلة افتراضياً)"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        }
        netConfigCard.addView(netSectionTitle)

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, dp(12))
            layoutParams = lp
        }

        pill4GView = createModePill("📶 4G سيريتل / MTN (MTU 1360)") {
            currentNetMode = 0
            prefs.edit().putInt("net_mode", 0).apply()
            refreshNetModePills()
        }
        pillAdslView = createModePill("🏠 راوتر ADSL منزلي (MTU 1440)") {
            currentNetMode = 1
            prefs.edit().putInt("net_mode", 1).apply()
            refreshNetModePills()
        }
        refreshNetModePills()
        modeRow.addView(pill4GView)
        modeRow.addView(pillAdslView)
        netConfigCard.addView(modeRow)

        netConfigCard.addView(createModernToggleRow(
            title = "إيقاف خنق سامسونج الحراري (Kill Samsung GOS)",
            subtitle = "تجميد خدمة GOS عبر Shizuku لمنع هبوط تردد Mali GPU أثناء الاشتباكات",
            initialState = prefs.getBoolean("kill_gos", true)
        ) { enabled ->
            prefs.edit().putBoolean("kill_gos", enabled).apply()
        })

        netConfigCard.addView(createModernToggleRow(
            title = "إزالة الدمج الوهمي (Hit-Reg UDP Priority)",
            subtitle = "وسم حزم طلقات كود موبايل بأولوية قصوى DSCP EF ومنع تقطيع الحزم",
            initialState = prefs.getBoolean("hit_reg_boost", true)
        ) { enabled ->
            prefs.edit().putBoolean("hit_reg_boost", enabled).apply()
        })

        netConfigCard.addView(createModernToggleRow(
            title = "تسريع الدخول للعبة (Fast Login Pre-Warm)",
            subtitle = "فتح مسبق لخوادم المصادقة والتحديثات لإلغاء تأخر شاشة البداية",
            initialState = prefs.getBoolean("fast_login", true)
        ) { enabled ->
            prefs.edit().putBoolean("fast_login", enabled).apply()
        })

        netConfigCard.addView(createModernToggleRow(
            title = "عزل إنترنت الخلفية بالكامل (Kernel + VPN Firewall)",
            subtitle = "قطع الإنترنت عن واتساب وفيسبوك وتيك توك أثناء اللعب لتثبيت البنغ",
            initialState = prefs.getBoolean("isolate_bg", true)
        ) { enabled ->
            prefs.edit().putBoolean("isolate_bg", enabled).apply()
        })

        netConfigCard.addView(createModernToggleRow(
            title = "وضع صفر رام (إغلاق الواجهة الخلفية عند اللعب)",
            subtitle = "تحرير كامل ذاكرة المعالج الرسومي والرام فور تشغيل اللعبة وإبقاء عداد FPS فقط",
            initialState = prefs.getBoolean("zero_ram_exit", true)
        ) { enabled ->
            prefs.edit().putBoolean("zero_ram_exit", enabled).apply()
        })

        col.addView(netConfigCard)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
        }

        val btnHudOnly = createActionButton("🎮 تشغيل عداد FPS العائم فقط", "#1E293B", "#38BDF8") {
            startFullBoostSequence(launchGame = false)
        }
        val btnStopAll = createActionButton("🛑 إيقاف المعزز واستعادة النظام", "#2A1219", "#F87171") {
            stopAllBoostServices()
        }
        actionRow.addView(btnHudOnly)
        actionRow.addView(btnStopAll)
        col.addView(actionRow)

        scroll.addView(col)
        return scroll
    }

    private fun refreshShizukuBanner() {
        if (!::shizukuBannerTv.isInitialized) return
        when {
            ShizukuShellEngine.hasShizukuPermission() -> {
                shizukuBannerTv.text = "🔥 صلاحيات Shizuku (UID 2000) مفعّلة بالكامل!
وضع Diablo Kernel + إيقاف GOS + تحجيم GPU جاهز"
                shizukuBannerTv.setTextColor(Color.parseColor("#34D399"))
                shizukuActionBtn.text = "مفعّل ✓"
            }
            ShizukuShellEngine.isShizukuAvailable() -> {
                shizukuBannerTv.text = "⚡ تطبيق Shizuku يعمل! اضغط لمنح الصلاحية وتفعيل القوة القصوى"
                shizukuBannerTv.setTextColor(Color.parseColor("#FBBF24"))
                shizukuActionBtn.text = "منح الصلاحية"
            }
            else -> {
                shizukuBannerTv.text = "💡 شغّل تطبيق Shizuku لتفعيل وضع Diablo Kernel وإيقاف خنق سامسونج GOS"
                shizukuBannerTv.setTextColor(Color.parseColor("#94A3B8"))
                shizukuActionBtn.text = "فتح Shizuku"
            }
        }
    }

    private fun handleShizukuButtonClick() {
        when {
            ShizukuShellEngine.hasShizukuPermission() -> {
                Toast.makeText(this, "🔥 صلاحيات Shizuku مفعّلة وجاهزة!", Toast.LENGTH_SHORT).show()
            }
            ShizukuShellEngine.isShizukuAvailable() -> {
                ShizukuShellEngine.requestPermission(SHIZUKU_REQ)
            }
            else -> {
                val launch = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (launch != null) {
                    startActivity(launch)
                } else {
                    Toast.makeText(this, "افتح تطبيق Shizuku وشغّل الخدمة (Start) ثم ارجع لهنا واضغط منح الصلاحية", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshNetModePills() {
        pill4GView?.let { styleModePill(it, currentNetMode == 0) }
        pillAdslView?.let { styleModePill(it, currentNetMode == 1) }
    }

    private fun buildGpuEngineTab(): ScrollView {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        selectedGpuProfile = prefs.getInt("gpu_profile", 0)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#090B10"))
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
        }

        val title = TextView(this).apply {
            text = "محرك RedMagic Diablo & Shizuku GPU"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6))
        }
        val sub = TextView(this).apply {
            text = "أقوى من معزز سامسونج: يوقف خنق GOS، ويقفل ترددات النواة، ويطبق تحجيم الرندر الهاردويري"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, 0, 0, dp(16))
        }
        col.addView(title)
        col.addView(sub)

        val hwCard = createSleekCard("#141822", "#1E2536")
        val hwRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
        }
        val ramBox = createMetricBox("الرام الحرة لـ GPU", "-- MB", "#00F0FF")
        gpuRamFreeTv = ramBox.second
        val tempBox = createMetricBox("حرارة الجهاز", "-- °C", "#10B981")
        gpuTempTv = tempBox.second
        hwRow.addView(ramBox.first)
        hwRow.addView(tempBox.first)
        hwCard.addView(hwRow)

        val flushBtn = createFullWidthButton("🔥 تفعيل وضع Diablo عبر Shizuku وتحرير الرام الآن", "#2563EB") {
            thread {
                val freed = NetPingHelper.optimizeGpuAndRam(this)
                runOnUiThread {
                    refreshLiveMetrics()
                    val msg = if (ShizukuShellEngine.hasShizukuPermission()) {
                        "🔥 تم إيقاف GOS وتجميد تطبيقات الخلفية وتحرير $freed MB عبر Shizuku!"
                    } else {
                        "⚡ تم تحرير $freed MB وتفريغ ذاكرة الفيديو المشتركة!"
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }
        }
        hwCard.addView(flushBtn)
        col.addView(hwCard)

        val profileCard = createSleekCard("#141822", "#1E2536")
        val profTitle = TextView(this).apply {
            text = "🎛️ أوضاع النواة والمعالج الرسومي (RedMagic Cube)"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        }
        profileCard.addView(profTitle)

        profileViews.clear()
        val profilesData = listOf(
            Triple("🔥 وضع Diablo الخارق (مفعّل افتراضياً - أقصى FPS)", "قفل ترددات النواة Fixed Performance + إيقاف خنق GOS + تحجيم الرندر 80% لمنع أي تقطيع", 0),
            Triple("⚖️ وضع Rise المتوازن (60 FPS ثابت)", "توازن بين سلاسة الرسوميات واستقرار حرارة Galaxy A07 في المباريات الطويلة", 1),
            Triple("❄️ وضع التبريد الفائق (منع الهبوط الحراري)", "خفض الحمل الحراري لمنع تراجع تردد المعالج في الأجواء الحارة", 2)
        )

        for ((pTitle, pDesc, idx) in profilesData) {
            val itemBg = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
            }
            val itemLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = itemBg
                setPadding(dp(12), dp(10), dp(12), dp(10))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 0, 0, dp(8))
                layoutParams = lp
                setOnClickListener {
                    selectedGpuProfile = idx
                    prefs.edit().putInt("gpu_profile", idx).apply()
                    refreshGpuProfileStyles()
                    thread { NetPingHelper.optimizeGpuAndRam(this@MainActivity) }
                    Toast.makeText(this@MainActivity, "تم تفعيل: $pTitle", Toast.LENGTH_SHORT).show()
                }
            }
            val tTv = TextView(this).apply {
                text = pTitle
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
            }
            val dTv = TextView(this).apply {
                text = pDesc
                setTextColor(Color.parseColor("#94A3B8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setPadding(0, dp(3), 0, 0)
            }
            itemLayout.addView(tTv)
            itemLayout.addView(dTv)
            profileViews.add(itemLayout)
            profileCard.addView(itemLayout)
        }
        refreshGpuProfileStyles()
        col.addView(profileCard)

        scroll.addView(col)
        return scroll
    }

    private fun refreshGpuProfileStyles() {
        for ((idx, view) in profileViews.withIndex()) {
            val bg = view.background as? GradientDrawable ?: continue
            if (idx == selectedGpuProfile) {
                bg.setColor(Color.parseColor("#172B4D"))
                bg.setStroke(dp(1), Color.parseColor("#00F0FF"))
            } else {
                bg.setColor(Color.parseColor("#10141D"))
                bg.setStroke(dp(1), Color.parseColor("#1F2637"))
            }
        }
    }

    private fun buildHudStudioTab(): ScrollView {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#090B10"))
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
        }

        val title = TextView(this).apply {
            text = "النافذة العائمة وعداد الفريمات الحقيقي"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6))
        }
        val sub = TextView(this).apply {
            text = "تعرض الكبسولة المصغرة الآن عدد الفريمات الحقيقي للعبة (FPS) بدلاً من البنغ وبصفر استهلاك للرام"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, 0, 0, dp(16))
        }
        col.addView(title)
        col.addView(sub)

        val hudInfoCard = createSleekCard("#141822", "#1E2536")
        val featuresList = listOf(
            "🟢 الكبسولة العائمة المصغرة تعرض الفريمات الحقيقية للعبة (مثلاً: 60 FPS) لحظة بلحظة",
            "🔥 زر Diablo GPU داخل اللوحة العائمة يشغل أوامر Shizuku الفورية أثناء اللعب",
            "📡 عند الضغط على الكبسولة يظهر البنغ الحقيقي المطابق لعداد كود موبايل الداخلي",
            "🎯 4 أشكال احترافية لعلامة التصويب الثابتة مع التحكم باللون والحجم",
            "🔒 ستارة قفل اللمس وتعتيم الشاشة لتبريد الجهاز وتوفير البطارية"
        )
        for (item in featuresList) {
            val tv = TextView(this).apply {
                text = item
                setTextColor(Color.parseColor("#E2E8F0"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, dp(6), 0, dp(6))
            }
            hudInfoCard.addView(tv)
        }

        hudInfoCard.addView(createFullWidthButton("🚀 تشغيل عداد FPS العائم الآن", "#10B981") {
            startFullBoostSequence(launchGame = false)
        })

        hudInfoCard.addView(createFullWidthButton("🛑 إيقاف النافذة العائمة واستعادة النظام", "#EF4444") {
            stopAllBoostServices()
        })

        col.addView(hudInfoCard)
        scroll.addView(col)
        return scroll
    }

    private fun buildBottomNavBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0E111A"))
            weightSum = 3f
            setPadding(0, dp(8), 0, dp(10))
        }

        val item0 = createNavTabItem("⚡", "تعزيز") { switchTab(0) }
        navBoostLabel = item0.second

        val item1 = createNavTabItem("🔥", "Diablo GPU") { switchTab(1) }
        navGpuLabel = item1.second

        val item2 = createNavTabItem("🎯", "عداد FPS") { switchTab(2) }
        navHudLabel = item2.second

        bar.addView(item0.first)
        bar.addView(item1.first)
        bar.addView(item2.first)
        return bar
    }

    private fun createNavTabItem(icon: String, label: String, onClick: () -> Unit): Pair<LinearLayout, TextView> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { onClick() }
        }
        val iconTv = TextView(this).apply {
            text = icon
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
        }
        val labelTv = TextView(this).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        box.addView(iconTv)
        box.addView(labelTv)
        return box to labelTv
    }

    private fun switchTab(index: Int) {
        tabBoostView.visibility = if (index == 0) View.VISIBLE else View.GONE
        tabGpuView.visibility = if (index == 1) View.VISIBLE else View.GONE
        tabHudView.visibility = if (index == 2) View.VISIBLE else View.GONE

        val activeColor = Color.parseColor("#38BDF8")
        val inactiveColor = Color.parseColor("#64748B")

        navBoostLabel.setTextColor(if (index == 0) activeColor else inactiveColor)
        navGpuLabel.setTextColor(if (index == 1) activeColor else inactiveColor)
        navHudLabel.setTextColor(if (index == 2) activeColor else inactiveColor)
    }

    private fun createSleekCard(bgHex: String, strokeHex: String): LinearLayout {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(bgHex))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor(strokeHex))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 0, dp(14))
            layoutParams = lp
        }
    }

    private fun createMetricBox(label: String, initialValue: String, valueColorHex: String): Pair<LinearLayout, TextView> {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#0E121B"))
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), Color.parseColor("#1F2637"))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(8), dp(10), dp(8), dp(10))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            layoutParams = lp
        }
        val valTv = TextView(this).apply {
            text = initialValue
            setTextColor(Color.parseColor(valueColorHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val lblTv = TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        }
        box.addView(valTv)
        box.addView(lblTv)
        return box to valTv
    }

    private fun createModePill(title: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun styleModePill(tv: TextView, selected: Boolean) {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            if (selected) {
                setColor(Color.parseColor("#172B4D"))
                setStroke(dp(1), Color.parseColor("#00F0FF"))
            } else {
                setColor(Color.parseColor("#0E121B"))
                setStroke(dp(1), Color.parseColor("#1F2637"))
            }
        }
        tv.background = bg
        tv.setTextColor(if (selected) Color.parseColor("#00F0FF") else Color.parseColor("#94A3B8"))
    }

    private fun applyTogglePillStyle(pillBtn: TextView, state: Boolean) {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            if (state) {
                setColor(Color.parseColor("#064E3B"))
                setStroke(dp(1), Color.parseColor("#10B981"))
            } else {
                setColor(Color.parseColor("#1E293B"))
                setStroke(dp(1), Color.parseColor("#475569"))
            }
        }
        pillBtn.background = bg
        pillBtn.text = if (state) "مفعّل ✓" else "متوقف"
        pillBtn.setTextColor(if (state) Color.parseColor("#34D399") else Color.parseColor("#94A3B8"))
    }

    private fun createModernToggleRow(
        title: String,
        subtitle: String,
        initialState: Boolean,
        onToggle: (Boolean) -> Unit
    ): LinearLayout {
        var state = initialState
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(0, 0, dp(10), 0)
        }
        val tTv = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val sTv = TextView(this).apply {
            text = subtitle
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(0, dp(2), 0, 0)
        }
        textCol.addView(tTv)
        textCol.addView(sTv)

        val pillBtn = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }

        applyTogglePillStyle(pillBtn, state)
        row.setOnClickListener {
            state = !state
            applyTogglePillStyle(pillBtn, state)
            onToggle(state)
        }
        row.addView(textCol)
        row.addView(pillBtn)
        return row
    }

    private fun createActionButton(title: String, bgHex: String, textHex: String, onClick: () -> Unit): TextView {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(bgHex))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.parseColor(textHex))
        }
        return TextView(this).apply {
            text = title
            setTextColor(Color.parseColor(textHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(10), dp(12), dp(10), dp(12))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun createFullWidthButton(title: String, bgHex: String, onClick: () -> Unit): TextView {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(bgHex))
            cornerRadius = dp(14).toFloat()
        }
        return TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, dp(12), 0, 0)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun loadCodIcon(): Drawable {
        val pkgs = listOf(
            "com.activision.callofduty.shooter",
            "com.garena.game.codm",
            "com.activision.callofduty.warzone"
        )
        for (pkg in pkgs) {
            try {
                return packageManager.getApplicationIcon(pkg)
            } catch (_: Exception) {}
        }
        return try {
            resources.getDrawable(R.drawable.cod_default_icon, theme)
        } catch (_: Exception) {
            resources.getDrawable(android.R.drawable.sym_def_app_icon, theme)
        }
    }

    private fun showRegionSelectorDialog() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getInt("region_index", 0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("اختر منطقة خادم Call of Duty Mobile")
            .setSingleChoiceItems(NetPingHelper.SERVER_REGIONS, current) { dialog, which ->
                prefs.edit().putInt("region_index", which).apply()
                regionValueTv.text = "${NetPingHelper.SERVER_REGIONS[which]}  ‹"
                dialog.dismiss()
                refreshLiveMetrics()
            }
            .show()
    }

    private fun showDownscaleSelectorDialog() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getInt("downscale_index", 0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("تحجيم دقة المعالج الرسومي (Shizuku GPU Scaling)")
            .setSingleChoiceItems(NetPingHelper.DOWNSCALE_MODES, current) { dialog, which ->
                prefs.edit().putInt("downscale_index", which).apply()
                downscaleValueTv.text = "${NetPingHelper.getDownscaleRatioValue(which)}x Esports  ‹"
                dialog.dismiss()
            }
            .show()
    }

    private fun refreshLiveMetrics() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val availMb = mi.availMem / (1024 * 1024)
        gpuRamFreeTv.text = "$availMb MB"

        val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 330) ?: 330
        gpuTempTv.text = "${tenths / 10.0} °C"

        livePingGaugeTv.text = "جاري الفحص..."
        val region = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("region_index", 0)
        thread {
            val ping = NetPingHelper.measureTrueGamePing(region)
            val jitter = NetPingHelper.lastJitter
            runOnUiThread {
                livePingGaugeTv.text = "$ping ms"
                val color = when {
                    ping < 75 -> "#10B981"
                    ping < 105 -> "#F59E0B"
                    else -> "#EF4444"
                }
                livePingGaugeTv.setTextColor(Color.parseColor(color))
                liveJitterTv.text = "$jitter ms"
                liveHitRegTv.text = "100% فوري"
            }
        }
    }

    private fun startFullBoostSequence(launchGame: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "يرجى منح صلاحية الظهور فوق التطبيقات لتشغيل عداد الفريمات العائم", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, OVERLAY_REQ)
            return
        }

        thread {
            NetPingHelper.optimizeGpuAndRam(this)
        }
        NetPingHelper.enableUltraNetworkAndHitRegEngine(this)

        val hudIntent = Intent(this, FloatingBoosterService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(hudIntent)
        } else {
            startService(hudIntent)
        }

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("isolate_bg", true)) {
            val prep = VpnService.prepare(this)
            if (prep != null) {
                startActivityForResult(prep, VPN_REQ)
                return
            } else {
                startService(Intent(this, GuardVpnService::class.java).setAction(GuardVpnService.ACTION_START))
            }
        }

        isBoosting = true
        mainBoostBtn.text = "مُعزّز ✓"
        mainBoostBtn.setTextColor(Color.parseColor("#10B981"))
        boostStatusSubTv.text = if (ShizukuShellEngine.hasShizukuPermission()) {
            "🔥 وضع Shizuku Diablo + مانع الدمج الوهمي نشط"
        } else {
            "⚡ تم تحرير الرام وتفعيل مانع الدمج الوهمي"
        }
        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"))

        if (launchGame) {
            handler.postDelayed({
                launchCodMobileAndFreeRam(prefs.getBoolean("zero_ram_exit", true))
            }, 350L)
        } else {
            refreshLiveMetrics()
        }
    }

    private fun launchCodMobileAndFreeRam(autoCloseActivity: Boolean) {
        val pkgs = listOf(
            "com.activision.callofduty.shooter",
            "com.garena.game.codm",
            "com.activision.callofduty.warzone"
        )
        for (pkg in pkgs) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                startActivity(launch)
                if (autoCloseActivity) {
                    finish()
                }
                return
            }
        }
        Toast.makeText(this, "⚡ المعزز وعداد الفريمات يعملان الآن! افتح كود موبايل", Toast.LENGTH_SHORT).show()
    }

    private fun stopAllBoostServices() {
        thread { ShizukuShellEngine.restoreNormalSystemState() }
        stopService(Intent(this, FloatingBoosterService::class.java))
        startService(Intent(this, GuardVpnService::class.java).setAction(GuardVpnService.ACTION_STOP))
        NetPingHelper.disableUltraNetworkEngine()
        isBoosting = false
        mainBoostBtn.text = "تعزيز"
        mainBoostBtn.setTextColor(Color.parseColor("#60A5FA"))
        boostStatusSubTv.text = "تم إيقاف المعزز واستعادة إعدادات النظام"
        boostStatusSubTv.setTextColor(Color.parseColor("#94A3B8"))
        Toast.makeText(this, "🛑 تم إيقاف المعزز واستعادة إعدادات النظام بالكامل", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQ && resultCode == RESULT_OK) {
            startService(Intent(this, GuardVpnService::class.java).setAction(GuardVpnService.ACTION_START))
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            launchCodMobileAndFreeRam(prefs.getBoolean("zero_ram_exit", true))
        } else if (requestCode == OVERLAY_REQ && Settings.canDrawOverlays(this)) {
            startFullBoostSequence(launchGame = false)
        }
    }
}
