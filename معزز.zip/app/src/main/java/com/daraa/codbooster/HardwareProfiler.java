package com.daraa.codbooster;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;

public final class HardwareProfiler {

    public HardwareProfiler() {}

    public static String getSafeStr(String s) {
        return s != null ? s.trim() : "";
    }

    public static String getDeviceMarketingName() {
        String brand = getSafeStr(Build.BRAND);
        String model = getSafeStr(Build.MODEL);
        if (model.length() == 0) return "Samsung Galaxy A07 4G";
        if (brand.length() > 0 && !model.toLowerCase().startsWith(brand.toLowerCase())) {
            String capBrand = brand.substring(0, 1).toUpperCase() + brand.substring(1);
            return capBrand + " " + model;
        }
        return model;
    }

    public static int readDisplayRefreshRate(Context context) {
        try {
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                Display d = wm.getDefaultDisplay();
                if (d != null) {
                    int hz = Math.round(d.getRefreshRate());
                    if (hz >= 30 && hz <= 240) return hz;
                }
            }
        } catch (Throwable ignored) {}
        return 90;
    }

    public static long[] getRamStatsMb(Context context) {
        long availMb = 2800L;
        long totalMb = 6144L;
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                availMb = mi.availMem / (1024L * 1024L);
                totalMb = mi.totalMem / (1024L * 1024L);
            }
        } catch (Throwable ignored) {}
        long usedMb = totalMb > availMb ? (totalMb - availMb) : 0L;
        return new long[]{availMb, totalMb, usedMb};
    }

    public static float getBatteryTempCelsius(Context context) {
        try {
            Intent bm = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bm != null) {
                int tenths = bm.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320);
                return tenths / 10.0f;
            }
        } catch (Throwable ignored) {}
        return 32.0f;
    }
}
