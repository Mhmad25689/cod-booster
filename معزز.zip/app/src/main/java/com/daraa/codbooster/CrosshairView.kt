package com.daraa.codbooster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class CrosshairView(context: Context) : View(context) {

    var styleIndex = 0
    var colorIndex = 0
    var scaleFactor = 1.0f

    private val colors = intArrayOf(
        Color.parseColor("#00FF66"),
        Color.parseColor("#00F0FF"),
        Color.parseColor("#FF2A54"),
        Color.parseColor("#FFD600")
    )

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#AA000000")
        strokeCap = Paint.Cap.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun nextStyle() {
        styleIndex = (styleIndex + 1) % 4
        invalidate()
    }

    fun nextColor() {
        colorIndex = (colorIndex + 1) % colors.size
        invalidate()
    }

    fun cycleSize() {
        scaleFactor = when {
            scaleFactor < 1.0f -> 1.0f
            scaleFactor < 1.3f -> 1.35f
            else -> 0.75f
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val density = resources.displayMetrics.density
        val s = density * scaleFactor

        val activeColor = colors[colorIndex % colors.size]
        strokePaint.color = activeColor
        fillPaint.color = activeColor
        strokePaint.strokeWidth = 2.0f * s
        shadowPaint.strokeWidth = 3.6f * s

        when (styleIndex) {
            0 -> {
                val gap = 4f * s
                val len = 11f * s
                canvas.drawLine(cx - len, cy, cx - gap, cy, shadowPaint)
                canvas.drawLine(cx + gap, cy, cx + len, cy, shadowPaint)
                canvas.drawLine(cx, cy - len, cx, cy - gap, shadowPaint)
                canvas.drawLine(cx, cy + gap, cx, cy + len, shadowPaint)

                canvas.drawLine(cx - len, cy, cx - gap, cy, strokePaint)
                canvas.drawLine(cx + gap, cy, cx + len, cy, strokePaint)
                canvas.drawLine(cx, cy - len, cx, cy - gap, strokePaint)
                canvas.drawLine(cx, cy + gap, cx, cy + len, strokePaint)
                canvas.drawCircle(cx, cy, 1.8f * s, fillPaint)
            }
            1 -> {
                canvas.drawCircle(cx, cy, 3.8f * s, shadowPaint)
                canvas.drawCircle(cx, cy, 3.0f * s, fillPaint)
            }
            2 -> {
                val r = 9f * s
                canvas.drawCircle(cx, cy, r, shadowPaint)
                canvas.drawCircle(cx, cy, r, strokePaint)
                canvas.drawCircle(cx, cy, 1.8f * s, fillPaint)
            }
            3 -> {
                val gap = 3.5f * s
                val len = 11f * s
                canvas.drawLine(cx - len, cy, cx - gap, cy, shadowPaint)
                canvas.drawLine(cx + gap, cy, cx + len, cy, shadowPaint)
                canvas.drawLine(cx, cy + gap, cx, cy + len, shadowPaint)

                canvas.drawLine(cx - len, cy, cx - gap, cy, strokePaint)
                canvas.drawLine(cx + gap, cy, cx + len, cy, strokePaint)
                canvas.drawLine(cx, cy + gap, cx, cy + len, strokePaint)
                canvas.drawCircle(cx, cy, 1.6f * s, fillPaint)
            }
        }
    }
}
