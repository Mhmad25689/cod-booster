package com.daraa.codbooster;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    public static final int VPN_REQ = 2001;
    public static final int OVERLAY_REQ = 2002;
    public static final int SHIZUKU_REQ = 2003;
    public static final String PREFS = "hyperboost_prefs";

    public interface ToggleCallback {
        void onToggled(boolean enabled);
    }

    public FrameLayout contentFrame;
    public ScrollView tabGamesBoostView;
    public ScrollView tabNetworkView;
    public ScrollView tabGpuView;
    public ScrollView tabEngineerView;

    public TextView navGamesLabel;
    public TextView navNetLabel;
    public TextView navGpuLabel;
    public TextView navEngLabel;

    // Hardware & Shizuku Header Views
    public TextView deviceModelBannerTv;
    public TextView deviceSpecsSubTv;
    public TextView deviceRamChipTv;
    public TextView deviceHzChipTv;
    public TextView deviceTempChipTv;

    public TextView shizukuBannerTv;
    public TextView shizukuActionBtn;

    // Auto-Detected Games Library Views
    public TextView detectedGamesCountBadge;
    public LinearLayout gamesCarouselContainer;
    public ImageView selectedGameIconView;
    public TextView selectedGameTitleTv;
    public TextView selectedGamePkgTv;
    public TextView boostStatusSubTv;
    public TextView mainBoostBtn;

    public TextView regionValueTv;
    public TextView downscaleValueTv;
    public TextView activeServerSubTv;
    public TextView livePingGaugeTv;
    public TextView liveJitterTv;
    public TextView liveHitRegTv;

    public TextView pill4GView = null;
    public TextView pillAdslView = null;
    public int currentNetMode = 0;

    public TextView gpuRamFreeTv;
    public TextView gpuTempTv;
    public final List<LinearLayout> profileViews = new ArrayList<LinearLayout>();
    public int selectedGpuProfile = 0;

    // Engineer Lab Views
    public TextView engSpecsDetailTv;
    public TextView engNetDetailTv;
    public TextView engKernelLogTv;

    public final Handler handler = new Handler(Looper.getMainLooper());
    public boolean isBoosting = false;

    public final Shizuku.OnRequestPermissionResultListener shizukuPermListener =
        new Shizuku.OnRequestPermissionResultListener() {
            @Override
            public void onRequestPermissionResult(int requestCode, final int grantResult) {
                if (requestCode == SHIZUKU_REQ) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshShizukuBanner();
                            refreshEngineerLabInfo();
                            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                                String kernelId = ShizukuShellEngine.getVerifiedKernelIdentity();
                                Toast.makeText(
                                    MainActivity.this,
                                    "🔥 تم تفعيل صلاحيات Shizuku الحقيقية (" + kernelId + ") بنجاح!",
                                    Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    });
                }
            }
        };

    public int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            (float) value,
            getResources().getDisplayMetrics()
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().setStatusBarColor(Color.parseColor("#080B12"));
            getWindow().setNavigationBarColor(Color.parseColor("#0D111C"));
        } catch (Throwable ignored) {}

        try {
            Shizuku.tryRequestBinderFromProvider(this);
            Shizuku.addRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignored) {}

        GameScannerEngine.scanInstalledGames(this);
        NetPingHelper.prewarmGameLoginAndMatchmakingServers();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#080B12"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setFitsSystemWindows(true);

        contentFrame = new FrameLayout(this);
        contentFrame.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ));

        tabGamesBoostView = buildGamesAndBoostTab();
        tabNetworkView = buildNetworkEngineTab();
        tabGpuView = buildGpuEngineTab();
        tabEngineerView = buildEngineerLabTab();

        contentFrame.addView(tabGamesBoostView);
        contentFrame.addView(tabNetworkView);
        contentFrame.addView(tabGpuView);
        contentFrame.addView(tabEngineerView);

        root.addView(contentFrame);
        root.addView(buildBottomNavBar());

        setContentView(root);
        switchTab(0);
        refreshDetectedGamesCarousel();
        refreshShizukuBanner();
        refreshLiveMetrics();
        refreshEngineerLabInfo();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            Shizuku.tryRequestBinderFromProvider(this);
        } catch (Throwable ignored) {}
        GameScannerEngine.scanInstalledGames(this);
        refreshDetectedGamesCarousel();
        refreshShizukuBanner();
        refreshLiveMetrics();
        refreshEngineerLabInfo();
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    public ScrollView buildGamesAndBoostTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#080B12"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(15), dp(14), dp(15), dp(24));

        // 1. شريط العنوان الاحترافي
        RelativeLayout topBar = new RelativeLayout(this);
        topBar.setPadding(0, 0, 0, dp(12));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("معزز الألعاب الأسطوري");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f);
        headerTitle.setTypeface(Typeface.DEFAULT_BOLD);
        RelativeLayout.LayoutParams hLp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        hLp.addRule(RelativeLayout.CENTER_IN_PARENT);
        headerTitle.setLayoutParams(hLp);

        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#172B4D"));
        badgeBg.setCornerRadius((float) dp(12));
        badgeBg.setStroke(dp(1), Color.parseColor("#00F0FF"));

        TextView editionBadge = new TextView(this);
        editionBadge.setText("⚡ V6 PRO");
        editionBadge.setTextColor(Color.parseColor("#00F0FF"));
        editionBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        editionBadge.setTypeface(Typeface.DEFAULT_BOLD);
        editionBadge.setBackground(badgeBg);
        editionBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        RelativeLayout.LayoutParams bLp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        bLp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        bLp.addRule(RelativeLayout.CENTER_VERTICAL);
        editionBadge.setLayoutParams(bLp);

        topBar.addView(headerTitle);
        topBar.addView(editionBadge);
        col.addView(topBar);

        // 2. بطاقة التعرف التلقائي على الهاتف والعتاد (Hardware Auto-Profiler)
        LinearLayout hwBannerCard = createSleekCard("#101726", "#1E293B");
        deviceModelBannerTv = new TextView(this);
        deviceModelBannerTv.setText("📱 " + HardwareProfiler.getDeviceMarketingName() + " • " + HardwareProfiler.getAndroidOsLabel());
        deviceModelBannerTv.setTextColor(Color.parseColor("#38BDF8"));
        deviceModelBannerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        deviceModelBannerTv.setTypeface(Typeface.DEFAULT_BOLD);

        deviceSpecsSubTv = new TextView(this);
        deviceSpecsSubTv.setText("⚙️ " + HardwareProfiler.getSocAndAbiSummary() + "\n🛡️ " + HardwareProfiler.getOemEngineBadge());
        deviceSpecsSubTv.setTextColor(Color.parseColor("#94A3B8"));
        deviceSpecsSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        deviceSpecsSubTv.setPadding(0, dp(4), 0, dp(10));

        LinearLayout hwChipsRow = new LinearLayout(this);
        hwChipsRow.setOrientation(LinearLayout.HORIZONTAL);
        hwChipsRow.setWeightSum(3f);

        long[] ramStats = HardwareProfiler.getRamStatsMb(this);
        int hz = HardwareProfiler.readDisplayRefreshRate(this);
        float tempC = HardwareProfiler.getBatteryTempCelsius(this);

        deviceRamChipTv = createMiniHwChip("الرام الحرة: " + ramStats[0] + "MB", "#10B981");
        deviceHzChipTv = createMiniHwChip("الشاشة: " + hz + "Hz", "#00F0FF");
        deviceTempChipTv = createMiniHwChip("الحرارة: " + tempC + "°C", "#F59E0B");

        hwChipsRow.addView(deviceRamChipTv);
        hwChipsRow.addView(deviceHzChipTv);
        hwChipsRow.addView(deviceTempChipTv);

        hwBannerCard.addView(deviceModelBannerTv);
        hwBannerCard.addView(deviceSpecsSubTv);
        hwBannerCard.addView(hwChipsRow);
        col.addView(hwBannerCard);

        // 3. بطاقة نواة Shizuku UID 2000
        LinearLayout shizukuCard = createSleekCard("#12192B", "#2563EB");
        LinearLayout shizukuRow = new LinearLayout(this);
        shizukuRow.setOrientation(LinearLayout.HORIZONTAL);
        shizukuRow.setGravity(Gravity.CENTER_VERTICAL);

        shizukuBannerTv = new TextView(this);
        shizukuBannerTv.setText("⚡ جاري فحص اتصال نواة Shizuku (UID 2000)...");
        shizukuBannerTv.setTextColor(Color.WHITE);
        shizukuBannerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        shizukuBannerTv.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuBannerTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        shizukuBannerTv.setPadding(0, 0, dp(8), 0);

        GradientDrawable shizukuBtnBg = new GradientDrawable();
        shizukuBtnBg.setColor(Color.parseColor("#2563EB"));
        shizukuBtnBg.setCornerRadius((float) dp(14));

        shizukuActionBtn = new TextView(this);
        shizukuActionBtn.setText("ربط Shizuku");
        shizukuActionBtn.setTextColor(Color.WHITE);
        shizukuActionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        shizukuActionBtn.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuActionBtn.setBackground(shizukuBtnBg);
        shizukuActionBtn.setPadding(dp(12), dp(7), dp(12), dp(7));
        shizukuActionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleShizukuButtonClick();
            }
        });

        shizukuRow.addView(shizukuBannerTv);
        shizukuRow.addView(shizukuActionBtn);
        shizukuCard.addView(shizukuRow);
        col.addView(shizukuCard);

        // 4. بطاقة مكتبة الألعاب المكتشفة تلقائياً (Auto-Detected Games Hub)
        LinearLayout scannerCard = createSleekCard("#141824", "#1E293B");
        LinearLayout scannerHeader = new LinearLayout(this);
        scannerHeader.setOrientation(LinearLayout.HORIZONTAL);
        scannerHeader.setGravity(Gravity.CENTER_VERTICAL);
        scannerHeader.setPadding(0, 0, 0, dp(8));

        detectedGamesCountBadge = new TextView(this);
        detectedGamesCountBadge.setText("🎮 الألعاب المكتشفة تلقائياً");
        detectedGamesCountBadge.setTextColor(Color.WHITE);
        detectedGamesCountBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        detectedGamesCountBadge.setTypeface(Typeface.DEFAULT_BOLD);
        detectedGamesCountBadge.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView addAppBtn = createHeaderSmallButton("+ إضافة لعبة/تطبيق", "#172B4D", "#38BDF8", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddCustomGameDialog();
            }
        });

        TextView rescanBtn = createHeaderSmallButton("فحص ↻", "#0F172A", "#10B981", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GameScannerEngine.scanInstalledGames(MainActivity.this);
                refreshDetectedGamesCarousel();
                Toast.makeText(
                    MainActivity.this,
                    "✅ تم فحص الجهاز واكتشاف " + GameScannerEngine.cachedGames.size() + " لعبة تلقائياً",
                    Toast.LENGTH_SHORT
                ).show();
            }
        });

        scannerHeader.addView(detectedGamesCountBadge);
        scannerHeader.addView(addAppBtn);
        scannerHeader.addView(rescanBtn);
        scannerCard.addView(scannerHeader);

        TextView scannerHint = new TextView(this);
        scannerHint.setText("يتعرف التطبيق تلقائياً على جميع الألعاب المثبتة على أي هاتف. اضغط على أي لعبة لاختيارها أو أضف أي تطبيق يدوياً:");
        scannerHint.setTextColor(Color.parseColor("#94A3B8"));
        scannerHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        scannerHint.setPadding(0, 0, 0, dp(10));
        scannerCard.addView(scannerHint);

        HorizontalScrollView hScroll = new HorizontalScrollView(this);
        hScroll.setHorizontalScrollBarEnabled(false);
        gamesCarouselContainer = new LinearLayout(this);
        gamesCarouselContainer.setOrientation(LinearLayout.HORIZONTAL);
        gamesCarouselContainer.setGravity(Gravity.CENTER_VERTICAL);
        hScroll.addView(gamesCarouselContainer);
        scannerCard.addView(hScroll);

        col.addView(scannerCard);

        // 5. بطاقة اللعبة المستهدفة والتحكم بالتعزيز الخارق
        LinearLayout activeGameCard = createSleekCard("#141A29", "#2563EB");
        LinearLayout gameRow = new LinearLayout(this);
        gameRow.setOrientation(LinearLayout.HORIZONTAL);
        gameRow.setGravity(Gravity.CENTER_VERTICAL);

        selectedGameIconView = new ImageView(this);
        selectedGameIconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        selectedGameIconView.setLayoutParams(new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, dp(12), 0);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        selectedGameTitleTv = new TextView(this);
        selectedGameTitleTv.setText(GameScannerEngine.getActiveGameName(this));
        selectedGameTitleTv.setTextColor(Color.WHITE);
        selectedGameTitleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        selectedGameTitleTv.setTypeface(Typeface.DEFAULT_BOLD);

        selectedGamePkgTv = new TextView(this);
        selectedGamePkgTv.setText(GameScannerEngine.getActiveGamePackage(this));
        selectedGamePkgTv.setTextColor(Color.parseColor("#64748B"));
        selectedGamePkgTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        selectedGamePkgTv.setPadding(0, dp(1), 0, 0);

        boostStatusSubTv = new TextView(this);
        boostStatusSubTv.setText("جاهز للتعزيز: مسار مباشر <60ms + أولوية معالج قصوى + عداد FPS");
        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"));
        boostStatusSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        boostStatusSubTv.setPadding(0, dp(3), 0, 0);

        titleCol.addView(selectedGameTitleTv);
        titleCol.addView(selectedGamePkgTv);
        titleCol.addView(boostStatusSubTv);

        GradientDrawable boostPillBg = new GradientDrawable();
        boostPillBg.setColor(Color.parseColor("#2563EB"));
        boostPillBg.setCornerRadius((float) dp(18));
        boostPillBg.setStroke(dp(1), Color.parseColor("#60A5FA"));

        mainBoostBtn = new TextView(this);
        mainBoostBtn.setText("🚀 تعزيز وتشغيل");
        mainBoostBtn.setTextColor(Color.WHITE);
        mainBoostBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        mainBoostBtn.setTypeface(Typeface.DEFAULT_BOLD);
        mainBoostBtn.setGravity(Gravity.CENTER);
        mainBoostBtn.setBackground(boostPillBg);
        mainBoostBtn.setPadding(dp(14), dp(10), dp(14), dp(10));
        mainBoostBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(true);
            }
        });

        gameRow.addView(selectedGameIconView);
        gameRow.addView(titleCol);
        gameRow.addView(mainBoostBtn);
        activeGameCard.addView(gameRow);

        View divider1 = new View(this);
        divider1.setBackgroundColor(Color.parseColor("#1F293D"));
        LinearLayout.LayoutParams d1Lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        d1Lp.setMargins(0, dp(12), 0, dp(10));
        divider1.setLayoutParams(d1Lp);
        activeGameCard.addView(divider1);

        LinearLayout regionRow = new LinearLayout(this);
        regionRow.setOrientation(LinearLayout.HORIZONTAL);
        regionRow.setGravity(Gravity.CENTER_VERTICAL);
        regionRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRegionSelectorDialog();
            }
        });

        TextView regionLabelTv = new TextView(this);
        regionLabelTv.setText("منطقة الخادم والمسار");
        regionLabelTv.setTextColor(Color.parseColor("#94A3B8"));
        regionLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        regionLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        int savedRegion = prefs.getInt("region_index", 0);
        regionValueTv = new TextView(this);
        regionValueTv.setText(NetPingHelper.SERVER_REGIONS[savedRegion] + "  ‹");
        regionValueTv.setTextColor(Color.parseColor("#E2E8F0"));
        regionValueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        regionValueTv.setTypeface(Typeface.DEFAULT_BOLD);

        regionRow.addView(regionLabelTv);
        regionRow.addView(regionValueTv);
        activeGameCard.addView(regionRow);

        View divider2 = new View(this);
        divider2.setBackgroundColor(Color.parseColor("#1F293D"));
        LinearLayout.LayoutParams d2Lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        d2Lp.setMargins(0, dp(10), 0, dp(10));
        divider2.setLayoutParams(d2Lp);
        activeGameCard.addView(divider2);

        LinearLayout downscaleRow = new LinearLayout(this);
        downscaleRow.setOrientation(LinearLayout.HORIZONTAL);
        downscaleRow.setGravity(Gravity.CENTER_VERTICAL);
        downscaleRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDownscaleSelectorDialog();
            }
        });

        TextView downscaleLabelTv = new TextView(this);
        downscaleLabelTv.setText("دقة رندر المعالج الرسومي (GPU Scaling)");
        downscaleLabelTv.setTextColor(Color.parseColor("#38BDF8"));
        downscaleLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        downscaleLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        int savedDownscale = prefs.getInt("downscale_index", 0);
        downscaleValueTv = new TextView(this);
        downscaleValueTv.setText(NetPingHelper.getDownscaleRatioValue(savedDownscale) + "x Esports  ‹");
        downscaleValueTv.setTextColor(Color.parseColor("#00F0FF"));
        downscaleValueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        downscaleValueTv.setTypeface(Typeface.DEFAULT_BOLD);

        downscaleRow.addView(downscaleLabelTv);
        downscaleRow.addView(downscaleValueTv);
        activeGameCard.addView(downscaleRow);

        col.addView(activeGameCard);

        // 6. بطاقة القياس الحي للبنغ والتذبذب الفعلي
        LinearLayout telemetryCard = createSleekCard("#141824", "#1E293B");
        LinearLayout teleHeader = new LinearLayout(this);
        teleHeader.setOrientation(LinearLayout.HORIZONTAL);
        teleHeader.setGravity(Gravity.CENTER_VERTICAL);
        teleHeader.setPadding(0, 0, 0, dp(6));

        TextView teleTitle = new TextView(this);
        teleTitle.setText("📡 القياس الفعلي الحقيقي للبنغ والشبكة (Real TCP/ICMP RTT)");
        teleTitle.setTextColor(Color.parseColor("#E2E8F0"));
        teleTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        teleTitle.setTypeface(Typeface.DEFAULT_BOLD);
        teleTitle.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView refreshBtn = new TextView(this);
        refreshBtn.setText("فحص حي ↻");
        refreshBtn.setTextColor(Color.parseColor("#38BDF8"));
        refreshBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        refreshBtn.setTypeface(Typeface.DEFAULT_BOLD);
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshLiveMetrics();
            }
        });

        teleHeader.addView(teleTitle);
        teleHeader.addView(refreshBtn);
        telemetryCard.addView(teleHeader);

        activeServerSubTv = new TextView(this);
        activeServerSubTv.setText("المسار النشط: " + NetPingHelper.activeServerLabel);
        activeServerSubTv.setTextColor(Color.parseColor("#94A3B8"));
        activeServerSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        activeServerSubTv.setPadding(0, 0, 0, dp(10));
        telemetryCard.addView(activeServerSubTv);

        LinearLayout metricsGrid = new LinearLayout(this);
        metricsGrid.setOrientation(LinearLayout.HORIZONTAL);
        metricsGrid.setWeightSum(3f);

        LinearLayout[] box1Holder = new LinearLayout[1];
        livePingGaugeTv = createMetricBox("البنغ الفعلي RTT", "-- ms", "#10B981", box1Holder);

        LinearLayout[] box2Holder = new LinearLayout[1];
        liveJitterTv = createMetricBox("التذبذب Jitter", "-- ms", "#38BDF8", box2Holder);

        LinearLayout[] box3Holder = new LinearLayout[1];
        liveHitRegTv = createMetricBox("فقدان الحزم Loss", "0%", "#A855F7", box3Holder);

        metricsGrid.addView(box1Holder[0]);
        metricsGrid.addView(box2Holder[0]);
        metricsGrid.addView(box3Holder[0]);
        telemetryCard.addView(metricsGrid);
        col.addView(telemetryCard);

        // أزرار سريعة للنافذة العائمة وإيقاف الخدمات
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setWeightSum(2f);

        TextView btnHudOnly = createActionButton("🎯 تشغيل عداد FPS العائم فقط", "#172B4D", "#38BDF8", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(false);
            }
        });
        TextView btnStopAll = createActionButton("🛑 إيقاف المعزز واستعادة النظام", "#2A1219", "#F87171", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAllBoostServices();
            }
        });
        actionRow.addView(btnHudOnly);
        actionRow.addView(btnStopAll);
        col.addView(actionRow);

        scroll.addView(col);
        return scroll;
    }

    public void refreshDetectedGamesCarousel() {
        if (gamesCarouselContainer == null) return;
        gamesCarouselContainer.removeAllViews();

        List<GameScannerEngine.GameItem> games = GameScannerEngine.cachedGames;
        String activePkg = GameScannerEngine.getActiveGamePackage(this);
        String activeName = GameScannerEngine.getActiveGameName(this);

        if (detectedGamesCountBadge != null) {
            detectedGamesCountBadge.setText("🎮 الألعاب المكتشفة (" + games.size() + ")");
        }

        if (selectedGameIconView != null) {
            selectedGameIconView.setImageDrawable(GameScannerEngine.loadGameIcon(this, activePkg));
        }
        if (selectedGameTitleTv != null) {
            selectedGameTitleTv.setText(activeName);
        }
        if (selectedGamePkgTv != null) {
            selectedGamePkgTv.setText(activePkg);
        }

        if (games.isEmpty()) {
            GradientDrawable emptyBg = new GradientDrawable();
            emptyBg.setColor(Color.parseColor("#0F1522"));
            emptyBg.setCornerRadius((float) dp(12));
            emptyBg.setStroke(dp(1), Color.parseColor("#334155"));

            TextView emptyTv = new TextView(this);
            emptyTv.setText("لم يتم العثور على ألعاب مثبتة حالياً • اضغط (+ إضافة لعبة/تطبيق) لاختيار أي تطبيق على هاتفك");
            emptyTv.setTextColor(Color.parseColor("#94A3B8"));
            emptyTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            emptyTv.setBackground(emptyBg);
            emptyTv.setPadding(dp(14), dp(12), dp(14), dp(12));
            emptyTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAddCustomGameDialog();
                }
            });
            gamesCarouselContainer.addView(emptyTv);
            return;
        }

        for (int i = 0; i < games.size(); i++) {
            final GameScannerEngine.GameItem item = games.get(i);
            boolean isSelected = item.packageName.equals(activePkg);

            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setCornerRadius((float) dp(14));
            if (isSelected) {
                cardBg.setColor(Color.parseColor("#172B4D"));
                cardBg.setStroke(dp(2), Color.parseColor("#00F0FF"));
            } else {
                cardBg.setColor(Color.parseColor("#0E131F"));
                cardBg.setStroke(dp(1), Color.parseColor("#1F293D"));
            }

            LinearLayout gCard = new LinearLayout(this);
            gCard.setOrientation(LinearLayout.VERTICAL);
            gCard.setGravity(Gravity.CENTER);
            gCard.setBackground(cardBg);
            gCard.setPadding(dp(10), dp(10), dp(10), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(108), LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), 0, dp(4), 0);
            gCard.setLayoutParams(lp);

            ImageView iconIv = new ImageView(this);
            iconIv.setImageDrawable(GameScannerEngine.loadGameIcon(this, item.packageName));
            iconIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iconIv.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));

            TextView nameTv = new TextView(this);
            nameTv.setText(item.label);
            nameTv.setTextColor(isSelected ? Color.parseColor("#00F0FF") : Color.WHITE);
            nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            nameTv.setTypeface(Typeface.DEFAULT_BOLD);
            nameTv.setGravity(Gravity.CENTER);
            nameTv.setSingleLine(true);
            nameTv.setPadding(0, dp(6), 0, dp(2));

            TextView stateTv = new TextView(this);
            stateTv.setText(isSelected ? "محددة ✓" : "اضغط للاختيار");
            stateTv.setTextColor(isSelected ? Color.parseColor("#34D399") : Color.parseColor("#64748B"));
            stateTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
            stateTv.setGravity(Gravity.CENTER);

            gCard.addView(iconIv);
            gCard.addView(nameTv);
            gCard.addView(stateTv);

            gCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GameScannerEngine.setSelectedGame(MainActivity.this, item.packageName, item.label);
                    refreshDetectedGamesCarousel();
                    refreshEngineerLabInfo();
                    Toast.makeText(
                        MainActivity.this,
                        "🎯 تم تحديد اللعبة: " + item.label,
                        Toast.LENGTH_SHORT
                    ).show();
                }
            });

            gamesCarouselContainer.addView(gCard);
        }
    }

    public void showAddCustomGameDialog() {
        final List<GameScannerEngine.GameItem> candidates = GameScannerEngine.listLaunchableNonGameApps(this);
        if (candidates.isEmpty()) {
            Toast.makeText(this, "جميع التطبيقات القابلة للتشغيل مضافة بالفعل في المكتبة!", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence[] titles = new CharSequence[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            titles[i] = candidates.get(i).label + "\n(" + candidates.get(i).packageName + ")";
        }
        try {
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("إضافة لعبة أو تطبيق إلى المعزز")
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which >= 0 && which < candidates.size()) {
                            GameScannerEngine.GameItem chosen = candidates.get(which);
                            GameScannerEngine.addCustomGamePackage(MainActivity.this, chosen.packageName);
                            GameScannerEngine.setSelectedGame(MainActivity.this, chosen.packageName, chosen.label);
                            GameScannerEngine.scanInstalledGames(MainActivity.this);
                            refreshDetectedGamesCarousel();
                            refreshEngineerLabInfo();
                            Toast.makeText(
                                MainActivity.this,
                                "✅ تمت إضافة وتحديد: " + chosen.label,
                                Toast.LENGTH_SHORT
                            ).show();
                        }
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
        } catch (Throwable ignored) {}
    }

    public ScrollView buildNetworkEngineTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        currentNetMode = prefs.getInt("net_mode", 0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#080B12"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(15), dp(16), dp(15), dp(24));

        TextView title = new TextView(this);
        title.setText("محرك الشبكة وتثبيت البنغ <60ms");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(4));

        TextView sub = new TextView(this);
        sub.setText("توجيه مباشر Zero-Overhead + نبضات DSCP EF (0xB8) كل 250ms + عزل تطبيقات الخلفية الشرهة");
        sub.setTextColor(Color.parseColor("#94A3B8"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        sub.setPadding(0, 0, 0, dp(14));

        col.addView(title);
        col.addView(sub);

        LinearLayout netConfigCard = createSleekCard("#141824", "#1E293B");
        TextView netSectionTitle = new TextView(this);
        netSectionTitle.setText("⚙️ ضبط MTU ونوع الاتصال");
        netSectionTitle.setTextColor(Color.WHITE);
        netSectionTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        netSectionTitle.setTypeface(Typeface.DEFAULT_BOLD);
        netSectionTitle.setPadding(0, 0, 0, dp(10));
        netConfigCard.addView(netSectionTitle);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setWeightSum(2f);
        LinearLayout.LayoutParams mRowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        mRowLp.setMargins(0, 0, 0, dp(12));
        modeRow.setLayoutParams(mRowLp);

        pill4GView = createModePill("📶 بيانات 4G/LTE (MTU 1360)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentNetMode = 0;
                prefs.edit().putInt("net_mode", 0).apply();
                refreshNetModePills();
            }
        });
        pillAdslView = createModePill("🏠 راوتر Wi-Fi / فايبر (MTU 1440)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentNetMode = 1;
                prefs.edit().putInt("net_mode", 1).apply();
                refreshNetModePills();
            }
        });
        refreshNetModePills();
        modeRow.addView(pill4GView);
        modeRow.addView(pillAdslView);
        netConfigCard.addView(modeRow);

        netConfigCard.addView(createModernToggleRow(
            "إيقاف خنق المصنع الحراري (Samsung GOS / Realme Athena)",
            "يتعرف تلقائياً على واجهة الهاتف (One UI / Realme UI / HyperOS) ويجمد خنق الفريمات",
            prefs.getBoolean("kill_gos", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("kill_gos", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "مانع الدمج الوهمي الحقيقي (250ms RRC Radio Lock)",
            "نبضات DSCP EF بتردد 4Hz لمنع خمول برج الـ 4G والراوتر أثناء المواجهات",
            prefs.getBoolean("hit_reg_boost", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("hit_reg_boost", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "توجيه مباشر أسرع من GearUP (Zero-Overhead Route)",
            "ربط الألعاب المكتشفة مباشرة بالخادم بدون تشفير VPN يبطئ خط الإنترنت",
            prefs.getBoolean("fast_login", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("fast_login", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "عزل إنترنت الخلفية الذكي (Split-Tunnel Sinkhole)",
            "قطع الإنترنت عن تطبيقات الخلفية الشرهة مع استثناء جميع الألعاب المكتشفة 100%",
            prefs.getBoolean("isolate_bg", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("isolate_bg", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "وضع صفر رام (إغلاق واجهة المعزز فور فتح اللعبة)",
            "تحرير كامل الرام للعبة وإبقاء كبسولة الفريمات والبنغ الخفيفة فقط",
            prefs.getBoolean("zero_ram_exit", false),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("zero_ram_exit", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createFullWidthButton("⚡ فحص واختيار أسرع DNS للمنطقة الآن", "#2563EB", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final String bestDns = NetPingHelper.benchmarkAndSelectFastestDns();
                        final int ping = NetPingHelper.measureTrueGamePing(prefs.getInt("region_index", 0));
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshLiveMetrics();
                                refreshEngineerLabInfo();
                                Toast.makeText(
                                    MainActivity.this,
                                    "✅ تم ربط أسرع DNS: " + bestDns + " (البنغ: " + ping + "ms)",
                                    Toast.LENGTH_LONG
                                ).show();
                            }
                        });
                    }
                }).start();
            }
        }));

        col.addView(netConfigCard);
        scroll.addView(col);
        return scroll;
    }

    public ScrollView buildGpuEngineTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        selectedGpuProfile = prefs.getInt("gpu_profile", 0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#080B12"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(15), dp(16), dp(15), dp(24));

        TextView title = new TextView(this);
        title.setText("محرك النواة و Diablo GPU V6");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(4));

        TextView sub = new TextView(this);
        sub.setText("يتكيف تلقائياً مع معالج هاتفك (" + HardwareProfiler.getDeviceMarketingName() + ") ويتحكم بـ SurfaceFlinger و GameManagerService");
        sub.setTextColor(Color.parseColor("#94A3B8"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        sub.setPadding(0, 0, 0, dp(14));

        col.addView(title);
        col.addView(sub);

        LinearLayout hwCard = createSleekCard("#141824", "#1E293B");
        LinearLayout hwRow = new LinearLayout(this);
        hwRow.setOrientation(LinearLayout.HORIZONTAL);
        hwRow.setWeightSum(2f);

        LinearLayout[] ramBoxHolder = new LinearLayout[1];
        gpuRamFreeTv = createMetricBox("الرام الحرة الفعلية", "-- MB", "#00F0FF", ramBoxHolder);

        LinearLayout[] tempBoxHolder = new LinearLayout[1];
        gpuTempTv = createMetricBox("حرارة البطارية الفعلية", "-- °C", "#10B981", tempBoxHolder);

        hwRow.addView(ramBoxHolder[0]);
        hwRow.addView(tempBoxHolder[0]);
        hwCard.addView(hwRow);

        TextView flushBtn = createFullWidthButton("🔥 تطبيق وضع النواة المختار وتحرير الرام الآن", "#2563EB", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final long freed = NetPingHelper.optimizeGpuAndRam(MainActivity.this);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshLiveMetrics();
                                refreshEngineerLabInfo();
                                String msg = ShizukuShellEngine.hasShizukuPermission()
                                    ? "🔥 تم تنفيذ أوامر Shizuku الحقيقية لـ " + HardwareProfiler.getDeviceMarketingName() + " بنجاح!"
                                    : "⚡ تم تنظيف العمليات الخلفية (" + (freed > 0 ? ("تم تحرير " + freed + " MB") : "الذاكرة في أقصى سعة") + ")";
                                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }).start();
            }
        });
        hwCard.addView(flushBtn);
        col.addView(hwCard);

        LinearLayout profileCard = createSleekCard("#141824", "#1E293B");
        TextView profTitle = new TextView(this);
        profTitle.setText("🎛️ أوضاع النواة الحقيقية (مخصصة لـ " + HardwareProfiler.getDeviceMarketingName() + ")");
        profTitle.setTextColor(Color.WHITE);
        profTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        profTitle.setTypeface(Typeface.DEFAULT_BOLD);
        profTitle.setPadding(0, 0, 0, dp(10));
        profileCard.addView(profTitle);

        profileViews.clear();
        String[] pTitles = new String[]{
            "🔥 وضع Diablo الخارق (أقصى فريمات + أولوية CPU -20)",
            "⚖️ وضع Rise المتوازن (ثبات الفريمات للمباريات الطويلة)",
            "❄️ وضع التبريد الفائق (تحجيم 70% لمنع السخونة والهبوط الحراري)"
        };
        String[] pDescs = new String[]{
            "يقفل ترددات الأداء القصوى، يجمد خدمات الخنق (Samsung GOS / Realme Athena)، يرفع تردد الشاشة، ويمنح اللعبة أولوية -20",
            "يضبط تحجيم الرندر على 85% مع منع الخنق الخلفي والحفاظ على استقرار الحرارة والفريمات لفترات اللعب الطويلة",
            "يخفض عبء المعالج الرسومي بنسبة 45% عبر تحجيم الرندر إلى 70% وإلغاء قفل الفولتية لتبريد الجهاز فوراً"
        };

        for (int i = 0; i < 3; i++) {
            final int idx = i;
            final String modeName = pTitles[i];
            GradientDrawable itemBg = new GradientDrawable();
            itemBg.setCornerRadius((float) dp(12));

            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setBackground(itemBg);
            itemLayout.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            lp.setMargins(0, 0, 0, dp(8));
            itemLayout.setLayoutParams(lp);
            itemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedGpuProfile = idx;
                    prefs.edit().putInt("gpu_profile", idx).apply();
                    refreshGpuProfileStyles();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            NetPingHelper.optimizeGpuAndRam(MainActivity.this);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    refreshEngineerLabInfo();
                                }
                            });
                        }
                    }).start();
                    Toast.makeText(MainActivity.this, "تم تفعيل وتنفيذ: " + modeName, Toast.LENGTH_SHORT).show();
                }
            });

            TextView tTv = new TextView(this);
            tTv.setText(pTitles[i]);
            tTv.setTextColor(Color.WHITE);
            tTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            tTv.setTypeface(Typeface.DEFAULT_BOLD);

            TextView dTv = new TextView(this);
            dTv.setText(pDescs[i]);
            dTv.setTextColor(Color.parseColor("#94A3B8"));
            dTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            dTv.setPadding(0, dp(3), 0, 0);

            itemLayout.addView(tTv);
            itemLayout.addView(dTv);
            profileViews.add(itemLayout);
            profileCard.addView(itemLayout);
        }

        refreshGpuProfileStyles();
        col.addView(profileCard);

        scroll.addView(col);
        return scroll;
    }

    public ScrollView buildEngineerLabTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#080B12"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(15), dp(16), dp(15), dp(24));

        TextView title = new TextView(this);
        title.setText("🛠️ مختبر المهندس والنافذة العائمة V6");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(4));

        TextView sub = new TextView(this);
        sub.setText("لوحة تشخيص معمارية النظام، فحص مآخذ الشبكة (Sockets)، وسجل أوامر النواة الحقيقي + التحكم بالنافذة العائمة");
        sub.setTextColor(Color.parseColor("#94A3B8"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        sub.setPadding(0, 0, 0, dp(14));

        col.addView(title);
        col.addView(sub);

        // 1. بطاقة التشخيص الهندسي للعتاد والنظام
        LinearLayout archCard = createSleekCard("#101726", "#2563EB");
        TextView archTitle = new TextView(this);
        archTitle.setText("🔬 التشخيص الهندسي للمعمارية والعتاد (Hardware Telemetry)");
        archTitle.setTextColor(Color.parseColor("#38BDF8"));
        archTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        archTitle.setTypeface(Typeface.DEFAULT_BOLD);
        archTitle.setPadding(0, 0, 0, dp(8));
        archCard.addView(archTitle);

        engSpecsDetailTv = new TextView(this);
        engSpecsDetailTv.setTextColor(Color.parseColor("#E2E8F0"));
        engSpecsDetailTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        engSpecsDetailTv.setTypeface(Typeface.MONOSPACE);
        archCard.addView(engSpecsDetailTv);

        col.addView(archCard);

        // 2. بطاقة تشخيص مآخذ الشبكة والـ QoS
        LinearLayout netLabCard = createSleekCard("#141824", "#1E293B");
        TextView netLabTitle = new TextView(this);
        netLabTitle.setText("🌐 تشخيص طبقة الشبكة ومآخذ النواة (Kernel Network Stack)");
        netLabTitle.setTextColor(Color.parseColor("#10B981"));
        netLabTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        netLabTitle.setTypeface(Typeface.DEFAULT_BOLD);
        netLabTitle.setPadding(0, 0, 0, dp(8));
        netLabCard.addView(netLabTitle);

        engNetDetailTv = new TextView(this);
        engNetDetailTv.setTextColor(Color.parseColor("#E2E8F0"));
        engNetDetailTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        engNetDetailTv.setTypeface(Typeface.MONOSPACE);
        netLabCard.addView(engNetDetailTv);

        col.addView(netLabCard);

        // 3. سجل الأوامر المنفذة فعلياً في النواة (Kernel Shell Execution Log)
        LinearLayout logCard = createSleekCard("#0B0F17", "#334155");
        TextView logTitle = new TextView(this);
        logTitle.setText("💻 سجل أوامر النواة المنفذة (Kernel & ADB Shell Console)");
        logTitle.setTextColor(Color.parseColor("#FBBF24"));
        logTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        logTitle.setTypeface(Typeface.DEFAULT_BOLD);
        logTitle.setPadding(0, 0, 0, dp(8));
        logCard.addView(logTitle);

        engKernelLogTv = new TextView(this);
        engKernelLogTv.setText(ShizukuShellEngine.lastExecutedCommandsLog);
        engKernelLogTv.setTextColor(Color.parseColor("#34D399"));
        engKernelLogTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        engKernelLogTv.setTypeface(Typeface.MONOSPACE);
        logCard.addView(engKernelLogTv);

        col.addView(logCard);

        // 4. بطاقة التحكم بالنافذة العائمة وعلامة التصويب
        LinearLayout hudInfoCard = createSleekCard("#141824", "#1E293B");
        TextView hudTitle = new TextView(this);
        hudTitle.setText("🎯 كبسولة FPS الحقيقية وأدوات اللعب العائمة (Game Turbo HUD)");
        hudTitle.setTextColor(Color.WHITE);
        hudTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        hudTitle.setTypeface(Typeface.DEFAULT_BOLD);
        hudTitle.setPadding(0, 0, 0, dp(6));
        hudInfoCard.addView(hudTitle);

        String[] featuresList = new String[]{
            "🟢 قراءة الفريمات الحقيقية (SurfaceFlinger 1013 عبر Shizuku أو VSync Jank Analyzer)",
            "📡 عرض البنغ الفعلي الحقيقي لسيرفر المباراة النشط لحظة بلحظة",
            "🎯 4 أشكال احترافية لعلامة التصويب الثابتة (Crosshair) مع التحكم الفوري باللون والحجم",
            "🔒 ستارة قفل اللمس وتعتيم الشاشة (0.01f) لتبريد الجهاز ومنع اللمس الخاطئ"
        };
        for (int i = 0; i < featuresList.length; i++) {
            TextView tv = new TextView(this);
            tv.setText(featuresList[i]);
            tv.setTextColor(Color.parseColor("#CBD5E1"));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            tv.setPadding(0, dp(4), 0, dp(4));
            hudInfoCard.addView(tv);
        }

        hudInfoCard.addView(createFullWidthButton("🚀 تشغيل الكبسولة العائمة وعداد FPS الحقيقي الآن", "#10B981", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(false);
            }
        }));

        hudInfoCard.addView(createFullWidthButton("🛑 إيقاف النافذة العائمة واستعادة النظام", "#EF4444", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAllBoostServices();
            }
        }));

        col.addView(hudInfoCard);
        scroll.addView(col);
        return scroll;
    }

    public void refreshEngineerLabInfo() {
        long[] ram = HardwareProfiler.getRamStatsMb(this);
        int hz = HardwareProfiler.readDisplayRefreshRate(this);

        if (deviceRamChipTv != null) {
            deviceRamChipTv.setText("الرام الحرة: " + ram[0] + "MB");
        }
        if (deviceHzChipTv != null) {
            deviceHzChipTv.setText("الشاشة: " + hz + "Hz");
        }
        if (deviceTempChipTv != null) {
            deviceTempChipTv.setText("الحرارة: " + HardwareProfiler.getBatteryTempCelsius(this) + "°C");
        }

        if (engSpecsDetailTv != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("• الطراز: ").append(HardwareProfiler.getDeviceMarketingName())
              .append(" (").append(HardwareProfiler.getSafeStr(Build.DEVICE)).append(")\n");
            sb.append("• النظام: ").append(HardwareProfiler.getAndroidOsLabel()).append("\n");
            sb.append("• المعالج: ").append(HardwareProfiler.getSocAndAbiSummary()).append("\n");
            sb.append("• تردد الشاشة: ").append(hz).append(" Hz (VSync Frame Budget: ")
              .append(Math.round(1000.0f / (hz > 0 ? hz : 60))).append(" ms)\n");
            sb.append("• الذاكرة RAM: الحرة ").append(ram[0]).append(" MB / الإجمالية ")
              .append(ram[1]).append(" MB (المستخدمة ").append(ram[2]).append(" MB)\n");
            sb.append("• البطارية: ").append(HardwareProfiler.getBatteryTelemetrySummary(this)).append("\n");
            sb.append("• النواة: ").append(HardwareProfiler.getKernelVersionShort()).append("\n");
            sb.append("• حالة Shizuku: ").append(ShizukuShellEngine.getVerifiedKernelIdentity());
            engSpecsDetailTv.setText(sb.toString());
        }

        if (engNetDetailTv != null) {
            SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int netMode = prefs.getInt("net_mode", 0);
            int mtu = (netMode == 1) ? 1440 : 1360;
            StringBuilder nb = new StringBuilder();
            nb.append("• اللعبة المستهدفة: ").append(GameScannerEngine.getActiveGameName(this))
              .append(" [").append(GameScannerEngine.getActiveGamePackage(this)).append("]\n");
            nb.append("• الألعاب المكتشفة والمحمية: ").append(GameScannerEngine.cachedGames.size()).append(" لعبة\n");
            nb.append("• المسار النشط: ").append(NetPingHelper.activeServerLabel).append("\n");
            nb.append("• أسرع خادم DNS: ").append(NetPingHelper.fastestDnsServer)
              .append(" | حجم الحزمة MTU: ").append(mtu).append(" Bytes\n");
            nb.append("• أولوية الحزم: DSCP EF 46 (TOS 0xB8) | نبضات RRC Lock: 250ms (4Hz)\n");
            nb.append("• مآخذ UDP النشطة في النواة (/proc/net/udp): ").append(NetPingHelper.activeUdpSocketsCount).append(" مقبس");
            engNetDetailTv.setText(nb.toString());
        }

        if (engKernelLogTv != null) {
            engKernelLogTv.setText(ShizukuShellEngine.lastExecutedCommandsLog);
        }
    }

    public LinearLayout buildBottomNavBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#0D111C"));
        bar.setWeightSum(4f);
        bar.setPadding(0, dp(8), 0, dp(10));

        LinearLayout[] tab0Holder = new LinearLayout[1];
        navGamesLabel = createNavTabItem("🎮", "الألعاب والتعزيز", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(0);
            }
        }, tab0Holder);

        LinearLayout[] tab1Holder = new LinearLayout[1];
        navNetLabel = createNavTabItem("📡", "الشبكة والبنغ", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(1);
            }
        }, tab1Holder);

        LinearLayout[] tab2Holder = new LinearLayout[1];
        navGpuLabel = createNavTabItem("🔥", "النواة و GPU", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(2);
            }
        }, tab2Holder);

        LinearLayout[] tab3Holder = new LinearLayout[1];
        navEngLabel = createNavTabItem("🛠️", "مختبر المهندس", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshEngineerLabInfo();
                switchTab(3);
            }
        }, tab3Holder);

        bar.addView(tab0Holder[0]);
        bar.addView(tab1Holder[0]);
        bar.addView(tab2Holder[0]);
        bar.addView(tab3Holder[0]);
        return bar;
    }

    public TextView createNavTabItem(String icon, String label, View.OnClickListener onClick, LinearLayout[] boxOut) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        box.setOnClickListener(onClick);

        TextView iconTv = new TextView(this);
        iconTv.setText(icon);
        iconTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        iconTv.setGravity(Gravity.CENTER);

        TextView labelTv = new TextView(this);
        labelTv.setText(label);
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        labelTv.setTypeface(Typeface.DEFAULT_BOLD);
        labelTv.setGravity(Gravity.CENTER);
        labelTv.setPadding(0, dp(2), 0, 0);

        box.addView(iconTv);
        box.addView(labelTv);
        boxOut[0] = box;
        return labelTv;
    }

    public void switchTab(int index) {
        tabGamesBoostView.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        tabNetworkView.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        tabGpuView.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        tabEngineerView.setVisibility(index == 3 ? View.VISIBLE : View.GONE);

        int activeColor = Color.parseColor("#00F0FF");
        int inactiveColor = Color.parseColor("#64748B");

        navGamesLabel.setTextColor(index == 0 ? activeColor : inactiveColor);
        navNetLabel.setTextColor(index == 1 ? activeColor : inactiveColor);
        navGpuLabel.setTextColor(index == 2 ? activeColor : inactiveColor);
        navEngLabel.setTextColor(index == 3 ? activeColor : inactiveColor);
    }

    public void refreshShizukuBanner() {
        if (shizukuBannerTv == null) return;
        if (ShizukuShellEngine.hasShizukuPermission()) {
            String kernelId = ShizukuShellEngine.getVerifiedKernelIdentity();
            shizukuBannerTv.setText("🔥 متصل بنواة النظام (" + kernelId + ")\nأوامر Diablo + تحجيم GPU + عداد FPS الحقيقي مفعّلة بالكامل");
            shizukuBannerTv.setTextColor(Color.parseColor("#34D399"));
            shizukuActionBtn.setText("مفعّل ✓");
        } else if (ShizukuShellEngine.isShizukuAvailable()) {
            shizukuBannerTv.setText("⚡ خدمة Shizuku نشطة! اضغط لمنح صلاحية النواة الحقيقية (UID 2000)");
            shizukuBannerTv.setTextColor(Color.parseColor("#FBBF24"));
            shizukuActionBtn.setText("منح الصلاحية");
        } else {
            shizukuBannerTv.setText("💡 يعمل المعزز تلقائياً بوضع المحرك المحلي النشط • أو اربط Shizuku لتفعيل أوامر النواة (UID 2000)");
            shizukuBannerTv.setTextColor(Color.parseColor("#94A3B8"));
            shizukuActionBtn.setText("فتح Shizuku");
        }
    }

    public void handleShizukuButtonClick() {
        try {
            Shizuku.tryRequestBinderFromProvider(this);
            if (ShizukuShellEngine.hasShizukuPermission()) {
                String kernelId = ShizukuShellEngine.getVerifiedKernelIdentity();
                Toast.makeText(this, "🔥 صلاحيات Shizuku مفعّلة (" + kernelId + ")!", Toast.LENGTH_SHORT).show();
            } else if (ShizukuShellEngine.isShizukuAvailable()) {
                ShizukuShellEngine.requestPermission(SHIZUKU_REQ);
            } else {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) {
                    startActivity(launch);
                } else {
                    Toast.makeText(this, "المعزز يعمل بكفاءة بدون روت! ولتفعيل أوامر UID 2000 يمكنك تثبيت وتشغيل تطبيق Shizuku", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Throwable ignored) {}
    }

    public void refreshNetModePills() {
        if (pill4GView != null) styleModePill(pill4GView, currentNetMode == 0);
        if (pillAdslView != null) styleModePill(pillAdslView, currentNetMode == 1);
    }

    public void refreshGpuProfileStyles() {
        for (int i = 0; i < profileViews.size(); i++) {
            LinearLayout view = profileViews.get(i);
            Drawable d = view.getBackground();
            if (d instanceof GradientDrawable) {
                GradientDrawable bg = (GradientDrawable) d;
                if (i == selectedGpuProfile) {
                    bg.setColor(Color.parseColor("#172B4D"));
                    bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
                } else {
                    bg.setColor(Color.parseColor("#10141D"));
                    bg.setStroke(dp(1), Color.parseColor("#1F2637"));
                }
            }
        }
    }

    public TextView createMiniHwChip(String text, String colorHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#0B0F19"));
        bg.setCornerRadius((float) dp(10));
        bg.setStroke(dp(1), Color.parseColor("#1E293B"));

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    public TextView createHeaderSmallButton(String text, String bgHex, String strokeHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(10));
        bg.setStroke(dp(1), Color.parseColor(strokeHex));

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(strokeHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(10), dp(5), dp(10), dp(5));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(4), 0, 0, 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public LinearLayout createSleekCard(String bgHex, String strokeHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(18));
        bg.setStroke(dp(1), Color.parseColor(strokeHex));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(bg);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        return card;
    }

    public TextView createMetricBox(String label, String initialValue, String valueColorHex, LinearLayout[] boxOut) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#0B0F19"));
        bg.setCornerRadius((float) dp(12));
        bg.setStroke(dp(1), Color.parseColor("#1F2637"));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackground(bg);
        box.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        box.setLayoutParams(lp);

        TextView valTv = new TextView(this);
        valTv.setText(initialValue);
        valTv.setTextColor(Color.parseColor(valueColorHex));
        valTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        valTv.setTypeface(Typeface.DEFAULT_BOLD);
        valTv.setGravity(Gravity.CENTER);

        TextView lblTv = new TextView(this);
        lblTv.setText(label);
        lblTv.setTextColor(Color.parseColor("#94A3B8"));
        lblTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        lblTv.setGravity(Gravity.CENTER);
        lblTv.setPadding(0, dp(3), 0, 0);

        box.addView(valTv);
        box.addView(lblTv);
        boxOut[0] = box;
        return valTv;
    }

    public TextView createModePill(String title, View.OnClickListener onClick) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public void styleModePill(TextView tv, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(12));
        if (selected) {
            bg.setColor(Color.parseColor("#172B4D"));
            bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
        } else {
            bg.setColor(Color.parseColor("#0E121B"));
            bg.setStroke(dp(1), Color.parseColor("#1F2637"));
        }
        tv.setBackground(bg);
        tv.setTextColor(selected ? Color.parseColor("#00F0FF") : Color.parseColor("#94A3B8"));
    }

    public void applyTogglePillStyle(TextView pillBtn, boolean state) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(14));
        if (state) {
            bg.setColor(Color.parseColor("#064E3B"));
            bg.setStroke(dp(1), Color.parseColor("#10B981"));
        } else {
            bg.setColor(Color.parseColor("#1E293B"));
            bg.setStroke(dp(1), Color.parseColor("#475569"));
        }
        pillBtn.setBackground(bg);
        pillBtn.setText(state ? "مفعّل ✓" : "متوقف");
        pillBtn.setTextColor(state ? Color.parseColor("#34D399") : Color.parseColor("#94A3B8"));
    }

    public LinearLayout createModernToggleRow(
        String title,
        String subtitle,
        final boolean initialState,
        final ToggleCallback callback
    ) {
        final int[] stateHolder = new int[]{initialState ? 1 : 0};
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        textCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        textCol.setPadding(0, 0, dp(10), 0);

        TextView tTv = new TextView(this);
        tTv.setText(title);
        tTv.setTextColor(Color.WHITE);
        tTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tTv.setTypeface(Typeface.DEFAULT_BOLD);

        TextView sTv = new TextView(this);
        sTv.setText(subtitle);
        sTv.setTextColor(Color.parseColor("#94A3B8"));
        sTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        sTv.setPadding(0, dp(2), 0, 0);

        textCol.addView(tTv);
        textCol.addView(sTv);

        final TextView pillBtn = new TextView(this);
        pillBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        pillBtn.setTypeface(Typeface.DEFAULT_BOLD);
        pillBtn.setGravity(Gravity.CENTER);
        pillBtn.setPadding(dp(12), dp(6), dp(12), dp(6));

        applyTogglePillStyle(pillBtn, stateHolder[0] != 0);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stateHolder[0] = (stateHolder[0] == 0) ? 1 : 0;
                applyTogglePillStyle(pillBtn, stateHolder[0] != 0);
                callback.onToggled(stateHolder[0] != 0);
            }
        });
        row.addView(textCol);
        row.addView(pillBtn);
        return row;
    }

    public TextView createActionButton(String title, String bgHex, String textHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(14));
        bg.setStroke(dp(1), Color.parseColor(textHex));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.parseColor(textHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(10), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public TextView createFullWidthButton(String title, String bgHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(14));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(12), 0, 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public void showRegionSelectorDialog() {
        try {
            final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int current = prefs.getInt("region_index", 0);
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("اختر منطقة خادم الألعاب")
                .setSingleChoiceItems(NetPingHelper.SERVER_REGIONS, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putInt("region_index", which).apply();
                        regionValueTv.setText(NetPingHelper.SERVER_REGIONS[which] + "  ‹");
                        dialog.dismiss();
                        refreshLiveMetrics();
                    }
                })
                .show();
        } catch (Throwable ignored) {}
    }

    public void showDownscaleSelectorDialog() {
        try {
            final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int current = prefs.getInt("downscale_index", 0);
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("تحجيم دقة المعالج الرسومي (GPU Scaling)")
                .setSingleChoiceItems(NetPingHelper.DOWNSCALE_MODES, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putInt("downscale_index", which).apply();
                        downscaleValueTv.setText(NetPingHelper.getDownscaleRatioValue(which) + "x Esports  ‹");
                        dialog.dismiss();
                    }
                })
                .show();
        } catch (Throwable ignored) {}
    }

    public void refreshLiveMetrics() {
        long[] ram = HardwareProfiler.getRamStatsMb(this);
        if (gpuRamFreeTv != null) {
            gpuRamFreeTv.setText(ram[0] + " MB");
        }
        float tempC = HardwareProfiler.getBatteryTempCelsius(this);
        if (gpuTempTv != null) {
            gpuTempTv.setText(tempC + " °C");
        }
        if (deviceRamChipTv != null) {
            deviceRamChipTv.setText("الرام الحرة: " + ram[0] + "MB");
        }
        if (deviceTempChipTv != null) {
            deviceTempChipTv.setText("الحرارة: " + tempC + "°C");
        }

        if (livePingGaugeTv != null) {
            livePingGaugeTv.setText("جاري القياس...");
        }
        final int region = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("region_index", 0);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int ping = NetPingHelper.measureTrueGamePing(region);
                final int jitter = NetPingHelper.lastJitter;
                final int loss = NetPingHelper.lastPacketLoss;
                final String srvLabel = NetPingHelper.activeServerLabel;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (livePingGaugeTv != null) {
                            livePingGaugeTv.setText(ping + " ms");
                            String color;
                            if (ping < 65) {
                                color = "#10B981";
                            } else if (ping < 95) {
                                color = "#F59E0B";
                            } else {
                                color = "#EF4444";
                            }
                            livePingGaugeTv.setTextColor(Color.parseColor(color));
                        }
                        if (liveJitterTv != null) {
                            liveJitterTv.setText(jitter + " ms");
                        }
                        if (liveHitRegTv != null) {
                            liveHitRegTv.setText(loss + "% (" + (loss == 0 ? "ثابت" : "متذبذب") + ")");
                        }
                        if (activeServerSubTv != null) {
                            activeServerSubTv.setText("المسار النشط: " + srvLabel);
                        }
                        refreshEngineerLabInfo();
                    }
                });
            }
        }).start();
    }

    public void startFullBoostSequence(boolean launchGame) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "يرجى منح صلاحية الظهور فوق التطبيقات لتشغيل عداد الفريمات الحقيقي", Toast.LENGTH_LONG).show();
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_REQ);
            } catch (Throwable ignored) {}
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                NetPingHelper.optimizeGpuAndRam(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshEngineerLabInfo();
                    }
                });
            }
        }).start();
        NetPingHelper.enableUltraNetworkAndHitRegEngine(this);

        try {
            Intent hudIntent = new Intent(this, FloatingBoosterService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(hudIntent);
            } else {
                startService(hudIntent);
            }
        } catch (Throwable ignored) {}

        SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (prefs.getBoolean("isolate_bg", true)) {
            try {
                Intent prep = VpnService.prepare(this);
                if (prep != null) {
                    startActivityForResult(prep, VPN_REQ);
                    return;
                } else {
                    startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_START));
                }
            } catch (Throwable ignored) {}
        }

        isBoosting = true;
        mainBoostBtn.setText("مُعزّز ✓");
        String targetGameName = GameScannerEngine.getActiveGameName(this);
        if (ShizukuShellEngine.hasShizukuPermission()) {
            boostStatusSubTv.setText("🔥 وضع Shizuku Diablo نشط لـ " + targetGameName + " + عداد FPS الحقيقي");
        } else {
            boostStatusSubTv.setText("⚡ تم تعزيز " + targetGameName + " وتفعيل مانع الدمج الوهمي 250ms");
        }
        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"));

        if (launchGame) {
            final boolean autoExit = prefs.getBoolean("zero_ram_exit", false);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    launchSelectedGameAndFreeRam(autoExit);
                }
            }, 350L);
        } else {
            refreshLiveMetrics();
        }
    }

    public void launchSelectedGameAndFreeRam(boolean autoCloseActivity) {
        String activePkg = GameScannerEngine.getActiveGamePackage(this);
        String activeName = GameScannerEngine.getActiveGameName(this);
        try {
            if (activePkg != null && activePkg.length() > 0) {
                Intent launch = getPackageManager().getLaunchIntentForPackage(activePkg);
                if (launch != null) {
                    Toast.makeText(this, "🚀 جاري تشغيل " + activeName + " بأقصى أداء!", Toast.LENGTH_SHORT).show();
                    startActivity(launch);
                    if (autoCloseActivity) {
                        finish();
                    }
                    return;
                }
            }
        } catch (Throwable ignored) {}
        Toast.makeText(this, "⚡ المعزز وعداد الفريمات الحقيقي يعملان الآن! افتح لعبتك المفضلة", Toast.LENGTH_LONG).show();
    }

    public void stopAllBoostServices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ShizukuShellEngine.restoreNormalSystemState();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshEngineerLabInfo();
                    }
                });
            }
        }).start();
        try {
            stopService(new Intent(this, FloatingBoosterService.class));
        } catch (Throwable ignored) {}
        try {
            stopService(new Intent(this, GuardVpnService.class));
        } catch (Throwable ignored) {}
        NetPingHelper.disableUltraNetworkEngine();
        isBoosting = false;
        mainBoostBtn.setText("🚀 تعزيز وتشغيل");
        boostStatusSubTv.setText("تم إيقاف المعزز واستعادة إعدادات النظام الطبيعية");
        boostStatusSubTv.setTextColor(Color.parseColor("#94A3B8"));
        Toast.makeText(this, "🛑 تم إيقاف المعزز واستعادة إعدادات النظام بالكامل", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQ && resultCode == RESULT_OK) {
            try {
                startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_START));
            } catch (Throwable ignored) {}
            SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            launchSelectedGameAndFreeRam(prefs.getBoolean("zero_ram_exit", false));
        } else if (requestCode == OVERLAY_REQ && Settings.canDrawOverlays(this)) {
            startFullBoostSequence(false);
        }
    }
}
