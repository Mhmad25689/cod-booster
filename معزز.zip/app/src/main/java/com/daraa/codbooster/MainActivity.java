package com.daraa.codbooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    public static final int VPN_REQ = 2001;
    public static final int OVERLAY_REQ = 2002;
    public static final int SHIZUKU_REQ = 2003;
    public static final String PREFS = "hyperboost_prefs";

    public interface ToggleCallback {
        void onToggled(boolean enabled);
    }

    public FrameLayout contentFrame;
    public ScrollView tabBoostView;
    public ScrollView tabGpuView;
    public ScrollView tabHudView;

    public TextView navBoostLabel;
    public TextView navGpuLabel;
    public TextView navHudLabel;

    public TextView shizukuBannerTv;
    public TextView shizukuActionBtn;

    public TextView regionValueTv;
    public TextView downscaleValueTv;
    public TextView activeServerSubTv;
    public TextView livePingGaugeTv;
    public TextView liveJitterTv;
    public TextView liveHitRegTv;
    public TextView boostStatusSubTv;
    public TextView mainBoostBtn;

    public TextView pill4GView = null;
    public TextView pillAdslView = null;
    public int currentNetMode = 0;

    public TextView gpuRamFreeTv;
    public TextView gpuTempTv;
    public final List<LinearLayout> profileViews = new ArrayList<LinearLayout>();
    public int selectedGpuProfile = 0;

    public final Handler handler = new Handler(Looper.getMainLooper());
    public boolean isBoosting = false;

    public final Shizuku.OnRequestPermissionResultListener shizukuPermListener =
        new Shizuku.OnRequestPermissionResultListener() {
            @Override
            public void onRequestPermissionResult(int requestCode, final int grantResult) {
                if (requestCode == SHIZUKU_REQ) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshShizukuBanner();
                            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                                String kernelId = ShizukuShellEngine.getVerifiedKernelIdentity();
                                Toast.makeText(
                                    MainActivity.this,
                                    "🔥 تم تفعيل صلاحيات Shizuku الحقيقية (" + kernelId + ") بنجاح!",
                                    Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    });
                }
            }
        };

    public int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            (float) value,
            getResources().getDisplayMetrics()
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#090B10"));
        getWindow().setNavigationBarColor(Color.parseColor("#0E111A"));

        try {
            Shizuku.tryRequestBinderFromProvider(this);
            Shizuku.addRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignored) {}

        NetPingHelper.prewarmCodLoginAndMatchmakingServers();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#090B10"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        contentFrame = new FrameLayout(this);
        contentFrame.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ));

        tabBoostView = buildGearUpBoostTab();
        tabGpuView = buildGpuEngineTab();
        tabHudView = buildHudStudioTab();

        contentFrame.addView(tabBoostView);
        contentFrame.addView(tabGpuView);
        contentFrame.addView(tabHudView);

        root.addView(contentFrame);
        root.addView(buildBottomNavBar());

        setContentView(root);
        switchTab(0);
        refreshShizukuBanner();
        refreshLiveMetrics();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            Shizuku.tryRequestBinderFromProvider(this);
        } catch (Throwable ignored) {}
        refreshShizukuBanner();
        refreshLiveMetrics();
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    public ScrollView buildGearUpBoostTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        currentNetMode = prefs.getInt("net_mode", 0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#090B10"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(24));

        RelativeLayout topBar = new RelativeLayout(this);
        topBar.setPadding(0, 0, 0, dp(14));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("معزز الألعاب الخارق");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19.5f);
        headerTitle.setTypeface(Typeface.DEFAULT_BOLD);
        RelativeLayout.LayoutParams hLp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        hLp.addRule(RelativeLayout.CENTER_IN_PARENT);
        headerTitle.setLayoutParams(hLp);

        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#2A1219"));
        badgeBg.setCornerRadius((float) dp(12));
        badgeBg.setStroke(dp(1), Color.parseColor("#F43F5E"));

        TextView editionBadge = new TextView(this);
        editionBadge.setText("🔥 V5 ULTRA");
        editionBadge.setTextColor(Color.parseColor("#FB7185"));
        editionBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        editionBadge.setTypeface(Typeface.DEFAULT_BOLD);
        editionBadge.setBackground(badgeBg);
        editionBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        RelativeLayout.LayoutParams bLp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        bLp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        bLp.addRule(RelativeLayout.CENTER_VERTICAL);
        editionBadge.setLayoutParams(bLp);

        topBar.addView(headerTitle);
        topBar.addView(editionBadge);
        col.addView(topBar);

        // بطاقة صلاحيات Shizuku الحقيقية (Binder IPC مباشر)
        LinearLayout shizukuCard = createSleekCard("#12192B", "#2563EB");
        LinearLayout shizukuRow = new LinearLayout(this);
        shizukuRow.setOrientation(LinearLayout.HORIZONTAL);
        shizukuRow.setGravity(Gravity.CENTER_VERTICAL);

        shizukuBannerTv = new TextView(this);
        shizukuBannerTv.setText("⚡ جاري فحص اتصال نواة Shizuku (UID 2000)...");
        shizukuBannerTv.setTextColor(Color.WHITE);
        shizukuBannerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        shizukuBannerTv.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuBannerTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        shizukuBannerTv.setPadding(0, 0, dp(8), 0);

        GradientDrawable shizukuBtnBg = new GradientDrawable();
        shizukuBtnBg.setColor(Color.parseColor("#2563EB"));
        shizukuBtnBg.setCornerRadius((float) dp(14));

        shizukuActionBtn = new TextView(this);
        shizukuActionBtn.setText("ربط Shizuku");
        shizukuActionBtn.setTextColor(Color.WHITE);
        shizukuActionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        shizukuActionBtn.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuActionBtn.setBackground(shizukuBtnBg);
        shizukuActionBtn.setPadding(dp(14), dp(7), dp(14), dp(7));
        shizukuActionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleShizukuButtonClick();
            }
        });

        shizukuRow.addView(shizukuBannerTv);
        shizukuRow.addView(shizukuActionBtn);
        shizukuCard.addView(shizukuRow);
        col.addView(shizukuCard);

        // بطاقة Call of Duty Mobile
        LinearLayout codCard = createSleekCard("#141822", "#1E2536");
        LinearLayout gameRow = new LinearLayout(this);
        gameRow.setOrientation(LinearLayout.HORIZONTAL);
        gameRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView gameIconView = new ImageView(this);
        gameIconView.setImageDrawable(loadCodIcon());
        gameIconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        gameIconView.setLayoutParams(new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, dp(12), 0);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView gameTitleTv = new TextView(this);
        gameTitleTv.setText("Call of Duty®: Mobile");
        gameTitleTv.setTextColor(Color.WHITE);
        gameTitleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f);
        gameTitleTv.setTypeface(Typeface.DEFAULT_BOLD);

        boostStatusSubTv = new TextView(this);
        boostStatusSubTv.setText("مسار مباشر <60ms + إيقاف GOS + منع الدمج الوهمي");
        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"));
        boostStatusSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        boostStatusSubTv.setPadding(0, dp(3), 0, 0);

        titleCol.addView(gameTitleTv);
        titleCol.addView(boostStatusSubTv);

        GradientDrawable boostPillBg = new GradientDrawable();
        boostPillBg.setColor(Color.parseColor("#172B4D"));
        boostPillBg.setCornerRadius((float) dp(20));
        boostPillBg.setStroke(dp(1), Color.parseColor("#2563EB"));

        mainBoostBtn = new TextView(this);
        mainBoostBtn.setText("تعزيز خارق");
        mainBoostBtn.setTextColor(Color.parseColor("#60A5FA"));
        mainBoostBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        mainBoostBtn.setTypeface(Typeface.DEFAULT_BOLD);
        mainBoostBtn.setGravity(Gravity.CENTER);
        mainBoostBtn.setBackground(boostPillBg);
        mainBoostBtn.setPadding(dp(16), dp(9), dp(16), dp(9));
        mainBoostBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(true);
            }
        });

        gameRow.addView(gameIconView);
        gameRow.addView(titleCol);
        gameRow.addView(mainBoostBtn);
        codCard.addView(gameRow);

        View divider1 = new View(this);
        divider1.setBackgroundColor(Color.parseColor("#1F2637"));
        LinearLayout.LayoutParams d1Lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        d1Lp.setMargins(0, dp(14), 0, dp(12));
        divider1.setLayoutParams(d1Lp);
        codCard.addView(divider1);

        LinearLayout regionRow = new LinearLayout(this);
        regionRow.setOrientation(LinearLayout.HORIZONTAL);
        regionRow.setGravity(Gravity.CENTER_VERTICAL);
        regionRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRegionSelectorDialog();
            }
        });

        TextView regionLabelTv = new TextView(this);
        regionLabelTv.setText("منطقة الخادم والمسار");
        regionLabelTv.setTextColor(Color.parseColor("#94A3B8"));
        regionLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        regionLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        int savedRegion = prefs.getInt("region_index", 0);
        regionValueTv = new TextView(this);
        regionValueTv.setText(NetPingHelper.SERVER_REGIONS[savedRegion] + "  ‹");
        regionValueTv.setTextColor(Color.parseColor("#E2E8F0"));
        regionValueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        regionValueTv.setTypeface(Typeface.DEFAULT_BOLD);

        regionRow.addView(regionLabelTv);
        regionRow.addView(regionValueTv);
        codCard.addView(regionRow);

        View divider2 = new View(this);
        divider2.setBackgroundColor(Color.parseColor("#1F2637"));
        LinearLayout.LayoutParams d2Lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        d2Lp.setMargins(0, dp(12), 0, dp(12));
        divider2.setLayoutParams(d2Lp);
        codCard.addView(divider2);

        LinearLayout downscaleRow = new LinearLayout(this);
        downscaleRow.setOrientation(LinearLayout.HORIZONTAL);
        downscaleRow.setGravity(Gravity.CENTER_VERTICAL);
        downscaleRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDownscaleSelectorDialog();
            }
        });

        TextView downscaleLabelTv = new TextView(this);
        downscaleLabelTv.setText("دقة رندر Mali GPU (عبر Shizuku)");
        downscaleLabelTv.setTextColor(Color.parseColor("#38BDF8"));
        downscaleLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        downscaleLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        int savedDownscale = prefs.getInt("downscale_index", 0);
        downscaleValueTv = new TextView(this);
        downscaleValueTv.setText(NetPingHelper.getDownscaleRatioValue(savedDownscale) + "x Esports  ‹");
        downscaleValueTv.setTextColor(Color.parseColor("#00F0FF"));
        downscaleValueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        downscaleValueTv.setTypeface(Typeface.DEFAULT_BOLD);

        downscaleRow.addView(downscaleLabelTv);
        downscaleRow.addView(downscaleValueTv);
        codCard.addView(downscaleRow);

        col.addView(codCard);

        // بطاقة القياس الحقيقي للبنغ والتذبذب
        LinearLayout telemetryCard = createSleekCard("#141822", "#1E2536");
        LinearLayout teleHeader = new LinearLayout(this);
        teleHeader.setOrientation(LinearLayout.HORIZONTAL);
        teleHeader.setGravity(Gravity.CENTER_VERTICAL);
        teleHeader.setPadding(0, 0, 0, dp(6));

        TextView teleTitle = new TextView(this);
        teleTitle.setText("📡 القياس الفعلي الحقيقي لبنغ الخوادم (بدون أرقام وهمية)");
        teleTitle.setTextColor(Color.parseColor("#E2E8F0"));
        teleTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        teleTitle.setTypeface(Typeface.DEFAULT_BOLD);
        teleTitle.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView refreshBtn = new TextView(this);
        refreshBtn.setText("فحص حي ↻");
        refreshBtn.setTextColor(Color.parseColor("#38BDF8"));
        refreshBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        refreshBtn.setTypeface(Typeface.DEFAULT_BOLD);
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshLiveMetrics();
            }
        });

        teleHeader.addView(teleTitle);
        teleHeader.addView(refreshBtn);
        telemetryCard.addView(teleHeader);

        activeServerSubTv = new TextView(this);
        activeServerSubTv.setText("المسار النشط: " + NetPingHelper.activeServerLabel);
        activeServerSubTv.setTextColor(Color.parseColor("#94A3B8"));
        activeServerSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        activeServerSubTv.setPadding(0, 0, 0, dp(10));
        telemetryCard.addView(activeServerSubTv);

        LinearLayout metricsGrid = new LinearLayout(this);
        metricsGrid.setOrientation(LinearLayout.HORIZONTAL);
        metricsGrid.setWeightSum(3f);

        LinearLayout[] box1Holder = new LinearLayout[1];
        livePingGaugeTv = createMetricBox("البنغ الحقيقي الفعلي", "-- ms", "#10B981", box1Holder);

        LinearLayout[] box2Holder = new LinearLayout[1];
        liveJitterTv = createMetricBox("التذبذب الفعلي Jitter", "-- ms", "#38BDF8", box2Holder);

        LinearLayout[] box3Holder = new LinearLayout[1];
        liveHitRegTv = createMetricBox("فقدان الحزم Loss", "0%", "#A855F7", box3Holder);

        metricsGrid.addView(box1Holder[0]);
        metricsGrid.addView(box2Holder[0]);
        metricsGrid.addView(box3Holder[0]);
        telemetryCard.addView(metricsGrid);
        col.addView(telemetryCard);

        // بطاقة إعدادات الشبكة والتفوق على GearUP
        LinearLayout netConfigCard = createSleekCard("#141822", "#1E2536");
        TextView netSectionTitle = new TextView(this);
        netSectionTitle.setText("⚙️ محركات تثبيت البنغ <60ms ومنع الدمج الوهمي");
        netSectionTitle.setTextColor(Color.WHITE);
        netSectionTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        netSectionTitle.setTypeface(Typeface.DEFAULT_BOLD);
        netSectionTitle.setPadding(0, 0, 0, dp(10));
        netConfigCard.addView(netSectionTitle);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setWeightSum(2f);
        LinearLayout.LayoutParams mRowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        mRowLp.setMargins(0, 0, 0, dp(12));
        modeRow.setLayoutParams(mRowLp);

        pill4GView = createModePill("📶 بيانات 4G سيريتل/MTN (MTU 1360)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentNetMode = 0;
                prefs.edit().putInt("net_mode", 0).apply();
                refreshNetModePills();
            }
        });
        pillAdslView = createModePill("🏠 راوتر ADSL/فايبر (MTU 1440)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentNetMode = 1;
                prefs.edit().putInt("net_mode", 1).apply();
                refreshNetModePills();
            }
        });
        refreshNetModePills();
        modeRow.addView(pill4GView);
        modeRow.addView(pillAdslView);
        netConfigCard.addView(modeRow);

        netConfigCard.addView(createModernToggleRow(
            "إيقاف خنق سامسونج الحراري (Kill GOS & SDHMS)",
            "تجميد خدمات الخنق الحراري عبر Shizuku ومنع هبوط الفريمات في الباتل رويال",
            prefs.getBoolean("kill_gos", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("kill_gos", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "مانع الدمج الوهمي الحقيقي (250ms RRC Radio Lock)",
            "نبضات DSCP EF بتردد 4Hz لمنع خمول برج الـ 4G والراوتر أثناء المواجهات",
            prefs.getBoolean("hit_reg_boost", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("hit_reg_boost", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "توجيه مباشر أسرع من GearUP (Zero-Overhead Route)",
            "توصيل كود موبايل مباشرة بالخادم بدون تشفير VPN يبطئ خط الإنترنت في سوريا",
            prefs.getBoolean("fast_login", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("fast_login", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "عزل إنترنت الخلفية المزدوج (Kernel + Split-VPN)",
            "قطع الإنترنت كلياً عن واتساب وفيسبوك وتيك توك مع استثناء كود موبايل 100%",
            prefs.getBoolean("isolate_bg", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("isolate_bg", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "وضع صفر رام (إغلاق واجهة المعزز فور فتح اللعبة)",
            "تحرير كامل الرام لـ كود موبايل وإبقاء كبسولة الفريمات والبنغ الخفيفة فقط",
            prefs.getBoolean("zero_ram_exit", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("zero_ram_exit", enabled).apply();
                }
            }
        ));

        col.addView(netConfigCard);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setWeightSum(2f);

        TextView btnHudOnly = createActionButton("🎮 تشغيل عداد FPS العائم فقط", "#1E293B", "#38BDF8", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(false);
            }
        });
        TextView btnStopAll = createActionButton("🛑 إيقاف المعزز واستعادة النظام", "#2A1219", "#F87171", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAllBoostServices();
            }
        });
        actionRow.addView(btnHudOnly);
        actionRow.addView(btnStopAll);
        col.addView(actionRow);

        scroll.addView(col);
        return scroll;
    }

    public void refreshShizukuBanner() {
        if (shizukuBannerTv == null) return;
        if (ShizukuShellEngine.hasShizukuPermission()) {
            String kernelId = ShizukuShellEngine.getVerifiedKernelIdentity();
            shizukuBannerTv.setText("🔥 متصل بنواة النظام (" + kernelId + ")\nأوامر Diablo + تحجيم GPU + عداد FPS الحقيقي مفعّلة بالكامل");
            shizukuBannerTv.setTextColor(Color.parseColor("#34D399"));
            shizukuActionBtn.setText("مفعّل ✓");
        } else if (ShizukuShellEngine.isShizukuAvailable()) {
            shizukuBannerTv.setText("⚡ خدمة Shizuku نشطة! اضغط لمنح صلاحية النواة الحقيقية بدون أخطاء");
            shizukuBannerTv.setTextColor(Color.parseColor("#FBBF24"));
            shizukuActionBtn.setText("منح الصلاحية");
        } else {
            shizukuBannerTv.setText("💡 شغّل تطبيق Shizuku لتفعيل صلاحيات النواة الكاملة (UID 2000) والتفوق على معزز سامسونج و RedMagic");
            shizukuBannerTv.setTextColor(Color.parseColor("#94A3B8"));
            shizukuActionBtn.setText("فتح Shizuku");
        }
    }

    public void handleShizukuButtonClick() {
        Shizuku.tryRequestBinderFromProvider(this);
        if (ShizukuShellEngine.hasShizukuPermission()) {
            String kernelId = ShizukuShellEngine.getVerifiedKernelIdentity();
            Toast.makeText(this, "🔥 صلاحيات Shizuku مفعّلة (" + kernelId + ")!", Toast.LENGTH_SHORT).show();
        } else if (ShizukuShellEngine.isShizukuAvailable()) {
            ShizukuShellEngine.requestPermission(SHIZUKU_REQ);
        } else {
            Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (launch != null) {
                startActivity(launch);
            } else {
                Toast.makeText(this, "افتح تطبيق Shizuku وشغّل الخدمة (Start) ثم ارجع واضغط ربط Shizuku", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void refreshNetModePills() {
        if (pill4GView != null) styleModePill(pill4GView, currentNetMode == 0);
        if (pillAdslView != null) styleModePill(pillAdslView, currentNetMode == 1);
    }

    public ScrollView buildGpuEngineTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        selectedGpuProfile = prefs.getInt("gpu_profile", 0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#090B10"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(24));

        TextView title = new TextView(this);
        title.setText("محرك RedMagic Diablo & Shizuku GPU V5");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(6));

        TextView sub = new TextView(this);
        sub.setText("يتفوق على معزز سامسونج وريدمي وريد ماجيك: يتحكم مباشرة بـ SurfaceFlinger و GameManagerService وأولوية المعالج");
        sub.setTextColor(Color.parseColor("#94A3B8"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        sub.setPadding(0, 0, 0, dp(16));

        col.addView(title);
        col.addView(sub);

        LinearLayout hwCard = createSleekCard("#141822", "#1E2536");
        LinearLayout hwRow = new LinearLayout(this);
        hwRow.setOrientation(LinearLayout.HORIZONTAL);
        hwRow.setWeightSum(2f);

        LinearLayout[] ramBoxHolder = new LinearLayout[1];
        gpuRamFreeTv = createMetricBox("الرام الحرة الفعلية", "-- MB", "#00F0FF", ramBoxHolder);

        LinearLayout[] tempBoxHolder = new LinearLayout[1];
        gpuTempTv = createMetricBox("حرارة البطارية الفعلية", "-- °C", "#10B981", tempBoxHolder);

        hwRow.addView(ramBoxHolder[0]);
        hwRow.addView(tempBoxHolder[0]);
        hwCard.addView(hwRow);

        TextView flushBtn = createFullWidthButton("🔥 تطبيق وضع النواة المختار وتحرير الرام الآن", "#2563EB", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final long freed = NetPingHelper.optimizeGpuAndRam(MainActivity.this);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshLiveMetrics();
                                String msg = ShizukuShellEngine.hasShizukuPermission()
                                    ? "🔥 تم تنفيذ أوامر Shizuku الحقيقية وإيقاف GOS وتفريغ الخلفية بنجاح!"
                                    : "⚡ تم تنظيف العمليات الخلفية (" + (freed > 0 ? ("تم تحرير " + freed + " MB") : "الذاكرة في أقصى سعة") + ")";
                                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }).start();
            }
        });
        hwCard.addView(flushBtn);
        col.addView(hwCard);

        LinearLayout profileCard = createSleekCard("#141822", "#1E2536");
        TextView profTitle = new TextView(this);
        profTitle.setText("🎛️ أوضاع النواة الحقيقية (كل وضع ينفذ أوامر نظام مختلفة)");
        profTitle.setTextColor(Color.WHITE);
        profTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        profTitle.setTypeface(Typeface.DEFAULT_BOLD);
        profTitle.setPadding(0, 0, 0, dp(10));
        profileCard.addView(profTitle);

        profileViews.clear();
        String[] pTitles = new String[]{
            "🔥 وضع Diablo الخارق (أقصى فريمات + أولوية CPU -20)",
            "⚖️ وضع Rise المتوازن (ثبات 60/90 FPS للمباريات الطويلة)",
            "❄️ وضع التبريد الفائق (تحجيم 70% لمنع السخونة والهبوط الحراري)"
        };
        String[] pDescs = new String[]{
            "يقفل ترددات النواة Fixed Performance، يلغي خنق GOS و SDHMS، يفعل مسار SurfaceFlinger السريع، ويرفع أولوية كود موبايل إلى -20",
            "يضبط تحجيم الرندر على 85% مع تجميد GOS في الخلفية والحفاظ على توازن حرارة Galaxy A07 في الباتل رويال",
            "يخفض عبء معالج Mali GPU بنسبة 45% عبر تحجيم الرندر إلى 70% وإيقاف قفل الفولتية لتبريد الهاتف فوراً"
        };

        for (int i = 0; i < 3; i++) {
            final int idx = i;
            final String modeName = pTitles[i];
            GradientDrawable itemBg = new GradientDrawable();
            itemBg.setCornerRadius((float) dp(12));

            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setBackground(itemBg);
            itemLayout.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            lp.setMargins(0, 0, 0, dp(8));
            itemLayout.setLayoutParams(lp);
            itemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedGpuProfile = idx;
                    prefs.edit().putInt("gpu_profile", idx).apply();
                    refreshGpuProfileStyles();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            NetPingHelper.optimizeGpuAndRam(MainActivity.this);
                        }
                    }).start();
                    Toast.makeText(MainActivity.this, "تم تفعيل وتنفيذ: " + modeName, Toast.LENGTH_SHORT).show();
                }
            });

            TextView tTv = new TextView(this);
            tTv.setText(pTitles[i]);
            tTv.setTextColor(Color.WHITE);
            tTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            tTv.setTypeface(Typeface.DEFAULT_BOLD);

            TextView dTv = new TextView(this);
            dTv.setText(pDescs[i]);
            dTv.setTextColor(Color.parseColor("#94A3B8"));
            dTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            dTv.setPadding(0, dp(3), 0, 0);

            itemLayout.addView(tTv);
            itemLayout.addView(dTv);
            profileViews.add(itemLayout);
            profileCard.addView(itemLayout);
        }

        refreshGpuProfileStyles();
        col.addView(profileCard);

        scroll.addView(col);
        return scroll;
    }

    public void refreshGpuProfileStyles() {
        for (int i = 0; i < profileViews.size(); i++) {
            LinearLayout view = profileViews.get(i);
            Drawable d = view.getBackground();
            if (d instanceof GradientDrawable) {
                GradientDrawable bg = (GradientDrawable) d;
                if (i == selectedGpuProfile) {
                    bg.setColor(Color.parseColor("#172B4D"));
                    bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
                } else {
                    bg.setColor(Color.parseColor("#10141D"));
                    bg.setStroke(dp(1), Color.parseColor("#1F2637"));
                }
            }
        }
    }

    public ScrollView buildHudStudioTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#090B10"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(24));

        TextView title = new TextView(this);
        title.setText("النافذة العائمة وعداد الفريمات الحقيقي V5");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(6));

        TextView sub = new TextView(this);
        sub.setText("يقرأ عداد الـ FPS الآن الإطارات الحقيقية المرسومة من SurfaceFlinger عبر Shizuku مع البنغ الفعلي");
        sub.setTextColor(Color.parseColor("#94A3B8"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        sub.setPadding(0, 0, 0, dp(16));

        col.addView(title);
        col.addView(sub);

        LinearLayout hudInfoCard = createSleekCard("#141822", "#1E2536");
        String[] featuresList = new String[]{
            "🟢 قراءة الفريمات الحقيقية للعبة (True Hardware FPS) مباشرة من SurfaceFlinger عبر Shizuku",
            "📡 عرض البنغ الفعلي الحقيقي لسيرفر المباراة النشط أو بوابة الشرق الأوسط/أوروبا لحظة بلحظة",
            "💥 نبضات تثبيت برج 4G والراوتر كل 250ms بأولوية DSCP EF للقضاء على الدمج الوهمي",
            "🎯 4 أشكال احترافية لعلامة التصويب الثابتة (Crosshair) مع التحكم الفوري باللون والحجم",
            "🔒 ستارة قفل اللمس وتعتيم الشاشة (0.01f) لتبريد الجهاز ومنع اللمس الخاطئ"
        };
        for (int i = 0; i < featuresList.length; i++) {
            TextView tv = new TextView(this);
            tv.setText(featuresList[i]);
            tv.setTextColor(Color.parseColor("#E2E8F0"));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            tv.setPadding(0, dp(6), 0, dp(6));
            hudInfoCard.addView(tv);
        }

        hudInfoCard.addView(createFullWidthButton("🚀 تشغيل الكبسولة العائمة وعداد FPS الحقيقي الآن", "#10B981", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(false);
            }
        }));

        hudInfoCard.addView(createFullWidthButton("🛑 إيقاف النافذة العائمة واستعادة النظام", "#EF4444", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAllBoostServices();
            }
        }));

        col.addView(hudInfoCard);
        scroll.addView(col);
        return scroll;
    }

    public LinearLayout buildBottomNavBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#0E111A"));
        bar.setWeightSum(3f);
        bar.setPadding(0, dp(8), 0, dp(10));

        LinearLayout[] tab0Holder = new LinearLayout[1];
        navBoostLabel = createNavTabItem("⚡", "تعزيز وبنغ", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(0);
            }
        }, tab0Holder);

        LinearLayout[] tab1Holder = new LinearLayout[1];
        navGpuLabel = createNavTabItem("🔥", "Diablo GPU", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(1);
            }
        }, tab1Holder);

        LinearLayout[] tab2Holder = new LinearLayout[1];
        navHudLabel = createNavTabItem("🎯", "عداد FPS الحقيقي", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(2);
            }
        }, tab2Holder);

        bar.addView(tab0Holder[0]);
        bar.addView(tab1Holder[0]);
        bar.addView(tab2Holder[0]);
        return bar;
    }

    public TextView createNavTabItem(String icon, String label, View.OnClickListener onClick, LinearLayout[] boxOut) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        box.setOnClickListener(onClick);

        TextView iconTv = new TextView(this);
        iconTv.setText(icon);
        iconTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
        iconTv.setGravity(Gravity.CENTER);

        TextView labelTv = new TextView(this);
        labelTv.setText(label);
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        labelTv.setTypeface(Typeface.DEFAULT_BOLD);
        labelTv.setGravity(Gravity.CENTER);
        labelTv.setPadding(0, dp(2), 0, 0);

        box.addView(iconTv);
        box.addView(labelTv);
        boxOut[0] = box;
        return labelTv;
    }

    public void switchTab(int index) {
        tabBoostView.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        tabGpuView.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        tabHudView.setVisibility(index == 2 ? View.VISIBLE : View.GONE);

        int activeColor = Color.parseColor("#38BDF8");
        int inactiveColor = Color.parseColor("#64748B");

        navBoostLabel.setTextColor(index == 0 ? activeColor : inactiveColor);
        navGpuLabel.setTextColor(index == 1 ? activeColor : inactiveColor);
        navHudLabel.setTextColor(index == 2 ? activeColor : inactiveColor);
    }

    public LinearLayout createSleekCard(String bgHex, String strokeHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(18));
        bg.setStroke(dp(1), Color.parseColor(strokeHex));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(bg);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(lp);
        return card;
    }

    public TextView createMetricBox(String label, String initialValue, String valueColorHex, LinearLayout[] boxOut) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#0E121B"));
        bg.setCornerRadius((float) dp(12));
        bg.setStroke(dp(1), Color.parseColor("#1F2637"));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackground(bg);
        box.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        box.setLayoutParams(lp);

        TextView valTv = new TextView(this);
        valTv.setText(initialValue);
        valTv.setTextColor(Color.parseColor(valueColorHex));
        valTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        valTv.setTypeface(Typeface.DEFAULT_BOLD);
        valTv.setGravity(Gravity.CENTER);

        TextView lblTv = new TextView(this);
        lblTv.setText(label);
        lblTv.setTextColor(Color.parseColor("#94A3B8"));
        lblTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        lblTv.setGravity(Gravity.CENTER);
        lblTv.setPadding(0, dp(3), 0, 0);

        box.addView(valTv);
        box.addView(lblTv);
        boxOut[0] = box;
        return valTv;
    }

    public TextView createModePill(String title, View.OnClickListener onClick) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public void styleModePill(TextView tv, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(12));
        if (selected) {
            bg.setColor(Color.parseColor("#172B4D"));
            bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
        } else {
            bg.setColor(Color.parseColor("#0E121B"));
            bg.setStroke(dp(1), Color.parseColor("#1F2637"));
        }
        tv.setBackground(bg);
        tv.setTextColor(selected ? Color.parseColor("#00F0FF") : Color.parseColor("#94A3B8"));
    }

    public void applyTogglePillStyle(TextView pillBtn, boolean state) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(14));
        if (state) {
            bg.setColor(Color.parseColor("#064E3B"));
            bg.setStroke(dp(1), Color.parseColor("#10B981"));
        } else {
            bg.setColor(Color.parseColor("#1E293B"));
            bg.setStroke(dp(1), Color.parseColor("#475569"));
        }
        pillBtn.setBackground(bg);
        pillBtn.setText(state ? "مفعّل ✓" : "متوقف");
        pillBtn.setTextColor(state ? Color.parseColor("#34D399") : Color.parseColor("#94A3B8"));
    }

    public LinearLayout createModernToggleRow(
        String title,
        String subtitle,
        final boolean initialState,
        final ToggleCallback callback
    ) {
        final int[] stateHolder = new int[]{initialState ? 1 : 0};
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        textCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        textCol.setPadding(0, 0, dp(10), 0);

        TextView tTv = new TextView(this);
        tTv.setText(title);
        tTv.setTextColor(Color.WHITE);
        tTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tTv.setTypeface(Typeface.DEFAULT_BOLD);

        TextView sTv = new TextView(this);
        sTv.setText(subtitle);
        sTv.setTextColor(Color.parseColor("#94A3B8"));
        sTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        sTv.setPadding(0, dp(2), 0, 0);

        textCol.addView(tTv);
        textCol.addView(sTv);

        final TextView pillBtn = new TextView(this);
        pillBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        pillBtn.setTypeface(Typeface.DEFAULT_BOLD);
        pillBtn.setGravity(Gravity.CENTER);
        pillBtn.setPadding(dp(12), dp(6), dp(12), dp(6));

        applyTogglePillStyle(pillBtn, stateHolder[0] != 0);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stateHolder[0] = (stateHolder[0] == 0) ? 1 : 0;
                applyTogglePillStyle(pillBtn, stateHolder[0] != 0);
                callback.onToggled(stateHolder[0] != 0);
            }
        });
        row.addView(textCol);
        row.addView(pillBtn);
        return row;
    }

    public TextView createActionButton(String title, String bgHex, String textHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(14));
        bg.setStroke(dp(1), Color.parseColor(textHex));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.parseColor(textHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(10), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public TextView createFullWidthButton(String title, String bgHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(14));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(12), 0, 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public Drawable loadCodIcon() {
        for (int i = 0; i < ShizukuShellEngine.COD_PACKAGES.length; i++) {
            try {
                return getPackageManager().getApplicationIcon(ShizukuShellEngine.COD_PACKAGES[i]);
            } catch (Throwable ignored) {}
        }
        try {
            return getResources().getDrawable(R.drawable.cod_default_icon);
        } catch (Throwable e) {
            return getResources().getDrawable(android.R.drawable.sym_def_app_icon);
        }
    }

    public void showRegionSelectorDialog() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int current = prefs.getInt("region_index", 0);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("اختر منطقة خادم Call of Duty Mobile")
            .setSingleChoiceItems(NetPingHelper.SERVER_REGIONS, current, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    prefs.edit().putInt("region_index", which).apply();
                    regionValueTv.setText(NetPingHelper.SERVER_REGIONS[which] + "  ‹");
                    dialog.dismiss();
                    refreshLiveMetrics();
                }
            })
            .show();
    }

    public void showDownscaleSelectorDialog() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int current = prefs.getInt("downscale_index", 0);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("تحجيم دقة المعالج الرسومي (Shizuku GPU Scaling)")
            .setSingleChoiceItems(NetPingHelper.DOWNSCALE_MODES, current, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    prefs.edit().putInt("downscale_index", which).apply();
                    downscaleValueTv.setText(NetPingHelper.getDownscaleRatioValue(which) + "x Esports  ‹");
                    dialog.dismiss();
                }
            })
            .show();
    }

    public void refreshLiveMetrics() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) {
            am.getMemoryInfo(mi);
        }
        long availMb = mi.availMem / (1024L * 1024L);
        if (gpuRamFreeTv != null) {
            gpuRamFreeTv.setText(availMb + " MB");
        }

        Intent bm = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int tenths = bm != null ? bm.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 330) : 330;
        if (gpuTempTv != null) {
            gpuTempTv.setText((tenths / 10.0f) + " °C");
        }

        if (livePingGaugeTv != null) {
            livePingGaugeTv.setText("جاري القياس...");
        }
        final int region = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("region_index", 0);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int ping = NetPingHelper.measureTrueGamePing(region);
                final int jitter = NetPingHelper.lastJitter;
                final int loss = NetPingHelper.lastPacketLoss;
                final String srvLabel = NetPingHelper.activeServerLabel;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (livePingGaugeTv != null) {
                            livePingGaugeTv.setText(ping + " ms");
                            String color;
                            if (ping < 65) {
                                color = "#10B981";
                            } else if (ping < 95) {
                                color = "#F59E0B";
                            } else {
                                color = "#EF4444";
                            }
                            livePingGaugeTv.setTextColor(Color.parseColor(color));
                        }
                        if (liveJitterTv != null) {
                            liveJitterTv.setText(jitter + " ms");
                        }
                        if (liveHitRegTv != null) {
                            liveHitRegTv.setText(loss + "% (" + (loss == 0 ? "ثابت" : "متذبذب") + ")");
                        }
                        if (activeServerSubTv != null) {
                            activeServerSubTv.setText("المسار النشط: " + srvLabel);
                        }
                    }
                });
            }
        }).start();
    }

    public void startFullBoostSequence(boolean launchGame) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "يرجى منح صلاحية الظهور فوق التطبيقات لتشغيل عداد الفريمات الحقيقي", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_REQ);
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                NetPingHelper.optimizeGpuAndRam(MainActivity.this);
            }
        }).start();
        NetPingHelper.enableUltraNetworkAndHitRegEngine(this);

        Intent hudIntent = new Intent(this, FloatingBoosterService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(hudIntent);
        } else {
            startService(hudIntent);
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (prefs.getBoolean("isolate_bg", true)) {
            Intent prep = VpnService.prepare(this);
            if (prep != null) {
                startActivityForResult(prep, VPN_REQ);
                return;
            } else {
                startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_START));
            }
        }

        isBoosting = true;
        mainBoostBtn.setText("مُعزّز ✓");
        mainBoostBtn.setTextColor(Color.parseColor("#10B981"));
        if (ShizukuShellEngine.hasShizukuPermission()) {
            boostStatusSubTv.setText("🔥 وضع Shizuku Diablo + تثبيت البنغ <60ms + عداد FPS الحقيقي نشط");
        } else {
            boostStatusSubTv.setText("⚡ تم عزل الشبكة وتفعيل مانع الدمج الوهمي 250ms");
        }
        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"));

        if (launchGame) {
            final boolean autoExit = prefs.getBoolean("zero_ram_exit", true);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    launchCodMobileAndFreeRam(autoExit);
                }
            }, 350L);
        } else {
            refreshLiveMetrics();
        }
    }

    public void launchCodMobileAndFreeRam(boolean autoCloseActivity) {
        for (int i = 0; i < ShizukuShellEngine.COD_PACKAGES.length; i++) {
            String pkg = ShizukuShellEngine.COD_PACKAGES[i];
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) {
                startActivity(launch);
                if (autoCloseActivity) {
                    finish();
                }
                return;
            }
        }
        Toast.makeText(this, "⚡ المعزز وعداد الفريمات الحقيقي يعملان الآن! افتح كود موبايل", Toast.LENGTH_SHORT).show();
    }

    public void stopAllBoostServices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ShizukuShellEngine.restoreNormalSystemState();
            }
        }).start();
        stopService(new Intent(this, FloatingBoosterService.class));
        startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_STOP));
        NetPingHelper.disableUltraNetworkEngine();
        isBoosting = false;
        mainBoostBtn.setText("تعزيز خارق");
        mainBoostBtn.setTextColor(Color.parseColor("#60A5FA"));
        boostStatusSubTv.setText("تم إيقاف المعزز واستعادة إعدادات النظام الطبيعية");
        boostStatusSubTv.setTextColor(Color.parseColor("#94A3B8"));
        Toast.makeText(this, "🛑 تم إيقاف المعزز واستعادة إعدادات النظام بالكامل", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQ && resultCode == RESULT_OK) {
            startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_START));
            SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            launchCodMobileAndFreeRam(prefs.getBoolean("zero_ram_exit", true));
        } else if (requestCode == OVERLAY_REQ && Settings.canDrawOverlays(this)) {
            startFullBoostSequence(false);
        }
    }
}
