package com.daraa.codbooster;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    public static final int VPN_REQ = 2001;
    public static final int SHIZUKU_REQ = 2003;
    public static final String PREFS = "hyperboost_prefs";

    public interface ToggleCallback {
        void onToggled(boolean enabled);
    }

    public FrameLayout contentFrame;
    public ScrollView tabGamesBoostView;
    public ScrollView tabGpuAndNetView;

    public TextView navGamesLabel;
    public TextView navGpuNetLabel;

    public TextView deviceRamChipTv;
    public TextView deviceHzChipTv;
    public TextView deviceTempChipTv;
    public TextView devicePingChipTv;

    public TextView shizukuBannerTv;
    public TextView shizukuActionBtn;

    public TextView detectedGamesCountBadge;
    public LinearLayout gamesCarouselContainer;
    public ImageView selectedGameIconView;
    public TextView selectedGameTitleTv;
    public TextView selectedGamePkgTv;
    public TextView boostStatusSubTv;
    public TextView mainBoostBtn;

    public TextView regionValueTv;
    public TextView downscaleValueTv;

    public TextView pill4GView = null;
    public TextView pillAdslView = null;
    public int currentNetMode = 0;

    public final List<LinearLayout> profileViews = new ArrayList<LinearLayout>();
    public int selectedGpuProfile = 0;
    public boolean pendingLaunchGame = false;

    public final Handler handler = new Handler(Looper.getMainLooper());

    // مستمعات Shizuku الرسمية الفورية (تستقبل اتصال Shizuku تلقائياً فور فتح التطبيق)
    public final Shizuku.OnBinderReceivedListener binderReceivedListener =
        new Shizuku.OnBinderReceivedListener() {
            @Override
            public void onBinderReceived() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshShizukuBanner();
                        if (!ShizukuShellEngine.hasShizukuPermission()) {
                            ShizukuShellEngine.requestPermission(SHIZUKU_REQ);
                        }
                    }
                });
            }
        };

    public final Shizuku.OnBinderDeadListener binderDeadListener =
        new Shizuku.OnBinderDeadListener() {
            @Override
            public void onBinderDead() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshShizukuBanner();
                    }
                });
            }
        };

    public final Shizuku.OnRequestPermissionResultListener shizukuPermListener =
        new Shizuku.OnRequestPermissionResultListener() {
            @Override
            public void onRequestPermissionResult(int requestCode, final int grantResult) {
                if (requestCode == SHIZUKU_REQ) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshShizukuBanner();
                            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                                Toast.makeText(
                                    MainActivity.this,
                                    "🔥 تم تفعيل صلاحيات Shizuku الكاملة (" + ShizukuShellEngine.getShizukuIdentityLabel() + ") بنجاح!",
                                    Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    });
                }
            }
        };

    public int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            (float) value,
            getResources().getDisplayMetrics()
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().setStatusBarColor(Color.parseColor("#080B12"));
            getWindow().setNavigationBarColor(Color.parseColor("#0D111C"));
        } catch (Throwable ignored) {}

        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
            Shizuku.addBinderDeadListener(binderDeadListener);
            Shizuku.addRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignored) {}

        GameScannerEngine.scanInstalledGames(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#080B12"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setFitsSystemWindows(true);

        contentFrame = new FrameLayout(this);
        contentFrame.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ));

        tabGamesBoostView = buildMainBoostTab();
        tabGpuAndNetView = buildPerformanceAndNetworkTab();

        contentFrame.addView(tabGamesBoostView);
        contentFrame.addView(tabGpuAndNetView);

        root.addView(contentFrame);
        root.addView(buildBottomNavBar());

        setContentView(root);
        switchTab(0);
        refreshDetectedGamesCarousel();
        refreshShizukuBanner();
        refreshHardwareChips();
        triggerLivePingCheck(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        GameScannerEngine.scanInstalledGames(this);
        refreshDetectedGamesCarousel();
        refreshShizukuBanner();
        refreshHardwareChips();
        triggerLivePingCheck(false);
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener);
            Shizuku.removeBinderDeadListener(binderDeadListener);
            Shizuku.removeRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    public ScrollView buildMainBoostTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#080B12"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(15), dp(14), dp(15), dp(24));

        // 1. شريط العنوان الرسمي
        RelativeLayout topBar = new RelativeLayout(this);
        topBar.setPadding(0, 0, 0, dp(12));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("معزز الألعاب");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f);
        headerTitle.setTypeface(Typeface.DEFAULT_BOLD);
        RelativeLayout.LayoutParams hLp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        hLp.addRule(RelativeLayout.CENTER_IN_PARENT);
        headerTitle.setLayoutParams(hLp);

        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#172B4D"));
        badgeBg.setCornerRadius((float) dp(12));
        badgeBg.setStroke(dp(1), Color.parseColor("#00F0FF"));

        TextView editionBadge = new TextView(this);
        editionBadge.setText("🔥 A07 PRO v8.1");
        editionBadge.setTextColor(Color.parseColor("#00F0FF"));
        editionBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        editionBadge.setTypeface(Typeface.DEFAULT_BOLD);
        editionBadge.setBackground(badgeBg);
        editionBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        RelativeLayout.LayoutParams bLp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        bLp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        bLp.addRule(RelativeLayout.CENTER_VERTICAL);
        editionBadge.setLayoutParams(bLp);

        topBar.addView(headerTitle);
        topBar.addView(editionBadge);
        col.addView(topBar);

        // 2. بطاقة ربط وتفعيل Shizuku الحقيقي (Official API V23)
        LinearLayout shizukuCard = createSleekCard("#12192B", "#2563EB");
        LinearLayout shizukuRow = new LinearLayout(this);
        shizukuRow.setOrientation(LinearLayout.HORIZONTAL);
        shizukuRow.setGravity(Gravity.CENTER_VERTICAL);

        shizukuBannerTv = new TextView(this);
        shizukuBannerTv.setText("⚡ جاري الاتصال بخادم Shizuku...");
        shizukuBannerTv.setTextColor(Color.WHITE);
        shizukuBannerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        shizukuBannerTv.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuBannerTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        shizukuBannerTv.setPadding(0, 0, dp(8), 0);

        GradientDrawable shizukuBtnBg = new GradientDrawable();
        shizukuBtnBg.setColor(Color.parseColor("#2563EB"));
        shizukuBtnBg.setCornerRadius((float) dp(14));

        shizukuActionBtn = new TextView(this);
        shizukuActionBtn.setText("تفعيل Shizuku");
        shizukuActionBtn.setTextColor(Color.WHITE);
        shizukuActionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        shizukuActionBtn.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuActionBtn.setBackground(shizukuBtnBg);
        shizukuActionBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        shizukuActionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleShizukuButtonClick();
            }
        });

        shizukuRow.addView(shizukuBannerTv);
        shizukuRow.addView(shizukuActionBtn);
        shizukuCard.addView(shizukuRow);
        col.addView(shizukuCard);

        // 3. بطاقة عتاد Samsung Galaxy A07 4G (6GB/128GB) + فاحص البنغ الحقيقي
        LinearLayout hwBannerCard = createSleekCard("#101726", "#1E293B");
        TextView deviceModelTv = new TextView(this);
        deviceModelTv.setText("📱 " + HardwareProfiler.getDeviceMarketingName() + " (6GB RAM / 128GB)");
        deviceModelTv.setTextColor(Color.parseColor("#38BDF8"));
        deviceModelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        deviceModelTv.setTypeface(Typeface.DEFAULT_BOLD);

        TextView deviceSubTv = new TextView(this);
        deviceSubTv.setText("🛡️ بديل Game Booster Plus لـ A07: حارس منع GOS + وضع الأولوية + تثبيت البنغ (اضغط على البنغ للفحص الفوري)");
        deviceSubTv.setTextColor(Color.parseColor("#94A3B8"));
        deviceSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        deviceSubTv.setPadding(0, dp(4), 0, dp(10));

        LinearLayout hwChipsRow = new LinearLayout(this);
        hwChipsRow.setOrientation(LinearLayout.HORIZONTAL);
        hwChipsRow.setWeightSum(4f);

        long[] ramStats = HardwareProfiler.getRamStatsMb(this);
        int hz = HardwareProfiler.readDisplayRefreshRate(this);
        float tempC = HardwareProfiler.getBatteryTempCelsius(this);

        deviceRamChipTv = createMiniHwChip("رام: " + ramStats[0] + "MB", "#10B981");
        deviceHzChipTv = createMiniHwChip("الشاشة: " + hz + "Hz", "#00F0FF");
        deviceTempChipTv = createMiniHwChip("الحرارة: " + tempC + "°C", "#F59E0B");
        devicePingChipTv = createMiniHwChip("البنغ: ...ms", "#A78BFA");
        devicePingChipTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triggerLivePingCheck(true);
            }
        });

        hwChipsRow.addView(deviceRamChipTv);
        hwChipsRow.addView(deviceHzChipTv);
        hwChipsRow.addView(deviceTempChipTv);
        hwChipsRow.addView(devicePingChipTv);

        hwBannerCard.addView(deviceModelTv);
        hwBannerCard.addView(deviceSubTv);
        hwBannerCard.addView(hwChipsRow);
        col.addView(hwBannerCard);

        // 4. بطاقة الألعاب المكتشفة تلقائياً
        LinearLayout scannerCard = createSleekCard("#141824", "#1E293B");
        LinearLayout scannerHeader = new LinearLayout(this);
        scannerHeader.setOrientation(LinearLayout.HORIZONTAL);
        scannerHeader.setGravity(Gravity.CENTER_VERTICAL);
        scannerHeader.setPadding(0, 0, 0, dp(8));

        detectedGamesCountBadge = new TextView(this);
        detectedGamesCountBadge.setText("🎮 الألعاب المثبتة على هاتفك");
        detectedGamesCountBadge.setTextColor(Color.WHITE);
        detectedGamesCountBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        detectedGamesCountBadge.setTypeface(Typeface.DEFAULT_BOLD);
        detectedGamesCountBadge.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView addAppBtn = createHeaderSmallButton("+ إضافة لعبة", "#172B4D", "#38BDF8", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddCustomGameDialog();
            }
        });

        scannerHeader.addView(detectedGamesCountBadge);
        scannerHeader.addView(addAppBtn);
        scannerCard.addView(scannerHeader);

        HorizontalScrollView hScroll = new HorizontalScrollView(this);
        hScroll.setHorizontalScrollBarEnabled(false);
        gamesCarouselContainer = new LinearLayout(this);
        gamesCarouselContainer.setOrientation(LinearLayout.HORIZONTAL);
        gamesCarouselContainer.setGravity(Gravity.CENTER_VERTICAL);
        hScroll.addView(gamesCarouselContainer);
        scannerCard.addView(hScroll);
        col.addView(scannerCard);

        // 5. بطاقة التشغيل والتعزيز الفائق للعبة المختارة
        LinearLayout activeGameCard = createSleekCard("#141A29", "#2563EB");
        LinearLayout gameRow = new LinearLayout(this);
        gameRow.setOrientation(LinearLayout.HORIZONTAL);
        gameRow.setGravity(Gravity.CENTER_VERTICAL);

        selectedGameIconView = new ImageView(this);
        selectedGameIconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        selectedGameIconView.setLayoutParams(new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, dp(12), 0);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        selectedGameTitleTv = new TextView(this);
        selectedGameTitleTv.setText(GameScannerEngine.getActiveGameName(this));
        selectedGameTitleTv.setTextColor(Color.WHITE);
        selectedGameTitleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f);
        selectedGameTitleTv.setTypeface(Typeface.DEFAULT_BOLD);

        selectedGamePkgTv = new TextView(this);
        selectedGamePkgTv.setText(GameScannerEngine.getActiveGamePackage(this));
        selectedGamePkgTv.setTextColor(Color.parseColor("#64748B"));
        selectedGamePkgTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        selectedGamePkgTv.setPadding(0, dp(1), 0, 0);

        boostStatusSubTv = new TextView(this);
        boostStatusSubTv.setText("وضع الأولوية + حارس منع GOS + تثبيت البنغ الفعلي");
        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"));
        boostStatusSubTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        boostStatusSubTv.setPadding(0, dp(3), 0, 0);

        titleCol.addView(selectedGameTitleTv);
        titleCol.addView(selectedGamePkgTv);
        titleCol.addView(boostStatusSubTv);

        GradientDrawable boostPillBg = new GradientDrawable();
        boostPillBg.setColor(Color.parseColor("#10B981"));
        boostPillBg.setCornerRadius((float) dp(18));

        mainBoostBtn = new TextView(this);
        mainBoostBtn.setText("🚀 تعزيز وتشغيل");
        mainBoostBtn.setTextColor(Color.WHITE);
        mainBoostBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        mainBoostBtn.setTypeface(Typeface.DEFAULT_BOLD);
        mainBoostBtn.setGravity(Gravity.CENTER);
        mainBoostBtn.setBackground(boostPillBg);
        mainBoostBtn.setPadding(dp(16), dp(11), dp(16), dp(11));
        mainBoostBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(true);
            }
        });

        gameRow.addView(selectedGameIconView);
        gameRow.addView(titleCol);
        gameRow.addView(mainBoostBtn);
        activeGameCard.addView(gameRow);

        View divider1 = new View(this);
        divider1.setBackgroundColor(Color.parseColor("#1F293D"));
        LinearLayout.LayoutParams d1Lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        d1Lp.setMargins(0, dp(12), 0, dp(10));
        divider1.setLayoutParams(d1Lp);
        activeGameCard.addView(divider1);

        LinearLayout regionRow = new LinearLayout(this);
        regionRow.setOrientation(LinearLayout.HORIZONTAL);
        regionRow.setGravity(Gravity.CENTER_VERTICAL);
        regionRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRegionSelectorDialog();
            }
        });

        TextView regionLabelTv = new TextView(this);
        regionLabelTv.setText("مسار الـ DNS وتقليل البنغ الفعلي");
        regionLabelTv.setTextColor(Color.parseColor("#94A3B8"));
        regionLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        regionLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        int savedRegion = prefs.getInt("region_index", 0);
        if (savedRegion < 0 || savedRegion >= NetPingHelper.SERVER_REGIONS.length) {
            savedRegion = 0;
        }
        regionValueTv = new TextView(this);
        regionValueTv.setText(NetPingHelper.SERVER_REGIONS[savedRegion] + "  ‹");
        regionValueTv.setTextColor(Color.parseColor("#E2E8F0"));
        regionValueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        regionValueTv.setTypeface(Typeface.DEFAULT_BOLD);

        regionRow.addView(regionLabelTv);
        regionRow.addView(regionValueTv);
        activeGameCard.addView(regionRow);

        View divider2 = new View(this);
        divider2.setBackgroundColor(Color.parseColor("#1F293D"));
        LinearLayout.LayoutParams d2Lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        d2Lp.setMargins(0, dp(10), 0, dp(10));
        divider2.setLayoutParams(d2Lp);
        activeGameCard.addView(divider2);

        LinearLayout downscaleRow = new LinearLayout(this);
        downscaleRow.setOrientation(LinearLayout.HORIZONTAL);
        downscaleRow.setGravity(Gravity.CENTER_VERTICAL);
        downscaleRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showGraphicsModeSelectorDialog();
            }
        });

        TextView downscaleLabelTv = new TextView(this);
        downscaleLabelTv.setText("جودة الرسوميات والفريمات (Game Mode)");
        downscaleLabelTv.setTextColor(Color.parseColor("#38BDF8"));
        downscaleLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        downscaleLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        int savedDownscale = prefs.getInt("downscale_index", 0);
        if (savedDownscale < 0 || savedDownscale >= NetPingHelper.GRAPHICS_MODES.length) {
            savedDownscale = 0;
        }
        downscaleValueTv = new TextView(this);
        downscaleValueTv.setText(NetPingHelper.GRAPHICS_MODES[savedDownscale] + "  ‹");
        downscaleValueTv.setTextColor(Color.parseColor("#00F0FF"));
        downscaleValueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        downscaleValueTv.setTypeface(Typeface.DEFAULT_BOLD);

        downscaleRow.addView(downscaleLabelTv);
        downscaleRow.addView(downscaleValueTv);
        activeGameCard.addView(downscaleRow);

        col.addView(activeGameCard);

        // 6. أزرار التحكم المباشر
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setWeightSum(2f);

        TextView btnApplyOnly = createActionButton("⚡ تطبيق التعزيز وتفريغ الرام فقط", "#172B4D", "#38BDF8", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFullBoostSequence(false);
            }
        });
        TextView btnStopAll = createActionButton("🛑 إيقاف التعزيز واستعادة النظام", "#2A1219", "#F87171", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAllBoostServices();
            }
        });
        actionRow.addView(btnApplyOnly);
        actionRow.addView(btnStopAll);
        col.addView(actionRow);

        scroll.addView(col);
        return scroll;
    }

    public ScrollView buildPerformanceAndNetworkTab() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        currentNetMode = prefs.getInt("net_mode", 0);
        selectedGpuProfile = prefs.getInt("gpu_profile", 0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#080B12"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(15), dp(16), dp(15), dp(24));

        TextView title = new TextView(this);
        title.setText("إعدادات Shizuku ووضع الأولوية (Galaxy A07)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(4));

        TextView sub = new TextView(this);
        sub.setText("ميزات تتفوق على معزز سامسونج الرسمي (Game Booster Plus) غير المدعوم على هاتفك وبصفر استهلاك للرام");
        sub.setTextColor(Color.parseColor("#94A3B8"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        sub.setPadding(0, 0, 0, dp(14));

        col.addView(title);
        col.addView(sub);

        // 1. بطاقة أوضاع المعالج الرسومي والنواة (3 أوضاع فعلية ومختلفة)
        LinearLayout profileCard = createSleekCard("#141824", "#1E293B");
        TextView profTitle = new TextView(this);
        profTitle.setText("🔥 وضع معالج Galaxy A07 4G والرسوميات الفعلي");
        profTitle.setTextColor(Color.WHITE);
        profTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        profTitle.setTypeface(Typeface.DEFAULT_BOLD);
        profTitle.setPadding(0, 0, 0, dp(10));
        profileCard.addView(profTitle);

        profileViews.clear();
        String[] pTitles = new String[]{
            "🔥 وضع الأداء الخارق (Diablo Ultra - قفل 90Hz كامل + إلغاء الخنق)",
            "⚖️ الوضع المتوازن الذكي (60-90Hz مرن + ثبات للمباريات الطويلة)",
            "❄️ وضع التبريد الفائق (Game Mode 3 + سقف 60Hz لمنع السخونة فوراً)"
        };
        String[] pDescs = new String[]{
            "يقفل الشاشة على 90Hz، يوقف خنق الحرارة، ويربط اللعبة بجميع أنوية المعالج (taskset ff) بعد إقلاعها",
            "يفعّل وضع الأداء مع تحجيم ذكي (0.90x) وحماية حرارة البطارية لجلسات اللعب الطويلة بدون هبوط فريمات",
            "يحول محرك أندرويد لوضع التبريد (Mode 3) بدقة 0.80x وسقف 60Hz لخفض حرارة المعالج والبطارية فوراً"
        };

        for (int i = 0; i < 3; i++) {
            final int idx = i;
            final String modeName = pTitles[i];
            GradientDrawable itemBg = new GradientDrawable();
            itemBg.setCornerRadius((float) dp(12));

            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setBackground(itemBg);
            itemLayout.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            lp.setMargins(0, 0, 0, dp(8));
            itemLayout.setLayoutParams(lp);
            itemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedGpuProfile = idx;
                    prefs.edit().putInt("gpu_profile", idx).apply();
                    refreshGpuProfileStyles();
                    Toast.makeText(MainActivity.this, "تم اختيار: " + modeName, Toast.LENGTH_SHORT).show();
                }
            });

            TextView tTv = new TextView(this);
            tTv.setText(pTitles[i]);
            tTv.setTextColor(Color.WHITE);
            tTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            tTv.setTypeface(Typeface.DEFAULT_BOLD);

            TextView dTv = new TextView(this);
            dTv.setText(pDescs[i]);
            dTv.setTextColor(Color.parseColor("#94A3B8"));
            dTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            dTv.setPadding(0, dp(3), 0, 0);

            itemLayout.addView(tTv);
            itemLayout.addView(dTv);
            profileViews.add(itemLayout);
            profileCard.addView(itemLayout);
        }

        refreshGpuProfileStyles();
        col.addView(profileCard);

        // 2. بطاقة إعدادات الشبكة ووضع الأولوية (Samsung Priority Mode)
        LinearLayout netConfigCard = createSleekCard("#141824", "#1E293B");
        TextView netSectionTitle = new TextView(this);
        netSectionTitle.setText("📡 تحسين البنغ وميزات Samsung Priority Mode");
        netSectionTitle.setTextColor(Color.WHITE);
        netSectionTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        netSectionTitle.setTypeface(Typeface.DEFAULT_BOLD);
        netSectionTitle.setPadding(0, 0, 0, dp(10));
        netConfigCard.addView(netSectionTitle);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setWeightSum(2f);
        LinearLayout.LayoutParams mRowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        mRowLp.setMargins(0, 0, 0, dp(12));
        modeRow.setLayoutParams(mRowLp);

        pill4GView = createModePill("📶 بيانات 4G/LTE (MTU 1360)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentNetMode = 0;
                prefs.edit().putInt("net_mode", 0).apply();
                refreshNetModePills();
            }
        });
        pillAdslView = createModePill("🏠 راوتر Wi-Fi / ADSL (MTU 1440)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentNetMode = 1;
                prefs.edit().putInt("net_mode", 1).apply();
                refreshNetModePills();
            }
        });
        refreshNetModePills();
        modeRow.addView(pill4GView);
        modeRow.addView(pillAdslView);
        netConfigCard.addView(modeRow);

        netConfigCard.addView(createModernToggleRow(
            "إيقاف خنق سامسونج الحراري (Samsung GOS & SDHMS Killer)",
            "تجميد خدمات سامسونج الخلفية التي تبطئ معالج Galaxy A07 وتسبب هبوط الفريمات",
            prefs.getBoolean("kill_gos", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("kill_gos", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "حارس منع عودة GOS أثناء اللعب (Persistent Anti-GOS Watchdog)",
            "يراقب اللعبة بالخلفية بصفر رام، يربط أنوية المعالج باللعبة بعد فتحها، ويمنع عودة GOS عند السخونة",
            prefs.getBoolean("gos_watchdog", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("gos_watchdog", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "وضع الأولوية: حجب الإشعارات العائمة أثناء اللعب (Priority Mode)",
            "يمنع إشعارات واتساب والرسائل من الظهور أعلى الشاشة والتغطية على زر الإطلاق أثناء المواجهات",
            prefs.getBoolean("block_heads_up", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("block_heads_up", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "تثبيت سطوع الشاشة ومنع التعتيم المفاجئ (Brightness Lock)",
            "يمنع انخفاض إضاءة الشاشة تلقائياً عندما تغطي يدك حساس الإضاءة أثناء مسك الهاتف بالعرض",
            prefs.getBoolean("lock_brightness", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("lock_brightness", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "ترجمة اللعبة إلى كود ARM64 السريع (Speed Compile AOT)",
            "ينهي مشكلة عنق الزجاجة والتقطيع المفاجئ أثناء المواجهات عبر Shizuku",
            prefs.getBoolean("speed_compile", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("speed_compile", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "فتح مسار البنغ السريع للراوتر والـ 4G (Low-Latency Lock)",
            "قفل شريحة الواي فاي وبرج الـ 4G في وضع الاستجابة الفورية وإيقاف مسح الشبكات بالخلفية",
            prefs.getBoolean("hit_reg_boost", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("hit_reg_boost", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "عزل إنترنت الخلفية بالكامل للعبة فقط (Kernel Firewall)",
            "قطع الإنترنت عن تطبيقات الخلفية الشرهة (واتساب، فيسبوك، تيك توك) مع حماية Discord لتثبيت البنغ",
            prefs.getBoolean("isolate_bg", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("isolate_bg", enabled).apply();
                }
            }
        ));

        netConfigCard.addView(createModernToggleRow(
            "وضع صفر رام (إغلاق واجهة المعزز تلقائياً فور دخول اللعبة)",
            "يغلق واجهة التطبيق بعد تشغيل اللعبة مع إبقاء حارس النواة نشطاً ليترك 100% من الرام للعبة",
            prefs.getBoolean("zero_ram_exit", true),
            new ToggleCallback() {
                @Override
                public void onToggled(boolean enabled) {
                    prefs.edit().putBoolean("zero_ram_exit", enabled).apply();
                }
            }
        ));

        col.addView(netConfigCard);
        scroll.addView(col);
        return scroll;
    }

    public LinearLayout buildBottomNavBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#0D111C"));
        bar.setWeightSum(2f);
        bar.setPadding(0, dp(8), 0, dp(10));

        LinearLayout[] tab0Holder = new LinearLayout[1];
        navGamesLabel = createNavTabItem("🚀", "الألعاب والتعزيز", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(0);
            }
        }, tab0Holder);

        LinearLayout[] tab1Holder = new LinearLayout[1];
        navGpuNetLabel = createNavTabItem("🔥", "إعدادات Shizuku والأولوية", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(1);
            }
        }, tab1Holder);

        bar.addView(tab0Holder[0]);
        bar.addView(tab1Holder[0]);
        return bar;
    }

    public TextView createNavTabItem(String icon, String label, View.OnClickListener onClick, LinearLayout[] boxOut) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        box.setOnClickListener(onClick);

        TextView iconTv = new TextView(this);
        iconTv.setText(icon);
        iconTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
        iconTv.setGravity(Gravity.CENTER);

        TextView labelTv = new TextView(this);
        labelTv.setText(label);
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        labelTv.setTypeface(Typeface.DEFAULT_BOLD);
        labelTv.setGravity(Gravity.CENTER);
        labelTv.setPadding(0, dp(2), 0, 0);

        box.addView(iconTv);
        box.addView(labelTv);
        boxOut[0] = box;
        return labelTv;
    }

    public void switchTab(int index) {
        tabGamesBoostView.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        tabGpuAndNetView.setVisibility(index == 1 ? View.VISIBLE : View.GONE);

        int activeColor = Color.parseColor("#00F0FF");
        int inactiveColor = Color.parseColor("#64748B");

        navGamesLabel.setTextColor(index == 0 ? activeColor : inactiveColor);
        navGpuNetLabel.setTextColor(index == 1 ? activeColor : inactiveColor);
    }

    public void refreshShizukuBanner() {
        if (shizukuBannerTv == null) return;
        if (ShizukuShellEngine.hasShizukuPermission()) {
            String idLabel = ShizukuShellEngine.getShizukuIdentityLabel();
            shizukuBannerTv.setText("🔥 صلاحيات Shizuku مفعّلة بالكامل (" + idLabel + ")\nحارس GOS + وضع الأولوية + تثبيت البنغ جاهز!");
            shizukuBannerTv.setTextColor(Color.parseColor("#34D399"));
            shizukuActionBtn.setText("مفعّل ✓");
        } else if (ShizukuShellEngine.isShizukuAvailable()) {
            shizukuBannerTv.setText("⚡ تطبيق Shizuku متصل! اضغط الآن على (منح الصلاحية) لتفعيل القوة القصوى");
            shizukuBannerTv.setTextColor(Color.parseColor("#FBBF24"));
            shizukuActionBtn.setText("منح الصلاحية");
        } else {
            shizukuBannerTv.setText("💡 شغّل خدمة Shizuku ثم اضغط هنا لتفعيل صلاحية النواة (أو فعلها من قائمة تطبيقات Shizuku)");
            shizukuBannerTv.setTextColor(Color.parseColor("#94A3B8"));
            shizukuActionBtn.setText("تفعيل Shizuku");
        }
    }

    public void handleShizukuButtonClick() {
        try {
            if (ShizukuShellEngine.hasShizukuPermission()) {
                Toast.makeText(this, "🔥 صلاحيات Shizuku مفعّلة وجاهزة بالكامل!", Toast.LENGTH_SHORT).show();
            } else if (ShizukuShellEngine.isShizukuAvailable()) {
                ShizukuShellEngine.requestPermission(SHIZUKU_REQ);
            } else {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) {
                    Toast.makeText(this, "شغّل Shizuku وستجد (معزز الألعاب) داخل قائمة التطبيقات المصرّح لها!", Toast.LENGTH_LONG).show();
                    startActivity(launch);
                } else {
                    Toast.makeText(this, "يرجى تثبيت وتشغيل تطبيق Shizuku لتفعيل أوامر النواة", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Throwable ignored) {}
    }

    public void refreshHardwareChips() {
        long[] ram = HardwareProfiler.getRamStatsMb(this);
        int hz = HardwareProfiler.readDisplayRefreshRate(this);
        float tempC = HardwareProfiler.getBatteryTempCelsius(this);
        if (deviceRamChipTv != null) {
            deviceRamChipTv.setText("رام: " + ram[0] + "MB");
        }
        if (deviceHzChipTv != null) {
            deviceHzChipTv.setText("الشاشة: " + hz + "Hz");
        }
        if (deviceTempChipTv != null) {
            deviceTempChipTv.setText("الحرارة: " + tempC + "°C");
        }
        if (devicePingChipTv != null && NetPingHelper.lastMeasuredPingMs > 0) {
            devicePingChipTv.setText("البنغ: " + NetPingHelper.lastMeasuredPingMs + "ms");
        }
    }

    public void triggerLivePingCheck(final boolean showToast) {
        if (devicePingChipTv != null && showToast) {
            devicePingChipTv.setText("البنغ: فحص...");
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String bestDns = NetPingHelper.benchmarkAndSelectFastestDns(MainActivity.this);
                final int rtt = NetPingHelper.lastMeasuredPingMs;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (devicePingChipTv != null) {
                            if (rtt > 0) {
                                devicePingChipTv.setText("البنغ: " + rtt + "ms");
                            } else {
                                devicePingChipTv.setText("البنغ: غير متصل");
                            }
                        }
                        if (showToast) {
                            if (rtt > 0) {
                                Toast.makeText(
                                    MainActivity.this,
                                    "📡 البنغ الفعلي: " + rtt + "ms عبر مخدم (" + bestDns + ")",
                                    Toast.LENGTH_SHORT
                                ).show();
                            } else {
                                Toast.makeText(
                                    MainActivity.this,
                                    "⚠️ تعذر قياس البنغ، تأكد من اتصال الواي فاي أو الـ 4G",
                                    Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                    }
                });
            }
        }).start();
    }

    public void refreshDetectedGamesCarousel() {
        if (gamesCarouselContainer == null) return;
        gamesCarouselContainer.removeAllViews();

        List<GameScannerEngine.GameItem> games = GameScannerEngine.cachedGames;
        String activePkg = GameScannerEngine.getActiveGamePackage(this);
        String activeName = GameScannerEngine.getActiveGameName(this);

        if (detectedGamesCountBadge != null) {
            detectedGamesCountBadge.setText("🎮 الألعاب المكتشفة (" + games.size() + ")");
        }
        if (selectedGameIconView != null) {
            selectedGameIconView.setImageDrawable(GameScannerEngine.loadGameIcon(this, activePkg));
        }
        if (selectedGameTitleTv != null) {
            selectedGameTitleTv.setText(activeName);
        }
        if (selectedGamePkgTv != null) {
            selectedGamePkgTv.setText(activePkg);
        }

        if (games.isEmpty()) {
            TextView emptyTv = new TextView(this);
            emptyTv.setText("اضغط (+ إضافة لعبة) لاختيار لعبتك من قائمة تطبيقات الهاتف");
            emptyTv.setTextColor(Color.parseColor("#94A3B8"));
            emptyTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            emptyTv.setPadding(dp(10), dp(10), dp(10), dp(10));
            emptyTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAddCustomGameDialog();
                }
            });
            gamesCarouselContainer.addView(emptyTv);
            return;
        }

        for (int i = 0; i < games.size(); i++) {
            final GameScannerEngine.GameItem item = games.get(i);
            boolean isSelected = item.packageName.equals(activePkg);

            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setCornerRadius((float) dp(14));
            if (isSelected) {
                cardBg.setColor(Color.parseColor("#172B4D"));
                cardBg.setStroke(dp(2), Color.parseColor("#00F0FF"));
            } else {
                cardBg.setColor(Color.parseColor("#0E131F"));
                cardBg.setStroke(dp(1), Color.parseColor("#1F293D"));
            }

            LinearLayout gCard = new LinearLayout(this);
            gCard.setOrientation(LinearLayout.VERTICAL);
            gCard.setGravity(Gravity.CENTER);
            gCard.setBackground(cardBg);
            gCard.setPadding(dp(10), dp(10), dp(10), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(106), LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), 0, dp(4), 0);
            gCard.setLayoutParams(lp);

            ImageView iconIv = new ImageView(this);
            iconIv.setImageDrawable(GameScannerEngine.loadGameIcon(this, item.packageName));
            iconIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iconIv.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));

            TextView nameTv = new TextView(this);
            nameTv.setText(item.label);
            nameTv.setTextColor(isSelected ? Color.parseColor("#00F0FF") : Color.WHITE);
            nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            nameTv.setTypeface(Typeface.DEFAULT_BOLD);
            nameTv.setGravity(Gravity.CENTER);
            nameTv.setSingleLine(true);
            nameTv.setPadding(0, dp(6), 0, dp(2));

            gCard.addView(iconIv);
            gCard.addView(nameTv);

            gCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GameScannerEngine.setSelectedGame(MainActivity.this, item.packageName, item.label);
                    refreshDetectedGamesCarousel();
                    Toast.makeText(MainActivity.this, "🎯 تم اختيار: " + item.label, Toast.LENGTH_SHORT).show();
                }
            });

            if (GameScannerEngine.isCustomAddedGame(this, item.packageName)) {
                gCard.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showRemoveCustomGameDialog(item);
                        return true;
                    }
                });
            }

            gamesCarouselContainer.addView(gCard);
        }
    }

    public void showRemoveCustomGameDialog(final GameScannerEngine.GameItem item) {
        try {
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("إزالة اللعبة المخصصة")
                .setMessage("هل تريد إزالة (" + item.label + ") من قائمة المعزز؟")
                .setPositiveButton("إزالة", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GameScannerEngine.removeCustomGamePackage(MainActivity.this, item.packageName);
                        GameScannerEngine.scanInstalledGames(MainActivity.this);
                        refreshDetectedGamesCarousel();
                        Toast.makeText(MainActivity.this, "تمت إزالة: " + item.label, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
        } catch (Throwable ignored) {}
    }

    public void showAddCustomGameDialog() {
        final List<GameScannerEngine.GameItem> candidates = GameScannerEngine.listLaunchableNonGameApps(this);
        if (candidates.isEmpty()) {
            Toast.makeText(this, "جميع التطبيقات مضافة بالفعل!", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence[] titles = new CharSequence[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            titles[i] = candidates.get(i).label;
        }
        try {
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("اختر لعبة لإضافتها إلى المعزز")
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which >= 0 && which < candidates.size()) {
                            GameScannerEngine.GameItem chosen = candidates.get(which);
                            GameScannerEngine.addCustomGamePackage(MainActivity.this, chosen.packageName);
                            GameScannerEngine.setSelectedGame(MainActivity.this, chosen.packageName, chosen.label);
                            GameScannerEngine.scanInstalledGames(MainActivity.this);
                            refreshDetectedGamesCarousel();
                        }
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
        } catch (Throwable ignored) {}
    }

    public void refreshNetModePills() {
        if (pill4GView != null) styleModePill(pill4GView, currentNetMode == 0);
        if (pillAdslView != null) styleModePill(pillAdslView, currentNetMode == 1);
    }

    public void refreshGpuProfileStyles() {
        for (int i = 0; i < profileViews.size(); i++) {
            LinearLayout view = profileViews.get(i);
            Drawable d = view.getBackground();
            if (d instanceof GradientDrawable) {
                GradientDrawable bg = (GradientDrawable) d;
                if (i == selectedGpuProfile) {
                    bg.setColor(Color.parseColor("#172B4D"));
                    bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
                } else {
                    bg.setColor(Color.parseColor("#10141D"));
                    bg.setStroke(dp(1), Color.parseColor("#1F2637"));
                }
            }
        }
    }

    public TextView createMiniHwChip(String text, String colorHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#0B0F19"));
        bg.setCornerRadius((float) dp(10));
        bg.setStroke(dp(1), Color.parseColor("#1E293B"));

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(4), dp(6), dp(4), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    public TextView createHeaderSmallButton(String text, String bgHex, String strokeHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(10));
        bg.setStroke(dp(1), Color.parseColor(strokeHex));

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(strokeHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(10), dp(5), dp(10), dp(5));
        tv.setOnClickListener(onClick);
        return tv;
    }

    public LinearLayout createSleekCard(String bgHex, String strokeHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(18));
        bg.setStroke(dp(1), Color.parseColor(strokeHex));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(bg);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        return card;
    }

    public TextView createModePill(String title, View.OnClickListener onClick) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public void styleModePill(TextView tv, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(12));
        if (selected) {
            bg.setColor(Color.parseColor("#172B4D"));
            bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
        } else {
            bg.setColor(Color.parseColor("#0E121B"));
            bg.setStroke(dp(1), Color.parseColor("#1F2637"));
        }
        tv.setBackground(bg);
        tv.setTextColor(selected ? Color.parseColor("#00F0FF") : Color.parseColor("#94A3B8"));
    }

    public void applyTogglePillStyle(TextView pillBtn, boolean state) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(14));
        if (state) {
            bg.setColor(Color.parseColor("#064E3B"));
            bg.setStroke(dp(1), Color.parseColor("#10B981"));
        } else {
            bg.setColor(Color.parseColor("#1E293B"));
            bg.setStroke(dp(1), Color.parseColor("#475569"));
        }
        pillBtn.setBackground(bg);
        pillBtn.setText(state ? "مفعّل ✓" : "متوقف");
        pillBtn.setTextColor(state ? Color.parseColor("#34D399") : Color.parseColor("#94A3B8"));
    }

    public LinearLayout createModernToggleRow(
        String title,
        String subtitle,
        final boolean initialState,
        final ToggleCallback callback
    ) {
        final int[] stateHolder = new int[]{initialState ? 1 : 0};
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        textCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        textCol.setPadding(0, 0, dp(10), 0);

        TextView tTv = new TextView(this);
        tTv.setText(title);
        tTv.setTextColor(Color.WHITE);
        tTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tTv.setTypeface(Typeface.DEFAULT_BOLD);

        TextView sTv = new TextView(this);
        sTv.setText(subtitle);
        sTv.setTextColor(Color.parseColor("#94A3B8"));
        sTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        sTv.setPadding(0, dp(2), 0, 0);

        textCol.addView(tTv);
        textCol.addView(sTv);

        final TextView pillBtn = new TextView(this);
        pillBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        pillBtn.setTypeface(Typeface.DEFAULT_BOLD);
        pillBtn.setGravity(Gravity.CENTER);
        pillBtn.setPadding(dp(12), dp(6), dp(12), dp(6));

        applyTogglePillStyle(pillBtn, stateHolder[0] != 0);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stateHolder[0] = (stateHolder[0] == 0) ? 1 : 0;
                applyTogglePillStyle(pillBtn, stateHolder[0] != 0);
                callback.onToggled(stateHolder[0] != 0);
            }
        });
        row.addView(textCol);
        row.addView(pillBtn);
        return row;
    }

    public TextView createActionButton(String title, String bgHex, String textHex, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius((float) dp(14));
        bg.setStroke(dp(1), Color.parseColor(textHex));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.parseColor(textHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(10), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public void showRegionSelectorDialog() {
        try {
            final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int current = prefs.getInt("region_index", 0);
            if (current < 0 || current >= NetPingHelper.SERVER_REGIONS.length) current = 0;
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("اختر مسار الـ DNS وتقليل البنغ الفعلي")
                .setSingleChoiceItems(NetPingHelper.SERVER_REGIONS, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putInt("region_index", which).apply();
                        regionValueTv.setText(NetPingHelper.SERVER_REGIONS[which] + "  ‹");
                        dialog.dismiss();
                        triggerLivePingCheck(true);
                    }
                })
                .show();
        } catch (Throwable ignored) {}
    }

    public void showGraphicsModeSelectorDialog() {
        try {
            final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int current = prefs.getInt("downscale_index", 0);
            if (current < 0 || current >= NetPingHelper.GRAPHICS_MODES.length) current = 0;
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("اختر جودة الرسوميات والفريمات (Galaxy A07)")
                .setSingleChoiceItems(NetPingHelper.GRAPHICS_MODES, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putInt("downscale_index", which).apply();
                        downscaleValueTv.setText(NetPingHelper.GRAPHICS_MODES[which] + "  ‹");
                        dialog.dismiss();
                    }
                })
                .show();
        } catch (Throwable ignored) {}
    }

    /**
     * تشغيل التعزيز الخارق بدون أي نافذة عائمة تستهلك الرام:
     * ينفذ أوامر Shizuku للنواة والـ GPU والشبكة، ويطلق الحارس الخلفي المستقل، ثم يشغل اللعبة
     */
    public void startFullBoostSequence(final boolean launchGame) {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        pendingLaunchGame = launchGame;

        boostStatusSubTv.setText("⏳ جاري تطبيق أوامر النواة وتفريغ الرام وربط مسار البنغ السريع...");
        boostStatusSubTv.setTextColor(Color.parseColor("#FBBF24"));

        NetPingHelper.enableUltraNetworkAndHitRegEngine(this);

        // إذا لم تكن صلاحية Shizuku مفعلة، نستخدم جدار العزل المحلي؛ أما مع Shizuku فيعمل عزل النواة المباشر بصفر تأخير
        if (prefs.getBoolean("isolate_bg", true) && !ShizukuShellEngine.hasShizukuPermission()) {
            try {
                Intent prep = VpnService.prepare(this);
                if (prep != null) {
                    startActivityForResult(prep, VPN_REQ);
                    return;
                } else {
                    startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_START));
                }
            } catch (Throwable ignored) {}
        }

        executeCoreBoostAndOptionalLaunch(launchGame);
    }

    public void executeCoreBoostAndOptionalLaunch(final boolean launchGame) {
        final SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final long freedMb = NetPingHelper.optimizeGpuAndRam(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshHardwareChips();
                        mainBoostBtn.setText("مُعزّز ✓");
                        String targetGameName = GameScannerEngine.getActiveGameName(MainActivity.this);
                        String pingInfo = NetPingHelper.lastMeasuredPingMs > 0
                            ? " (البنغ: " + NetPingHelper.lastMeasuredPingMs + "ms)"
                            : "";
                        if (ShizukuShellEngine.hasShizukuPermission()) {
                            boostStatusSubTv.setText("🔥 تم تفعيل Shizuku Pro + حارس GOS + وضع الأولوية لـ " + targetGameName + pingInfo);
                        } else {
                            boostStatusSubTv.setText("⚡ تم تعزيز " + targetGameName + " وتثبيت البنغ وتفريغ الرام" + pingInfo);
                        }
                        boostStatusSubTv.setTextColor(Color.parseColor("#10B981"));

                        if (launchGame) {
                            final boolean autoExit = prefs.getBoolean("zero_ram_exit", true);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    launchSelectedGameAndFreeRam(autoExit);
                                }
                            }, 250L);
                        } else {
                            String ramMsg = freedMb > 0 ? " (تحرير " + freedMb + "MB)" : "";
                            Toast.makeText(MainActivity.this, "⚡ تم تطبيق أقصى تعزيز للهاتف والشبكة بنجاح!" + ramMsg, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    public void launchSelectedGameAndFreeRam(boolean autoCloseActivity) {
        String activePkg = GameScannerEngine.getActiveGamePackage(this);
        String activeName = GameScannerEngine.getActiveGameName(this);
        try {
            if (activePkg != null && activePkg.length() > 0) {
                Intent launch = getPackageManager().getLaunchIntentForPackage(activePkg);
                if (launch != null) {
                    Toast.makeText(this, "🚀 تم تشغيل " + activeName + " مع حارس الأداء الخلفي وأقل بنغ!", Toast.LENGTH_SHORT).show();
                    startActivity(launch);
                    if (autoCloseActivity) {
                        finish();
                    }
                    return;
                }
            }
        } catch (Throwable ignored) {}
        Toast.makeText(this, "⚡ تم تفعيل التعزيز الخارق! افتح لعبتك الآن", Toast.LENGTH_LONG).show();
    }

    public void stopAllBoostServices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ShizukuShellEngine.restoreNormalSystemState(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshHardwareChips();
                    }
                });
            }
        }).start();
        try {
            Intent stopVpnIntent = new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_STOP);
            startService(stopVpnIntent);
        } catch (Throwable ignored) {
            try {
                stopService(new Intent(this, GuardVpnService.class));
            } catch (Throwable ignored2) {}
        }
        NetPingHelper.disableUltraNetworkEngine();
        mainBoostBtn.setText("🚀 تعزيز وتشغيل");
        boostStatusSubTv.setText("تم إيقاف التعزيز واستعادة إعدادات النظام الطبيعية");
        boostStatusSubTv.setTextColor(Color.parseColor("#94A3B8"));
        Toast.makeText(this, "🛑 تم إيقاف التعزيز واستعادة إعدادات النظام بالكامل", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQ && resultCode == RESULT_OK) {
            try {
                startService(new Intent(this, GuardVpnService.class).setAction(GuardVpnService.ACTION_START));
            } catch (Throwable ignored) {}
            executeCoreBoostAndOptionalLaunch(pendingLaunchGame);
        }
    }
}
