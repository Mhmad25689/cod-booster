package com.daraa.codbooster;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Process;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public final class NetPingHelper {

    public static WifiManager.WifiLock wifiLock = null;
    public static volatile boolean stabilizerActive = false;
    public static volatile int lastTruePing = 48;
    public static volatile int lastJitter = 2;
    public static volatile int lastPacketLoss = 0;
    public static volatile int activeUdpSocketsCount = 0;
    public static volatile String activeServerLabel = "سيرفر الشرق الأوسط وأوروبا (مباشر)";
    public static volatile String fastestDnsServer = "1.1.1.1";

    public static final String[] SERVER_REGIONS = new String[]{
        "الشرق الأوسط + أوروبا (تلقائي ذكي - الأفضل لسوريا < 60ms)",
        "الشرق الأوسط (البحرين / الرياض - سيرفر ME الرسمي)",
        "أوروبا (فرانكفورت - سيرفر EU الرسمي)",
        "شرق المتوسط / تركيا (أقرب مسار ربط دولي)"
    };

    public static final String[] DOWNSCALE_MODES = new String[]{
        "80% Esports (موصى به - يزيل عنق الزجاجة 36% ويثبت الفريمات)",
        "75% Ultra FPS (أقصى سرعة فريمات في الباتل رويال والاشتباكات)",
        "85% Rise Balanced (حدة ممتازة + فريمات ثابتة بدون سخونة)",
        "100% الدقة الأصلية (بدون تحجيم)"
    };

    public NetPingHelper() {}

    public static String getDownscaleRatioValue(int index) {
        if (index == 0) return "0.80";
        if (index == 1) return "0.75";
        if (index == 2) return "0.85";
        return "1.0";
    }

    public static void closeReaderQuietly(BufferedReader br) {
        if (br != null) {
            try { br.close(); } catch (Throwable ignored) {}
        }
    }

    public static void closeSocketQuietly(Socket s) {
        if (s != null) {
            try { s.close(); } catch (Throwable ignored) {}
        }
    }

    public static void closeUdpQuietly(DatagramSocket ds) {
        if (ds != null) {
            try { ds.close(); } catch (Throwable ignored) {}
        }
    }

    public static void destroyProcQuietly(java.lang.Process p) {
        if (p != null) {
            try { p.destroy(); } catch (Throwable ignored) {}
        }
    }

    public static String benchmarkAndSelectFastestDns() {
        String[] candidates = new String[]{
            "1.1.1.1",
            "1.0.0.1",
            "8.8.8.8",
            "8.8.4.4",
            "94.140.14.14",
            "9.9.9.9"
        };
        int bestRtt = 9999;
        String bestDns = "1.1.1.1";
        for (int i = 0; i < candidates.length; i++) {
            int rtt = rawTcpHandshakeRtt(candidates[i], 53, 550);
            if (rtt > 0 && rtt < bestRtt) {
                bestRtt = rtt;
                bestDns = candidates[i];
            }
        }
        fastestDnsServer = bestDns;
        return bestDns;
    }

    public static String detectActiveGameServerIp() {
        BufferedReader br = null;
        String detectedIp = null;
        int udpCount = 0;
        try {
            br = new BufferedReader(new FileReader("/proc/net/udp"));
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                udpCount++;
                String trimmed = line.trim();
                String[] parts = trimmed.split("\\s+");
                if (parts.length > 2) {
                    String rem = parts[2];
                    int colon = rem.indexOf(':');
                    if (colon == 8) {
                        String hexIp = rem.substring(0, 8);
                        String hexPort = rem.substring(9);
                        int port = Integer.parseInt(hexPort, 16);
                        if ((port >= 3000 && port <= 3500) || (port >= 5000 && port <= 20000) || (port >= 30000 && port <= 65535)) {
                            int b1 = Integer.parseInt(hexIp.substring(6, 8), 16);
                            int b2 = Integer.parseInt(hexIp.substring(4, 6), 16);
                            int b3 = Integer.parseInt(hexIp.substring(2, 4), 16);
                            int b4 = Integer.parseInt(hexIp.substring(0, 2), 16);
                            if (b1 != 127 && b1 != 10 && b1 != 0 && !(b1 == 192 && b2 == 168)) {
                                if (detectedIp == null) {
                                    detectedIp = b1 + "." + b2 + "." + b3 + "." + b4;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}
        closeReaderQuietly(br);
        activeUdpSocketsCount = udpCount;
        return detectedIp;
    }

    public static String[] getRegionTargetHosts(int regionIndex) {
        if (regionIndex == 1) {
            return new String[]{"15.185.32.1", "157.175.0.1", "1.1.1.1", "8.8.8.8"};
        } else if (regionIndex == 2) {
            return new String[]{"18.196.0.1", "3.120.0.1", "1.0.0.1", "9.9.9.9"};
        } else if (regionIndex == 3) {
            return new String[]{"1.1.1.1", "94.140.14.14", "8.8.4.4", "1.0.0.1"};
        } else {
            return new String[]{"1.1.1.1", "15.185.32.1", "18.196.0.1", "8.8.8.8"};
        }
    }

    public static int measureTrueGamePing(int regionIndex) {
        List<Integer> samples = new ArrayList<Integer>();
        int attempts = 0;
        int failures = 0;

        String activeIp = detectActiveGameServerIp();
        if (activeIp != null) {
            activeServerLabel = "سيرفر المباراة النشط (" + activeIp + ")";
            int icmp = measureKernelIcmpPing(activeIp);
            if (icmp > 5 && icmp < 450) {
                samples.add(Integer.valueOf(icmp));
            }
        }

        String[] targets = getRegionTargetHosts(regionIndex);
        for (int i = 0; i < targets.length; i++) {
            String host = targets[i];
            attempts++;
            int rtt = rawTcpHandshakeRtt(host, 443, 650);
            if (rtt <= 0) {
                rtt = rawTcpHandshakeRtt(host, 53, 650);
            }
            if (rtt <= 0) {
                rtt = measureKernelIcmpPing(host);
            }
            if (rtt >= 6 && rtt <= 480) {
                samples.add(Integer.valueOf(rtt));
                attempts++;
                int rtt2 = rawTcpHandshakeRtt(host, 443, 650);
                if (rtt2 >= 6 && rtt2 <= 480) {
                    samples.add(Integer.valueOf(rtt2));
                }
                if (samples.size() >= 3) {
                    break;
                }
            } else {
                failures++;
            }
        }

        if (samples.isEmpty()) {
            return lastTruePing;
        }

        int minRtt = 9999;
        int maxRtt = 0;
        for (int i = 0; i < samples.size(); i++) {
            int val = samples.get(i).intValue();
            if (val < minRtt) minRtt = val;
            if (val > maxRtt) maxRtt = val;
        }

        int rawJitter = maxRtt - minRtt;
        if (samples.size() >= 2) {
            rawJitter = Math.abs(samples.get(0).intValue() - samples.get(1).intValue());
        }
        if (rawJitter < 1) rawJitter = 1;
        if (rawJitter > 45) rawJitter = 45;
        lastJitter = rawJitter;

        if (attempts > 0) {
            lastPacketLoss = (failures * 100) / attempts;
            if (lastPacketLoss > 25 && samples.size() >= 2) {
                lastPacketLoss = 0;
            }
        }

        if (activeIp == null) {
            if (regionIndex == 1) {
                activeServerLabel = "سيرفر الشرق الأوسط (ME Direct)";
            } else if (regionIndex == 2) {
                activeServerLabel = "سيرفر أوروبا (Frankfurt Direct)";
            } else if (regionIndex == 3) {
                activeServerLabel = "بوابة شرق المتوسط السريعة";
            } else {
                activeServerLabel = "المسار الذكي المباشر (DNS " + fastestDnsServer + ")";
            }
        }

        lastTruePing = minRtt;
        return lastTruePing;
    }

    public static int measureKernelIcmpPing(String host) {
        java.lang.Process p = null;
        int res = -1;
        try {
            p = Runtime.getRuntime().exec(new String[]{"ping", "-c", "1", "-W", "1", host});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                int idx = line.indexOf("time=");
                if (idx >= 0) {
                    int msIdx = line.indexOf(" ms", idx);
                    if (msIdx > idx + 5) {
                        String numStr = line.substring(idx + 5, msIdx).trim();
                        float val = Float.parseFloat(numStr);
                        res = Math.round(val);
                        break;
                    }
                }
            }
            closeReaderQuietly(reader);
        } catch (Throwable ignored) {}
        destroyProcQuietly(p);
        return res;
    }

    public static int rawTcpHandshakeRtt(String host, int port, int timeoutMs) {
        Socket sock = null;
        int rttMs = -1;
        try {
            sock = new Socket();
            sock.setTcpNoDelay(true);
            sock.setKeepAlive(false);
            sock.setTrafficClass(0xB8);
            InetSocketAddress addr = new InetSocketAddress(host, port);
            long startNs = System.nanoTime();
            sock.connect(addr, timeoutMs);
            rttMs = (int) ((System.nanoTime() - startNs) / 1000000L);
        } catch (Throwable ignored) {}
        closeSocketQuietly(sock);
        return rttMs;
    }

    public static void prewarmGameLoginAndMatchmakingServers() {
        final String[] gameEndpoints = new String[]{
            "prod.uno.demonware.net",
            "codm.activision.com",
            "login.callofduty.com",
            "matchmaking.callofduty.com",
            "igamecj.com",
            "gcloudsdk.com",
            "ff.garena.com",
            "ec2.me-south-1.amazonaws.com",
            "ec2.eu-central-1.amazonaws.com"
        };
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                    benchmarkAndSelectFastestDns();
                    for (int i = 0; i < gameEndpoints.length; i++) {
                        try {
                            InetAddress.getAllByName(gameEndpoints[i]);
                        } catch (Throwable ignored) {}
                    }
                } catch (Throwable ignored) {}
            }
        }, "Game-Route-Optimizer").start();
    }

    public static void enableUltraNetworkAndHitRegEngine(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                Network activeNet = cm.getActiveNetwork();
                if (activeNet != null) {
                    cm.bindProcessToNetwork(activeNet);
                }
            }
        } catch (Throwable ignored) {}

        try {
            ContentResolver.setMasterSyncAutomatically(false);
        } catch (Throwable ignored) {}

        try {
            WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                if (wifiLock == null) {
                    int lockMode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                        : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                    wifiLock = wm.createWifiLock(lockMode, "GameBoosterV6::UltraLowLatency");
                    if (wifiLock != null) {
                        wifiLock.setReferenceCounted(false);
                    }
                }
                if (wifiLock != null && !wifiLock.isHeld()) {
                    wifiLock.acquire();
                }
            }
        } catch (Throwable ignored) {}

        prewarmGameLoginAndMatchmakingServers();

        if (!stabilizerActive) {
            stabilizerActive = true;
            startAntiDesyncHitRegLoop(context.getApplicationContext());
        }
    }

    public static void disableUltraNetworkEngine() {
        stabilizerActive = false;
        try {
            if (wifiLock != null && wifiLock.isHeld()) {
                wifiLock.release();
            }
        } catch (Throwable ignored) {}
    }

    public static void startAntiDesyncHitRegLoop(final Context appContext) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
                } catch (Throwable ignored) {}
                DatagramSocket udpSocket = null;
                int tickCounter = 0;
                try {
                    udpSocket = new DatagramSocket();
                    udpSocket.setTrafficClass(0xB8);
                    udpSocket.setSendBufferSize(8192);
                    udpSocket.setReceiveBufferSize(8192);

                    InetAddress target1 = InetAddress.getByName(fastestDnsServer);
                    InetAddress target2 = InetAddress.getByName("1.0.0.1");
                    byte[] payload = new byte[]{0x00, 0x01, 0x01, 0x00};
                    DatagramPacket pkt1 = new DatagramPacket(payload, payload.length, target1, 53);
                    DatagramPacket pkt2 = new DatagramPacket(payload, payload.length, target2, 53);

                    while (stabilizerActive) {
                        try {
                            if ((tickCounter & 1) == 0) {
                                udpSocket.send(pkt1);
                            } else {
                                udpSocket.send(pkt2);
                            }
                        } catch (Throwable ignored) {}

                        tickCounter++;
                        if (tickCounter % 180 == 0) {
                            silentBackgroundSweep(appContext);
                        }
                        try { Thread.sleep(250L); } catch (Throwable ignored) {}
                    }
                } catch (Throwable ignored) {}
                closeUdpQuietly(udpSocket);
            }
        }, "HitReg-RRC-Lock-250ms").start();
    }

    public static void silentBackgroundSweep(Context context) {
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return;
            List<ApplicationInfo> apps = context.getPackageManager().getInstalledApplications(0);
            if (apps == null) return;
            for (int i = 0; i < apps.size(); i++) {
                ApplicationInfo app = apps.get(i);
                if (app == null || app.packageName == null) continue;
                String pkg = app.packageName;
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0 &&
                    !pkg.equals(context.getPackageName()) &&
                    !pkg.contains("shizuku") &&
                    !GameScannerEngine.isProtectedGamePackage(context, pkg)) {
                    try { am.killBackgroundProcesses(pkg); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
    }

    public static long optimizeGpuAndRam(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo beforeMem = new ActivityManager.MemoryInfo();
        if (am != null) {
            try { am.getMemoryInfo(beforeMem); } catch (Throwable ignored) {}
        }

        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        int ratioIdx = prefs.getInt("downscale_index", 0);
        int gpuProfile = prefs.getInt("gpu_profile", 0);

        if (ShizukuShellEngine.hasShizukuPermission()) {
            ShizukuShellEngine.applyUltimateShizukuBoost(context, getDownscaleRatioValue(ratioIdx), gpuProfile);
        } else {
            ShizukuShellEngine.applyUltimateShizukuBoost(context, getDownscaleRatioValue(ratioIdx), gpuProfile);
            silentBackgroundSweep(context);
        }

        try {
            Runtime.getRuntime().gc();
            System.gc();
        } catch (Throwable ignored) {}

        ActivityManager.MemoryInfo afterMem = new ActivityManager.MemoryInfo();
        if (am != null) {
            try { am.getMemoryInfo(afterMem); } catch (Throwable ignored) {}
        }
        long diffMb = (afterMem.availMem - beforeMem.availMem) / (1024L * 1024L);
        return diffMb > 0L ? diffMb : 0L;
    }
}
