package com.daraa.codbooster;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Process;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;

public final class NetPingHelper {

    public static WifiManager.WifiLock wifiLock = null;
    public static volatile boolean stabilizerActive = false;
    public static volatile String fastestDnsServer = "1.1.1.1";
    public static volatile String fastestDnsHostname = "one.one.one.one";
    public static volatile int lastMeasuredPingMs = -1;

    // مسارات DNS والشبكة الفعلية (مربوطة فعلياً بنواة النظام عبر Shizuku وفاحص البنغ)
    public static final String[] SERVER_REGIONS = new String[]{
        "تلقائي ذكي (فحص واختيار أسرع DNS ومسار ألعاب فوراً)",
        "Cloudflare Gaming (1.1.1.1 - أسرع استجابة للشرق الأوسط وأوروبا)",
        "Google Public DNS (8.8.8.8 - ثبات عالي لبوابات الألعاب)",
        "Quad9 Gaming Route (9.9.9.9 - استقرار المسار ومنع التقطيع)",
        "الوضع الافتراضي للراوتر/الشبكة (بدون تغيير DNS النظام)"
    };

    public static final String[] DNS_IPS = new String[]{
        "1.1.1.1",
        "1.1.1.1",
        "8.8.8.8",
        "9.9.9.9",
        "1.1.1.1"
    };

    public static final String[] DNS_DOT_HOSTNAMES = new String[]{
        "one.one.one.one",
        "one.one.one.one",
        "dns.google",
        "dns.quad9.net",
        ""
    };

    // الافتراضي (index 0) هو 100% أعلى رسوميات + وضع الأداء الأقصى!
    public static final String[] GRAPHICS_MODES = new String[]{
        "100% أعلى رسوميات Ultra HD + أقصى فريمات (افتراضي)",
        "90% رسوميات فائقة الحدة + تعزيز إضافي للفريمات (0.90x)",
        "85% وضع البطولات التنافسي Esports السريع (0.85x)",
        "80% أقصى سرعة استجابة في المواجهات الكثيفة (0.80x)"
    };

    // حزمة استعلام DNS قياسية وخفيفة جداً (17 بايت - استعلام الجذر NS) لمنع حظر المزود للحزم الفارغة
    private static final byte[] VALID_MINIMAL_DNS_QUERY = new byte[]{
        0x13, 0x37,             // Transaction ID
        0x01, 0x00,             // Flags: Standard query (recursion desired)
        0x00, 0x01,             // Questions: 1
        0x00, 0x00,             // Answer RRs: 0
        0x00, 0x00,             // Authority RRs: 0
        0x00, 0x00,             // Additional RRs: 0
        0x00,                   // Root domain "."
        0x00, 0x02,             // Type: NS
        0x00, 0x01              // Class: IN
    };

    public NetPingHelper() {}

    public static String getDownscaleRatioValue(int index) {
        if (index == 1) return "0.90";
        if (index == 2) return "0.85";
        if (index == 3) return "0.80";
        return "1.0";
    }

    public static void closeSocketQuietly(Socket s) {
        if (s != null) {
            try { s.close(); } catch (Throwable ignored) {}
        }
    }

    public static void closeUdpQuietly(DatagramSocket ds) {
        if (ds != null) {
            try { ds.close(); } catch (Throwable ignored) {}
        }
    }

    /**
     * يفحص فعلياً أسرع مخدم DNS يستجيب لخط الراوتر أو الـ 4G في منطقتك،
     * أو يطبق المسار المختار يدوياً من الإعدادات مع قياس البنغ الحقيقي بالملي ثانية (ms)
     */
    public static String benchmarkAndSelectFastestDns(Context context) {
        int regionIndex = 0;
        if (context != null) {
            try {
                SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
                regionIndex = prefs.getInt("region_index", 0);
            } catch (Throwable ignored) {}
        }

        if (regionIndex >= 1 && regionIndex <= 3) {
            String chosenIp = DNS_IPS[regionIndex];
            String chosenHost = DNS_DOT_HOSTNAMES[regionIndex];
            int rtt = measureHostRttMs(chosenIp, 600);
            if (rtt > 0) {
                lastMeasuredPingMs = rtt;
            }
            fastestDnsServer = chosenIp;
            fastestDnsHostname = chosenHost;
            return chosenIp;
        }

        String[] candidatesIp = new String[]{
            "1.1.1.1",
            "8.8.8.8",
            "9.9.9.9",
            "94.140.14.14"
        };
        String[] candidatesHost = new String[]{
            "one.one.one.one",
            "dns.google",
            "dns.quad9.net",
            "dns.adguard-dns.com"
        };

        int bestRtt = 9999;
        String bestDns = "1.1.1.1";
        String bestHost = "one.one.one.one";

        for (int i = 0; i < candidatesIp.length; i++) {
            int rtt = measureHostRttMs(candidatesIp[i], 450);
            if (rtt > 0 && rtt < bestRtt) {
                bestRtt = rtt;
                bestDns = candidatesIp[i];
                bestHost = candidatesHost[i];
            }
        }

        if (bestRtt < 9999) {
            lastMeasuredPingMs = bestRtt;
        }
        fastestDnsServer = bestDns;
        fastestDnsHostname = (regionIndex == 4) ? "" : bestHost;
        return bestDns;
    }

    public static int measureHostRttMs(String host, int timeoutMs) {
        int rtt = rawTcpConnectMs(host, 443, timeoutMs);
        if (rtt <= 0) {
            rtt = rawTcpConnectMs(host, 53, timeoutMs);
        }
        return rtt;
    }

    public static int rawTcpConnectMs(String host, int port, int timeoutMs) {
        Socket sock = null;
        int rttMs = -1;
        try {
            sock = new Socket();
            sock.setTcpNoDelay(true);
            sock.setKeepAlive(false);
            sock.setTrafficClass(0xB8);
            InetSocketAddress addr = new InetSocketAddress(host, port);
            long startNs = System.nanoTime();
            sock.connect(addr, timeoutMs);
            rttMs = (int) ((System.nanoTime() - startNs) / 1000000L);
        } catch (Throwable ignored) {}
        closeSocketQuietly(sock);
        return rttMs;
    }

    /**
     * فتح مسبق لجميع مسارات وخوادم الدخول والمباريات لتسريع فتح اللعبة وتثبيت البنغ
     */
    public static void prewarmGameLoginAndMatchmakingServers(final Context context) {
        final String[] gameEndpoints = new String[]{
            "prod.uno.demonware.net",
            "codm.activision.com",
            "login.callofduty.com",
            "matchmaking.callofduty.com",
            "lsg.demonware.net",
            "cdn.callofduty.com",
            "dl.listdl.com",
            "igamecj.com",
            "gcloudsdk.com",
            "ff.garena.com",
            "ec2.me-south-1.amazonaws.com",
            "ec2.eu-central-1.amazonaws.com"
        };
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                    benchmarkAndSelectFastestDns(context);
                    for (int i = 0; i < gameEndpoints.length; i++) {
                        try {
                            InetAddress.getAllByName(gameEndpoints[i]);
                        } catch (Throwable ignored) {}
                    }
                } catch (Throwable ignored) {}
            }
        }, "Game-Route-Prewarmer").start();
    }

    /**
     * تفعيل محرك الشبكة الفائق للراوتر والبيانات:
     * 1. قفل الهاردوير للواي فاي في وضع الاستجابة القصوى (WIFI_MODE_FULL_LOW_LATENCY)
     * 2. إيقاف المزامنة التلقائية في الخلفية لمنع سحب الإنترنت المفاجئ
     * 3. تشغيل نبضات تثبيت الإشارة القياسية (DSCP EF 0xB8) لمنع خمول برج الـ 4G والراوتر
     */
    public static void enableUltraNetworkAndHitRegEngine(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        boolean hitRegBoost = prefs.getBoolean("hit_reg_boost", true);

        try {
            ContentResolver.setMasterSyncAutomatically(false);
        } catch (Throwable ignored) {}

        if (hitRegBoost) {
            try {
                WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    if (wifiLock == null) {
                        int lockMode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                            ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                            : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                        wifiLock = wm.createWifiLock(lockMode, "GameBoosterA07::UltraLowLatency");
                        if (wifiLock != null) {
                            wifiLock.setReferenceCounted(false);
                        }
                    }
                    if (wifiLock != null && !wifiLock.isHeld()) {
                        wifiLock.acquire();
                    }
                }
            } catch (Throwable ignored) {}
        }

        prewarmGameLoginAndMatchmakingServers(context.getApplicationContext());

        if (hitRegBoost && !stabilizerActive) {
            stabilizerActive = true;
            startAntiDesyncHitRegLoop(context.getApplicationContext());
        }
    }

    public static void disableUltraNetworkEngine() {
        stabilizerActive = false;
        try {
            if (wifiLock != null && wifiLock.isHeld()) {
                wifiLock.release();
            }
        } catch (Throwable ignored) {}
        try {
            ContentResolver.setMasterSyncAutomatically(true);
        } catch (Throwable ignored) {}
    }

    public static void startAntiDesyncHitRegLoop(final Context appContext) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                } catch (Throwable ignored) {}
                DatagramSocket udpSocket = null;
                int tickCounter = 0;
                // سقف زمني أقصى (ساعتان = 2400 نبضة كل 3 ثوانٍ) لمنع استنزاف البطارية إذا نسي المستخدم إيقاف التعزيز
                final int maxTicks = 2400;
                try {
                    udpSocket = new DatagramSocket();
                    udpSocket.setSoTimeout(1000);
                    udpSocket.setTrafficClass(0xB8); // DSCP 46 Expedited Forwarding
                    udpSocket.setSendBufferSize(4096);
                    udpSocket.setReceiveBufferSize(4096);

                    InetAddress target1 = InetAddress.getByName(fastestDnsServer);
                    InetAddress target2 = InetAddress.getByName("1.0.0.1");
                    DatagramPacket pkt1 = new DatagramPacket(
                        VALID_MINIMAL_DNS_QUERY,
                        VALID_MINIMAL_DNS_QUERY.length,
                        target1,
                        53
                    );
                    DatagramPacket pkt2 = new DatagramPacket(
                        VALID_MINIMAL_DNS_QUERY,
                        VALID_MINIMAL_DNS_QUERY.length,
                        target2,
                        53
                    );

                    while (stabilizerActive && tickCounter < maxTicks) {
                        try {
                            if ((tickCounter & 1) == 0) {
                                udpSocket.send(pkt1);
                            } else {
                                udpSocket.send(pkt2);
                            }
                        } catch (Throwable ignored) {}

                        tickCounter++;
                        if (tickCounter % 30 == 0) {
                            silentBackgroundSweep(appContext);
                        }
                        try { Thread.sleep(3000L); } catch (Throwable ignored) {}
                    }
                } catch (Throwable ignored) {}
                stabilizerActive = false;
                closeUdpQuietly(udpSocket);
            }
        }, "HitReg-RRC-Stabilizer").start();
    }

    public static void silentBackgroundSweep(Context context) {
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return;
            List<ApplicationInfo> apps = context.getPackageManager().getInstalledApplications(0);
            if (apps == null) return;
            for (int i = 0; i < apps.size(); i++) {
                ApplicationInfo app = apps.get(i);
                if (app == null || app.packageName == null) continue;
                String pkg = app.packageName;
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0 &&
                    !pkg.equals(context.getPackageName()) &&
                    !pkg.contains("shizuku") &&
                    !GameScannerEngine.isProtectedGamePackage(context, pkg)) {
                    try { am.killBackgroundProcesses(pkg); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
    }

    public static long optimizeGpuAndRam(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo beforeMem = new ActivityManager.MemoryInfo();
        if (am != null) {
            try { am.getMemoryInfo(beforeMem); } catch (Throwable ignored) {}
        }

        benchmarkAndSelectFastestDns(context);

        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        int ratioIdx = prefs.getInt("downscale_index", 0);
        int gpuProfile = prefs.getInt("gpu_profile", 0);

        if (ShizukuShellEngine.hasShizukuPermission()) {
            ShizukuShellEngine.applyUltimateA07ShizukuBoost(context, getDownscaleRatioValue(ratioIdx), gpuProfile);
        }
        silentBackgroundSweep(context);

        try {
            Runtime.getRuntime().gc();
            System.gc();
        } catch (Throwable ignored) {}

        ActivityManager.MemoryInfo afterMem = new ActivityManager.MemoryInfo();
        if (am != null) {
            try { am.getMemoryInfo(afterMem); } catch (Throwable ignored) {}
        }
        long diffMb = (afterMem.availMem - beforeMem.availMem) / (1024L * 1024L);
        return diffMb > 0L ? diffMb : 0L;
    }
}
