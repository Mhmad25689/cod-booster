package com.daraa.codbooster;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import java.util.List;

public class GuardVpnService extends VpnService {

    public static final String ACTION_START = "com.daraa.codbooster.START_VPN";
    public static final String ACTION_STOP = "com.daraa.codbooster.STOP_VPN";

    // قائمة التطبيقات الشرهة للإنترنت في الخلفية (تم استثناء Discord والمتصفحات لعدم قطع الدردشة الصوتية أو تسجيل الدخول)
    public static final String[] NOISY_BG_KEYWORDS = new String[]{
        "whatsapp", "facebook", "instagram", "tiktok", "zhiliaoapp",
        "telegram", "snapchat", "youtube", "twitter",
        "vending", "kwai", "likee", "pinterest", "threads",
        "imo", "viber", "messenger", "onedrive", "dropbox",
        "google.android.apps.photos", "google.android.apps.docs",
        "samsung.android.scloud", "sec.android.app.samsungapps",
        "samsung.android.game.gos", "samsung.android.rubin"
    };

    public ParcelFileDescriptor vpnInterface = null;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopVpn();
            NetPingHelper.disableUltraNetworkEngine();
            try { stopSelf(); } catch (Throwable ignored) {}
            return START_NOT_STICKY;
        }
        // الحفاظ على قفل الـ Wi-Fi ونبضات ثبات الشبكة داخل الخدمة حتى لو أُغلقت واجهة التطبيق (وضع صفر رام)
        NetPingHelper.enableUltraNetworkAndHitRegEngine(getApplicationContext());
        establishSmartFirewall();
        return START_STICKY;
    }

    public synchronized void establishSmartFirewall() {
        if (vpnInterface != null) return;

        try {
            SharedPreferences prefs = getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
            boolean isolateBg = prefs.getBoolean("isolate_bg", true);
            if (!isolateBg) {
                return;
            }

            int netMode = prefs.getInt("net_mode", 0);
            int optimalMtu = (netMode == 1) ? 1440 : 1360;
            String dns = NetPingHelper.fastestDnsServer;
            if (dns == null || dns.length() == 0) dns = "1.1.1.1";

            // جدار عزل صامت (Sinkhole) يحجز تطبيقات الخلفية الشرهة فقط ويترك مسار اللعبة وتطبيقات الصوت مفتوحاً 100%
            Builder builder = new Builder()
                .setSession("GameBooster_A07_Shield")
                .setMtu(optimalMtu)
                .addAddress("10.215.173.1", 30)
                .addDnsServer(dns)
                .addDnsServer("1.0.0.1")
                .addRoute("0.0.0.0", 0);

            List<ApplicationInfo> installed = getPackageManager().getInstalledApplications(0);
            int isolatedCount = 0;

            if (installed != null) {
                for (int i = 0; i < installed.size(); i++) {
                    ApplicationInfo app = installed.get(i);
                    if (app == null || app.packageName == null) continue;
                    String pkg = app.packageName;
                    String pkgLower = pkg.toLowerCase();

                    if (pkg.equals(getPackageName()) ||
                        pkgLower.contains("shizuku") ||
                        GameScannerEngine.isProtectedGamePackage(this, pkg)) {
                        continue;
                    }

                    boolean isNoisyApp = false;
                    for (int k = 0; k < NOISY_BG_KEYWORDS.length; k++) {
                        if (pkgLower.contains(NOISY_BG_KEYWORDS[k])) {
                            isNoisyApp = true;
                            break;
                        }
                    }

                    if (isNoisyApp) {
                        try {
                            builder.addAllowedApplication(pkg);
                            isolatedCount++;
                        } catch (Throwable ignored) {}
                    }
                }
            }

            if (isolatedCount > 0) {
                vpnInterface = builder.establish();
            }
        } catch (Throwable ignored) {}
    }

    public synchronized void stopVpn() {
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (Throwable ignored) {}
            vpnInterface = null;
        }
    }

    @Override
    public void onRevoke() {
        stopVpn();
        NetPingHelper.disableUltraNetworkEngine();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }
}
