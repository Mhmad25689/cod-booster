package com.daraa.codbooster;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import java.util.List;

public class GuardVpnService extends VpnService {

    public static final String ACTION_START = "com.daraa.codbooster.START_VPN";
    public static final String ACTION_STOP = "com.daraa.codbooster.STOP_VPN";

    public static final String[] NOISY_BG_KEYWORDS = new String[]{
        "whatsapp", "facebook", "instagram", "tiktok", "zhiliaoapp",
        "telegram", "snapchat", "youtube", "twitter", "chrome",
        "vending", "browser", "kwai", "likee", "pinterest", "threads",
        "discord", "imo", "viber", "messenger", "onedrive", "dropbox",
        "google.android.apps.photos", "google.android.apps.docs",
        "samsung.android.scloud", "sec.android.app.samsungapps",
        "samsung.android.game.gos", "samsung.android.rubin"
    };

    public ParcelFileDescriptor vpnInterface = null;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopVpn();
            stopSelf();
            return START_NOT_STICKY;
        }
        establishSmartFirewall();
        return START_STICKY;
    }

    /**
     * جدار عزل ذكي (Split-Tunnel Sinkhole):
     * يحبس جميع تطبيقات الخلفية الشرهة داخل نفق محلي مغلق،
     * بينما يستثني لعبة كود موبايل تماماً لتتصل مباشرة بالراوتر/4G بصفر تأخير تشفير (أسرع من GearUP).
     */
    public void establishSmartFirewall() {
        if (vpnInterface != null) return;

        SharedPreferences prefs = getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        boolean isolateBg = prefs.getBoolean("isolate_bg", true);
        if (!isolateBg) {
            stopSelf();
            return;
        }

        int netMode = prefs.getInt("net_mode", 0);
        // ضبط MTU المثالي: 1360 لشبكات 4G سيريتل/MTN لمنع تجزئة الحزم، و1440 لراوتر ADSL/VDSL
        int optimalMtu = (netMode == 1) ? 1440 : 1360;

        try {
            Builder builder = new Builder()
                .setSession("COD_DirectRoute_ZeroLag_Shield")
                .setMtu(optimalMtu)
                .addAddress("10.215.173.1", 30)
                .addDnsServer(NetPingHelper.fastestDnsServer)
                .addDnsServer("1.0.0.1")
                .addRoute("0.0.0.0", 0);

            List<ApplicationInfo> installed = getPackageManager().getInstalledApplications(0);
            int isolatedCount = 0;

            if (installed != null) {
                for (int i = 0; i < installed.size(); i++) {
                    ApplicationInfo app = installed.get(i);
                    if (app.packageName == null) continue;
                    String pkg = app.packageName.toLowerCase();

                    boolean isCod = pkg.contains("callofduty") || pkg.contains("codm") || pkg.contains("activision");
                    boolean isShizuku = pkg.contains("shizuku");
                    boolean isOurApp = app.packageName.equals(getPackageName());
                    if (isCod || isShizuku || isOurApp) {
                        continue;
                    }

                    boolean isUserApp = (app.flags & ApplicationInfo.FLAG_SYSTEM) == 0;
                    boolean isNoisyApp = false;
                    for (int k = 0; k < NOISY_BG_KEYWORDS.length; k++) {
                        if (pkg.contains(NOISY_BG_KEYWORDS[k])) {
                            isNoisyApp = true;
                            break;
                        }
                    }

                    if (isUserApp || isNoisyApp) {
                        try {
                            builder.addAllowedApplication(app.packageName);
                            isolatedCount++;
                        } catch (Throwable ignored) {}
                    }
                }
            }

            if (isolatedCount > 0) {
                vpnInterface = builder.establish();
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public void stopVpn() {
        try {
            if (vpnInterface != null) {
                vpnInterface.close();
            }
        } catch (Throwable ignored) {
        } finally {
            vpnInterface = null;
        }
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }
}
