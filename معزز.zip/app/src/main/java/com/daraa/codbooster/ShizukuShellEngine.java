package com.daraa.codbooster;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;
import rikka.shizuku.Shizuku;

public final class ShizukuShellEngine {

    // حزم سامسونج المسؤولة عن الخنق الحراري وتقليص الفريمات وعنق الزجاجة في Galaxy A07 4G
    public static final String[] SAMSUNG_A07_THROTTLE_PACKAGES = new String[]{
        "com.samsung.android.game.gos",
        "com.samsung.android.sdhms",
        "com.samsung.android.game.gametools",
        "com.samsung.android.game.gamehome",
        "com.samsung.android.scloud",
        "com.sec.android.app.samsungapps",
        "com.samsung.android.app.routines",
        "com.samsung.android.rubin.app",
        "com.samsung.android.fmm",
        "com.samsung.android.mdm",
        "com.samsung.android.MtpApplication",
        "com.samsung.android.app.reminder"
    };

    // حزم سامسونج الخدمية التي يُعاد تفعيل عملها في الخلفية فور انتهاء جلسة اللعب
    public static final String[] SAMSUNG_RESTORABLE_USER_PACKAGES = new String[]{
        "com.samsung.android.app.reminder",
        "com.samsung.android.app.routines",
        "com.samsung.android.MtpApplication",
        "com.samsung.android.scloud"
    };

    public ShizukuShellEngine() {}

    public static boolean isShizukuAvailable() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean hasShizukuPermission() {
        if (!isShizukuAvailable()) return false;
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestPermission(int requestCode) {
        try {
            if (isShizukuAvailable() && !hasShizukuPermission()) {
                Shizuku.requestPermission(requestCode);
            }
        } catch (Throwable ignored) {}
    }

    public static String getShizukuIdentityLabel() {
        if (!hasShizukuPermission()) return "غير متصل";
        try {
            int uid = Shizuku.getUid();
            if (uid == 0) return "ROOT UID 0";
            if (uid == 2000) return "ADB Shell UID 2000";
        } catch (Throwable ignored) {}
        return "UID 2000 نشط";
    }

    public static void destroyProcessQuietly(Process p) {
        if (p != null) {
            try { p.destroy(); } catch (Throwable ignored) {}
        }
    }

    private static Process createShizukuProcess(String[] cmd) {
        try {
            Method method = Shizuku.class.getDeclaredMethod(
                "newProcess",
                String[].class,
                String[].class,
                String.class
            );
            method.setAccessible(true);
            return (Process) method.invoke(null, cmd, null, null);
        } catch (Throwable ignored) {
            return null;
        }
    }

    /**
     * تنفيذ أوامر النواة الحقيقية عبر Shizuku.newProcess (بصلاحية ADB UID 2000 أو Root UID 0)
     */
    public static String execShell(String command) {
        if (command == null || command.length() == 0) return "";
        if (!hasShizukuPermission()) return "";

        Process proc = null;
        try {
            proc = createShizukuProcess(new String[]{"sh", "-c", command});
            if (proc != null) {
                try { proc.getOutputStream().close(); } catch (Throwable ignored) {}
                BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                StringBuilder out = new StringBuilder();
                String line = reader.readLine();
                while (line != null) {
                    out.append(line).append("\n");
                    line = reader.readLine();
                }
                proc.waitFor();
                try { reader.close(); } catch (Throwable ignored) {}
                try { proc.getErrorStream().close(); } catch (Throwable ignored) {}
                destroyProcessQuietly(proc);
                return out.toString().trim();
            }
        } catch (Throwable ignored) {}
        destroyProcessQuietly(proc);
        return "";
    }

    /**
     * تشغيل حارس خلفي مستقل (Detached Shell Daemon) داخل خادم Shizuku
     * يعمل بصفر ميغابايت من رام التطبيق حتى بعد إغلاق المعزز (Zero-RAM Mode)
     */
    public static void execDetachedShellDaemon(String backgroundScript) {
        if (backgroundScript == null || backgroundScript.length() == 0) return;
        if (!hasShizukuPermission()) return;

        Process proc = null;
        try {
            String wrapped = "( " + backgroundScript + " ) </dev/null >/dev/null 2>&1 &";
            proc = createShizukuProcess(new String[]{"sh", "-c", wrapped});
            if (proc != null) {
                try { proc.getInputStream().close(); } catch (Throwable ignored) {}
                try { proc.getErrorStream().close(); } catch (Throwable ignored) {}
                try { proc.getOutputStream().close(); } catch (Throwable ignored) {}
                proc.waitFor();
            }
        } catch (Throwable ignored) {}
        destroyProcessQuietly(proc);
    }

    /**
     * المحرك الشامل لفك عنق الزجاجة في Samsung Galaxy A07 4G (6GB/128GB)
     * يتفوق على معزز سامسونج الرسمي (Game Booster Plus + Priority Mode) غير المدعوم على A07
     */
    public static int applyUltimateA07ShizukuBoost(Context context, String downscaleRatio, int gpuProfile) {
        if (!hasShizukuPermission()) return 0;

        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        boolean killGos = prefs.getBoolean("kill_gos", true);
        boolean speedCompile = prefs.getBoolean("speed_compile", true);
        boolean isolateBg = prefs.getBoolean("isolate_bg", true);
        boolean hitRegBoost = prefs.getBoolean("hit_reg_boost", true);
        boolean blockHeadsUp = prefs.getBoolean("block_heads_up", true);
        boolean lockBrightness = prefs.getBoolean("lock_brightness", true);
        boolean gosWatchdog = prefs.getBoolean("gos_watchdog", true);
        int regionIndex = prefs.getInt("region_index", 0);

        String activeGamePkg = GameScannerEngine.getActiveGamePackage(context);
        int hz = HardwareProfiler.readDisplayRefreshRate(context);
        int maxHz = hz >= 90 ? hz : 90;

        StringBuilder cmds = new StringBuilder();

        // إيقاف أي حارس قديم قبل بدء جلسة تعزيز جديدة
        cmds.append("pkill -f A07_HYPER_WATCHDOG 2>/dev/null; ");

        // 1. تجميد خدمات الخنق الحراري في سامسونج (GOS & SDHMS) التي تسبب عنق الزجاجة في Galaxy A07
        if (killGos) {
            for (int i = 0; i < SAMSUNG_A07_THROTTLE_PACKAGES.length; i++) {
                String p = SAMSUNG_A07_THROTTLE_PACKAGES[i];
                cmds.append("am force-stop ").append(p).append(" 2>/dev/null; ");
                cmds.append("cmd appops set ").append(p).append(" RUN_IN_BACKGROUND ignore 2>/dev/null; ");
                cmds.append("cmd appops set ").append(p).append(" RUN_ANY_IN_BACKGROUND ignore 2>/dev/null; ");
                cmds.append("cmd appops set ").append(p).append(" WAKE_LOCK ignore 2>/dev/null; ");
                cmds.append("am set-standby-bucket ").append(p).append(" restricted 2>/dev/null; ");
            }
        }

        // 2. تطبيق وضع المعالج والرسوميات والحرارة الفعلي حسب اختيار المستخدم (3 أوضاع حقيقية ومختلفة)
        String effectiveRatio = downscaleRatio;
        if (gpuProfile == 0) {
            // الوضع 0: الأداء الخارق (Diablo Ultra) - قفل 90Hz كامل + إلغاء الخنق الحراري + أقصى طاقة
            cmds.append("settings put system peak_refresh_rate ").append(maxHz).append(".0 2>/dev/null; ");
            cmds.append("settings put system min_refresh_rate ").append(maxHz).append(".0 2>/dev/null; ");
            cmds.append("cmd power set-fixed-performance-mode-enabled true 2>/dev/null; ");
            cmds.append("cmd power set-adaptive-power-saver-enabled false 2>/dev/null; ");
            cmds.append("cmd power set-mode 0 2>/dev/null; ");
            cmds.append("cmd thermalservice override-status 0 2>/dev/null; ");
        } else if (gpuProfile == 1) {
            // الوضع 1: المتوازن الذكي للمباريات الطويلة - تردد مرن 60-90Hz + أداء ثابت مع حماية حرارة البطارية
            cmds.append("settings put system peak_refresh_rate ").append(maxHz).append(".0 2>/dev/null; ");
            cmds.append("settings put system min_refresh_rate 60.0 2>/dev/null; ");
            cmds.append("cmd power set-fixed-performance-mode-enabled true 2>/dev/null; ");
            cmds.append("cmd power set-adaptive-power-saver-enabled false 2>/dev/null; ");
            cmds.append("cmd power set-mode 0 2>/dev/null; ");
            cmds.append("cmd thermalservice reset 2>/dev/null; ");
            if ("1.0".equals(effectiveRatio)) {
                effectiveRatio = "0.90";
            }
        } else {
            // الوضع 2: التبريد الفائق ومنع الهبوط الحراري - سقف 60Hz لتبريد المعالج الرسومي والبطارية فوراً
            cmds.append("settings put system peak_refresh_rate 60.0 2>/dev/null; ");
            cmds.append("settings put system min_refresh_rate 60.0 2>/dev/null; ");
            cmds.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null; ");
            cmds.append("cmd power set-adaptive-power-saver-enabled false 2>/dev/null; ");
            cmds.append("cmd power set-mode 0 2>/dev/null; ");
            cmds.append("cmd thermalservice reset 2>/dev/null; ");
            if ("1.0".equals(effectiveRatio) || "0.90".equals(effectiveRatio)) {
                effectiveRatio = "0.80";
            }
        }

        // 3. تخصيص تعريف الهاردوير الرسومي (System Game Driver) ووضع Android Game Mode للعبة المختارة فقط لسرعة الاستجابة
        PackageManager pm = context.getPackageManager();
        applyGameKernelOptimization(cmds, pm, activeGamePkg, effectiveRatio, gpuProfile, maxHz);

        cmds.append("settings put global game_driver_opt_in_apps ").append(activeGamePkg).append(" 2>/dev/null; ");
        cmds.append("settings put global updatable_driver_production_opt_in_apps ").append(activeGamePkg).append(" 2>/dev/null; ");

        // 4. ميزات Samsung Game Booster Priority Mode (حجب الإشعارات العائمة + تثبيت السطوع + تسريع اللمس)
        if (blockHeadsUp) {
            cmds.append("settings put global heads_up_notifications_enabled 0 2>/dev/null; ");
        }
        if (lockBrightness) {
            cmds.append("settings put system screen_brightness_mode 0 2>/dev/null; ");
        }
        cmds.append("settings put system pointer_speed 7 2>/dev/null; ");
        cmds.append("settings put global window_animation_scale 0.0 2>/dev/null; ");
        cmds.append("settings put global transition_animation_scale 0.0 2>/dev/null; ");
        cmds.append("settings put global animator_duration_scale 0.0 2>/dev/null; ");

        // 5. محرك تقليل وتثبيت البنغ الحقيقي للراوتر (Wi-Fi) والبيانات (4G LTE) + ربط DNS النظام الفعلي
        if (hitRegBoost) {
            cmds.append("cmd wifi force-low-latency-mode enabled 2>/dev/null; ");
            cmds.append("cmd wifi force-hi-perf-mode enabled 2>/dev/null; ");
            cmds.append("cmd wifi set-wifi-saver-enabled false 2>/dev/null; ");
            cmds.append("settings put global wifi_scan_always_enabled 0 2>/dev/null; ");
            cmds.append("settings put global ble_scan_always_enabled 0 2>/dev/null; ");
            cmds.append("settings put global network_recommendations_enabled 0 2>/dev/null; ");
            cmds.append("settings put global mobile_data_always_on 1 2>/dev/null; ");
        }

        // ربط منطقة ومسار الـ DNS المختار فعلياً على مستوى النظام بالكامل لتستفيد منه اللعبة مباشرة
        String dnsHost = NetPingHelper.fastestDnsHostname;
        if (regionIndex == 4 || dnsHost == null || dnsHost.length() == 0) {
            cmds.append("settings put global private_dns_mode opportunistic 2>/dev/null; ");
        } else {
            cmds.append("settings put global private_dns_mode hostname 2>/dev/null; ");
            cmds.append("settings put global private_dns_specifier ").append(dnsHost).append(" 2>/dev/null; ");
        }

        if (isolateBg) {
            // عزل الإنترنت على مستوى نواة أندرويد (Kernel Netpolicy) بدون أي تأخير VPN
            cmds.append("cmd netpolicy set restrict-background true 2>/dev/null; ");
        }

        // 6. إيقاف إجباري كامل (am force-stop) لجميع تطبيقات الخلفية التي تستهلك الرام والإنترنت والـ CPU
        int stoppedCount = 0;
        try {
            List<ApplicationInfo> installed = pm.getInstalledApplications(0);
            if (installed != null) {
                for (int i = 0; i < installed.size(); i++) {
                    ApplicationInfo app = installed.get(i);
                    if (app == null || app.packageName == null) continue;
                    String pkg = app.packageName;
                    boolean isSystem = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    if (!isSystem &&
                        !pkg.equals(context.getPackageName()) &&
                        !pkg.contains("shizuku") &&
                        !GameScannerEngine.isProtectedGamePackage(context, pkg)) {
                        cmds.append("am force-stop ").append(pkg).append(" 2>/dev/null; ");
                        cmds.append("am set-standby-bucket ").append(pkg).append(" restricted 2>/dev/null; ");
                        stoppedCount++;
                    }
                }
            }
        } catch (Throwable ignored) {}

        // 7. تفريغ الكاش والعمليات الخاملة لتحرير أقصى مساحة من الـ 6GB RAM
        cmds.append("pm trim-caches 4096M 2>/dev/null; ");
        cmds.append("cmd activity kill-all 2>/dev/null; ");

        execShell(cmds.toString());

        // 8. ترجمة كود اللعبة إلى لغة الآلة ARM64 السريعة (Speed Profile AOT) لإنهاء التقطيع
        if (speedCompile && activeGamePkg != null && activeGamePkg.length() > 0) {
            execShell("cmd package compile -m speed-profile -f " + activeGamePkg + " 2>/dev/null");
        }

        // 9. إطلاق الحارس الخلفي المستقل بعد فتح اللعبة (يرفع أولوية PID اللعبة الفعلي ويمنع عودة GOS أثناء اللعب)
        if (activeGamePkg != null && activeGamePkg.length() > 0) {
            startPostLaunchGameWatchdog(activeGamePkg, killGos && gosWatchdog, hitRegBoost, blockHeadsUp, lockBrightness, isolateBg);
        }

        return stoppedCount;
    }

    public static void applyGameKernelOptimization(
        StringBuilder cmds,
        PackageManager pm,
        String gamePkg,
        String effectiveRatio,
        int gpuProfile,
        int maxHz
    ) {
        if (gamePkg == null || gamePkg.length() == 0) return;

        int gameModeNum = (gpuProfile == 2) ? 3 : 2; // 2 = Performance, 3 = Battery/Thermal Cooling
        int targetFps = (gpuProfile == 2) ? 60 : maxHz;

        if ("1.0".equals(effectiveRatio)) {
            cmds.append("cmd game set --mode ").append(gameModeNum)
                .append(" --downscale disable --fps ").append(targetFps).append(" ")
                .append(gamePkg).append(" 2>/dev/null || ")
                .append("cmd game set --mode ").append(gameModeNum)
                .append(" --downscale disable ").append(gamePkg).append(" 2>/dev/null; ");
        } else {
            cmds.append("cmd game set --mode ").append(gameModeNum)
                .append(" --downscale ").append(effectiveRatio)
                .append(" --fps ").append(targetFps).append(" ")
                .append(gamePkg).append(" 2>/dev/null || ")
                .append("cmd game set --mode ").append(gameModeNum)
                .append(" --downscale ").append(effectiveRatio).append(" ")
                .append(gamePkg).append(" 2>/dev/null; ");
        }

        cmds.append("cmd deviceidle whitelist +").append(gamePkg).append(" 2>/dev/null; ");
        cmds.append("am set-standby-bucket ").append(gamePkg).append(" active 2>/dev/null; ");
        cmds.append("cmd appops set ").append(gamePkg).append(" RUN_IN_BACKGROUND allow 2>/dev/null; ");
        cmds.append("cmd appops set ").append(gamePkg).append(" RUN_ANY_IN_BACKGROUND allow 2>/dev/null; ");

        try {
            ApplicationInfo ai = pm.getApplicationInfo(gamePkg, 0);
            if (ai != null && ai.uid > 0) {
                // استثناء اللعبة من جدار عزل الخلفية لتأخذ 100% من سرعة الراوتر والـ 4G
                cmds.append("cmd netpolicy add restrict-background-whitelist ").append(ai.uid).append(" 2>/dev/null; ");
                cmds.append("cmd netpolicy add app-idle-whitelist ").append(ai.uid).append(" 2>/dev/null; ");
            }
        } catch (Throwable ignored) {}
    }

    /**
     * ينتظر إقلاع اللعبة الفعلي (4 ثوانٍ) ثم يربط خيوط اللعبة بكل أنوية المعالج (taskset ff)
     * ويعطيها أعلى أولوية قراءة من الذاكرة (ionice)، ويراقب GOS وبرج الـ 4G طوال مدة اللعب
     * حتى لو أُغلق تطبيق المعزز بالكامل (Zero-RAM Mode)، ثم يستعيد إعدادات النظام تلقائياً عند إغلاق اللعبة!
     */
    public static void startPostLaunchGameWatchdog(
        String gamePkg,
        boolean keepKillingGos,
        boolean keepAlivePing,
        boolean restoreHeadsUpOnExit,
        boolean restoreBrightnessOnExit,
        boolean restoreNetpolicyOnExit
    ) {
        String dnsIp = NetPingHelper.fastestDnsServer;
        if (dnsIp == null || dnsIp.length() == 0) dnsIp = "1.1.1.1";

        StringBuilder wd = new StringBuilder();
        wd.append("export TAG=A07_HYPER_WATCHDOG; ");
        wd.append("sleep 4; ");
        wd.append("for p in $(pidof ").append(gamePkg).append(" 2>/dev/null); do ");
        wd.append("taskset -ap ff $p 2>/dev/null; ");
        wd.append("ionice -c 2 -n 0 -p $p 2>/dev/null; ");
        wd.append("renice -n -10 -p $p 2>/dev/null || renice -n 0 -p $p 2>/dev/null; ");
        wd.append("done; ");

        wd.append(" ticks=0; ");
        wd.append("while [ $ticks -lt 1800 ]; do ");
        wd.append("  gpid=$(pidof ").append(gamePkg).append(" 2>/dev/null); ");
        wd.append("  if [ -z \"$gpid\" ] && [ $ticks -gt 4 ]; then break; fi; ");
        if (keepKillingGos) {
            wd.append("  if [ $((ticks % 10)) -eq 0 ]; then ");
            wd.append("    am force-stop com.samsung.android.game.gos 2>/dev/null; ");
            wd.append("    am force-stop com.samsung.android.sdhms 2>/dev/null; ");
            wd.append("    for p in $gpid; do taskset -ap ff $p 2>/dev/null; done; ");
            wd.append("  fi; ");
        }
        if (keepAlivePing) {
            wd.append("  ping -c 1 -W 1 -s 8 ").append(dnsIp).append(" >/dev/null 2>&1; ");
        }
        wd.append("  ticks=$((ticks + 1)); ");
        wd.append("  sleep 3; ");
        wd.append("done; ");

        // استعادة الإعدادات تلقائياً فور خروج اللاعب من اللعبة حتى لو كان المعزز مغلقاً (Zero-RAM)
        if (restoreHeadsUpOnExit) {
            wd.append("settings put global heads_up_notifications_enabled 1 2>/dev/null; ");
        }
        if (restoreBrightnessOnExit) {
            wd.append("settings put system screen_brightness_mode 1 2>/dev/null; ");
        }
        if (restoreNetpolicyOnExit) {
            wd.append("cmd netpolicy set restrict-background false 2>/dev/null; ");
        }

        execDetachedShellDaemon(wd.toString());
    }

    public static void restoreNormalSystemState(Context context) {
        if (!hasShizukuPermission()) return;
        String activeGamePkg = GameScannerEngine.getActiveGamePackage(context);

        StringBuilder cmds = new StringBuilder();
        cmds.append("pkill -f A07_HYPER_WATCHDOG 2>/dev/null; ");
        cmds.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null; ");
        cmds.append("cmd thermalservice reset 2>/dev/null; ");
        cmds.append("cmd netpolicy set restrict-background false 2>/dev/null; ");
        cmds.append("cmd wifi force-low-latency-mode disabled 2>/dev/null; ");
        cmds.append("cmd wifi force-hi-perf-mode disabled 2>/dev/null; ");
        cmds.append("settings put system peak_refresh_rate 90.0 2>/dev/null; ");
        cmds.append("settings put system min_refresh_rate 60.0 2>/dev/null; ");
        cmds.append("settings put system screen_brightness_mode 1 2>/dev/null; ");
        cmds.append("settings put system pointer_speed 0 2>/dev/null; ");
        cmds.append("settings put global heads_up_notifications_enabled 1 2>/dev/null; ");
        cmds.append("settings put global private_dns_mode opportunistic 2>/dev/null; ");
        cmds.append("settings put global window_animation_scale 1.0 2>/dev/null; ");
        cmds.append("settings put global transition_animation_scale 1.0 2>/dev/null; ");
        cmds.append("settings put global animator_duration_scale 1.0 2>/dev/null; ");

        // إعادة السماح لتطبيقات سامسونج الخدمية (التذكيرات، الروتين، ونقل الملفات USB MTP) بالعمل الطبيعي
        for (int i = 0; i < SAMSUNG_RESTORABLE_USER_PACKAGES.length; i++) {
            String p = SAMSUNG_RESTORABLE_USER_PACKAGES[i];
            cmds.append("cmd appops set ").append(p).append(" RUN_IN_BACKGROUND allow 2>/dev/null; ");
            cmds.append("cmd appops set ").append(p).append(" RUN_ANY_IN_BACKGROUND allow 2>/dev/null; ");
            cmds.append("cmd appops set ").append(p).append(" WAKE_LOCK allow 2>/dev/null; ");
            cmds.append("am set-standby-bucket ").append(p).append(" working_set 2>/dev/null; ");
        }

        if (activeGamePkg != null && activeGamePkg.length() > 0) {
            cmds.append("cmd game reset ").append(activeGamePkg).append(" 2>/dev/null; ");
        }
        execShell(cmds.toString());
    }
}
