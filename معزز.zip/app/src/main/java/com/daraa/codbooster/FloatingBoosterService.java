package com.daraa.codbooster;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingBoosterService extends Service {

    public WindowManager windowManager;
    public LinearLayout miniCapsuleView = null;
    public TextView miniFpsText = null;
    public GradientDrawable miniDotBg = null;

    public View hudCardView = null;
    public CrosshairView crosshairView = null;
    public View touchCurtainView = null;

    public TextView hudPingText = null;
    public TextView hudTempText = null;
    public TextView hudRamText = null;
    public TextView hudFpsText = null;
    public LinearLayout crosshairBar = null;

    public final Handler handler = new Handler(Looper.getMainLooper());
    public boolean isRunning = false;
    public boolean isCrosshairShown = false;
    public boolean isDndEnabled = false;
    public boolean isDiabloModeOn = true;
    public boolean isHitRegOn = true;
    public int currentPing = 52;

    public long windowStartNanos = 0L;
    public long prevFrameNanos = 0L;
    public int renderedFrames = 0;
    public int jankFrames = 0;
    public volatile int currentRealFps = 60;
    public int lastDisplayedFps = -1;

    public int startX = 0;
    public int startY = 0;
    public float touchX = 0f;
    public float touchY = 0f;
    public boolean isTap = false;
    public long lastCurtainClick = 0L;

    public interface TileClickCallback {
        void onTileClicked(GradientDrawable tileBg);
    }

    public final Choreographer.FrameCallback vsyncFpsCallback = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) {
            if (!isRunning) return;
            if (windowStartNanos == 0L) {
                windowStartNanos = frameTimeNanos;
                prevFrameNanos = frameTimeNanos;
            } else {
                long frameDeltaNs = frameTimeNanos - prevFrameNanos;
                prevFrameNanos = frameTimeNanos;
                renderedFrames++;
                if (frameDeltaNs > 24000000L) {
                    int missed = (int) (frameDeltaNs / 16666667L) - 1;
                    if (missed < 1) missed = 1;
                    if (missed > 6) missed = 6;
                    jankFrames += missed;
                }

                long elapsedNs = frameTimeNanos - windowStartNanos;
                if (elapsedNs >= 1000000000L) {
                    // إذا لم تكن قراءة SurfaceFlinger مفعّلة عبر Shizuku، نستخدم قياس VSync الدقيق
                    if (!ShizukuShellEngine.hasShizukuPermission()) {
                        int rawFps = (int) ((renderedFrames * 1000000000L) / elapsedNs);
                        int effectiveFps = rawFps - (jankFrames / 2);
                        if (effectiveFps < 15) effectiveFps = 15;
                        if (effectiveFps > 120) effectiveFps = 120;
                        currentRealFps = effectiveFps;
                    }
                    renderedFrames = 0;
                    jankFrames = 0;
                    windowStartNanos = frameTimeNanos;

                    if (currentRealFps != lastDisplayedFps) {
                        lastDisplayedFps = currentRealFps;
                        updateMiniFpsCapsule();
                        if (hudFpsText != null) {
                            hudFpsText.setText(currentRealFps + " FPS");
                        }
                    }
                }
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            (float) value,
            getResources().getDisplayMetrics()
        );
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        startForegroundNotification();
        NetPingHelper.enableUltraNetworkAndHitRegEngine(this);
        createSleekMiniCapsule();
        Choreographer.getInstance().postFrameCallback(vsyncFpsCallback);
        startTelemetryLoop();
    }

    public void startForegroundNotification() {
        String channelId = "game_booster_v5_hud";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                channelId,
                "معزز الألعاب الخارق V5 - Shizuku & DirectPing",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("تثبيت البنغ الحقيقي + عداد الفريمات الحقيقي من النواة");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, channelId);
        } else {
            builder = new Notification.Builder(this);
        }

        String shizukuStatus = ShizukuShellEngine.hasShizukuPermission()
            ? "وضع Shizuku Diablo UID 2000 نشط 🔥"
            : "درع تثبيت البنغ والأداء نشط ⚡";
        Notification notification = builder
            .setContentTitle("معزز كود موبايل V5 (" + shizukuStatus + ")")
            .setContentText("تثبيت البنغ <60ms + منع الدمج الوهمي + عداد FPS الحقيقي")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(404, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(404, notification);
        }
    }

    public void createSleekMiniCapsule() {
        GradientDrawable capsuleBg = new GradientDrawable();
        capsuleBg.setColor(Color.parseColor("#D90B0F19"));
        capsuleBg.setCornerRadius((float) dp(18));
        capsuleBg.setStroke(dp(1), Color.parseColor("#6600F0FF"));

        final LinearLayout capsule = new LinearLayout(this);
        capsule.setOrientation(LinearLayout.HORIZONTAL);
        capsule.setGravity(Gravity.CENTER_VERTICAL);
        capsule.setBackground(capsuleBg);
        capsule.setLayerType(View.LAYER_TYPE_NONE, null);
        capsule.setPadding(dp(10), dp(4), dp(10), dp(4));

        GradientDrawable dotDrawable = new GradientDrawable();
        dotDrawable.setShape(GradientDrawable.OVAL);
        dotDrawable.setColor(Color.parseColor("#10B981"));
        miniDotBg = dotDrawable;

        View dot = new View(this);
        dot.setBackground(dotDrawable);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(7), dp(7));
        dotLp.setMargins(0, 0, dp(6), 0);
        dot.setLayoutParams(dotLp);

        TextView text = new TextView(this);
        text.setText("60 FPS | " + NetPingHelper.lastTruePing + "ms");
        text.setTextColor(Color.WHITE);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        miniFpsText = text;

        capsule.addView(dot);
        capsule.addView(text);

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(12);
        params.y = dp(42);

        capsule.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                int act = ev.getAction();
                if (act == MotionEvent.ACTION_DOWN) {
                    startX = params.x;
                    startY = params.y;
                    touchX = ev.getRawX();
                    touchY = ev.getRawY();
                    isTap = true;
                    return true;
                } else if (act == MotionEvent.ACTION_MOVE) {
                    int dx = (int) (ev.getRawX() - touchX);
                    int dy = (int) (ev.getRawY() - touchY);
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                        isTap = false;
                    }
                    params.x = startX + dx;
                    params.y = startY + dy;
                    try { windowManager.updateViewLayout(capsule, params); } catch (Throwable ignored) {}
                    return true;
                } else if (act == MotionEvent.ACTION_UP) {
                    if (isTap) {
                        toggleCompactGameTurboHud();
                    }
                    return true;
                }
                return false;
            }
        });

        miniCapsuleView = capsule;
        windowManager.addView(capsule, params);
    }

    public void updateMiniFpsCapsule() {
        if (miniFpsText != null) {
            miniFpsText.setText(currentRealFps + " FPS | " + currentPing + "ms");
        }
        String colorHex;
        if (currentRealFps >= 54 && currentPing < 75) {
            colorHex = "#10B981";
        } else if (currentRealFps >= 40) {
            colorHex = "#F59E0B";
        } else {
            colorHex = "#EF4444";
        }
        if (miniDotBg != null) {
            miniDotBg.setColor(Color.parseColor(colorHex));
        }
    }

    public void toggleCompactGameTurboHud() {
        if (hudCardView != null) {
            closeCompactHud();
            return;
        }

        GradientDrawable mainBg = new GradientDrawable();
        mainBg.setColor(Color.parseColor("#EB0D121F"));
        mainBg.setCornerRadius((float) dp(18));
        mainBg.setStroke(dp(1), Color.parseColor("#4D00F0FF"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(mainBg);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout topHeader = new LinearLayout(this);
        topHeader.setOrientation(LinearLayout.HORIZONTAL);
        topHeader.setGravity(Gravity.CENTER_VERTICAL);
        topHeader.setPadding(0, 0, 0, dp(6));

        String shizukuTag = ShizukuShellEngine.hasShizukuPermission()
            ? "🔥 SHIZUKU DIABLO V5"
            : "⚡ معزز الألعاب الخارق V5";
        TextView titleTv = new TextView(this);
        titleTv.setText(shizukuTag);
        titleTv.setTextColor(Color.parseColor("#00F0FF"));
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        GradientDrawable closeBtnBg = new GradientDrawable();
        closeBtnBg.setColor(Color.parseColor("#26FFFFFF"));
        closeBtnBg.setCornerRadius((float) dp(10));

        TextView closeSmallBtn = new TextView(this);
        closeSmallBtn.setText("✕");
        closeSmallBtn.setTextColor(Color.WHITE);
        closeSmallBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        closeSmallBtn.setGravity(Gravity.CENTER);
        closeSmallBtn.setBackground(closeBtnBg);
        closeSmallBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));
        closeSmallBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeCompactHud();
            }
        });

        topHeader.addView(titleTv);
        topHeader.addView(closeSmallBtn);
        root.addView(topHeader);

        GradientDrawable metricsStripBg = new GradientDrawable();
        metricsStripBg.setColor(Color.parseColor("#182032"));
        metricsStripBg.setCornerRadius((float) dp(10));

        LinearLayout metricsRow = new LinearLayout(this);
        metricsRow.setOrientation(LinearLayout.HORIZONTAL);
        metricsRow.setGravity(Gravity.CENTER);
        metricsRow.setBackground(metricsStripBg);
        metricsRow.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams mLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        mLp.setMargins(0, 0, 0, dp(8));
        metricsRow.setLayoutParams(mLp);

        hudFpsText = createMetricText(currentRealFps + " FPS", "#10B981");
        hudPingText = createMetricText("بنغ " + currentPing + "ms", "#00F0FF");
        hudTempText = createMetricText(getBatteryTempStr(), "#F59E0B");
        hudRamText = createMetricText(getAvailRamShortStr(), "#E2E8F0");

        metricsRow.addView(hudFpsText);
        metricsRow.addView(createDividerDot());
        metricsRow.addView(hudPingText);
        metricsRow.addView(createDividerDot());
        metricsRow.addView(hudTempText);
        metricsRow.addView(createDividerDot());
        metricsRow.addView(hudRamText);
        root.addView(metricsRow);

        LinearLayout gridRow1 = new LinearLayout(this);
        gridRow1.setOrientation(LinearLayout.HORIZONTAL);
        gridRow1.setGravity(Gravity.CENTER);
        gridRow1.setWeightSum(3f);

        LinearLayout gridRow2 = new LinearLayout(this);
        gridRow2.setOrientation(LinearLayout.HORIZONTAL);
        gridRow2.setGravity(Gravity.CENTER);
        gridRow2.setWeightSum(3f);
        LinearLayout.LayoutParams r2Lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        r2Lp.setMargins(0, dp(6), 0, 0);
        gridRow2.setLayoutParams(r2Lp);

        gridRow1.addView(createCompactTile("🔥", "Diablo GPU", isDiabloModeOn, false, new TileClickCallback() {
            @Override
            public void onTileClicked(final GradientDrawable tileBg) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final long freed = NetPingHelper.optimizeGpuAndRam(FloatingBoosterService.this);
                        isDiabloModeOn = true;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                updateTileStyle(tileBg, true);
                                if (hudRamText != null) hudRamText.setText(getAvailRamShortStr());
                                String msg = ShizukuShellEngine.hasShizukuPermission()
                                    ? "🔥 وضع Shizuku Diablo نشط! تم إيقاف GOS وتفريغ الرام (" + getAvailRamShortStr() + ")"
                                    : "⚡ تم تفريغ الخلفية وتنشيط مسار Mali GPU (" + (freed > 0 ? ("+" + freed + "MB") : getAvailRamShortStr()) + ")";
                                Toast.makeText(FloatingBoosterService.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).start();
            }
        }));

        gridRow1.addView(createCompactTile("🎯", "التصويب", isCrosshairShown, false, new TileClickCallback() {
            @Override
            public void onTileClicked(GradientDrawable tileBg) {
                toggleCrosshair();
                updateTileStyle(tileBg, isCrosshairShown);
                if (crosshairBar != null) {
                    crosshairBar.setVisibility(isCrosshairShown ? View.VISIBLE : View.GONE);
                }
            }
        }));

        gridRow1.addView(createCompactTile("💥", "تثبيت البنغ", isHitRegOn, false, new TileClickCallback() {
            @Override
            public void onTileClicked(GradientDrawable tileBg) {
                isHitRegOn = true;
                updateTileStyle(tileBg, true);
                NetPingHelper.enableUltraNetworkAndHitRegEngine(FloatingBoosterService.this);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final int p = NetPingHelper.measureTrueGamePing(0);
                        currentPing = p;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                updateHudPingText();
                                Toast.makeText(
                                    FloatingBoosterService.this,
                                    "⚡ مسار 250ms DSCP EF نشط! البنغ الفعلي: " + p + "ms (التذبذب " + NetPingHelper.lastJitter + "ms)",
                                    Toast.LENGTH_SHORT
                                ).show();
                            }
                        });
                    }
                }).start();
            }
        }));

        gridRow2.addView(createCompactTile("🔒", "قفل اللمس", false, false, new TileClickCallback() {
            @Override
            public void onTileClicked(GradientDrawable tileBg) {
                closeCompactHud();
                showSamsungStyleTouchCurtain();
            }
        }));

        gridRow2.addView(createCompactTile("🔕", "عدم إزعاج", isDndEnabled, false, new TileClickCallback() {
            @Override
            public void onTileClicked(GradientDrawable tileBg) {
                toggleDndMode();
                updateTileStyle(tileBg, isDndEnabled);
            }
        }));

        gridRow2.addView(createCompactTile("🛑", "إيقاف كلي", false, true, new TileClickCallback() {
            @Override
            public void onTileClicked(GradientDrawable tileBg) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ShizukuShellEngine.restoreNormalSystemState();
                    }
                }).start();
                stopService(new Intent(FloatingBoosterService.this, GuardVpnService.class).setAction(GuardVpnService.ACTION_STOP));
                NetPingHelper.disableUltraNetworkEngine();
                stopSelf();
            }
        }));

        root.addView(gridRow1);
        root.addView(gridRow2);

        crosshairBar = new LinearLayout(this);
        crosshairBar.setOrientation(LinearLayout.HORIZONTAL);
        crosshairBar.setGravity(Gravity.CENTER);
        crosshairBar.setVisibility(isCrosshairShown ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams chLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        chLp.setMargins(0, dp(8), 0, 0);
        crosshairBar.setLayoutParams(chLp);

        crosshairBar.addView(createMiniActionChip("الشكل ┼", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (crosshairView != null) crosshairView.nextStyle();
            }
        }));
        crosshairBar.addView(createMiniActionChip("اللون 🎨", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (crosshairView != null) crosshairView.nextColor();
            }
        }));
        crosshairBar.addView(createMiniActionChip("الحجم ➕", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (crosshairView != null) crosshairView.cycleSize();
            }
        }));

        root.addView(crosshairBar);

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            dp(272),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(16);
        params.y = dp(76);

        hudCardView = root;
        windowManager.addView(root, params);
    }

    public void closeCompactHud() {
        if (hudCardView != null) {
            try { windowManager.removeView(hudCardView); } catch (Throwable ignored) {}
            hudCardView = null;
        }
    }

    public TextView createMetricText(String textStr, String colorHex) {
        TextView tv = new TextView(this);
        tv.setText(textStr);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    public TextView createDividerDot() {
        TextView tv = new TextView(this);
        tv.setText(" • ");
        tv.setTextColor(Color.parseColor("#475569"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        return tv;
    }

    public LinearLayout createCompactTile(
        String iconEmoji,
        String label,
        boolean isActive,
        boolean isDanger,
        final TileClickCallback callback
    ) {
        final GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((float) dp(12));
        if (isDanger) {
            bg.setColor(Color.parseColor("#2A1219"));
            bg.setStroke(dp(1), Color.parseColor("#7F1D1D"));
        } else {
            updateTileStyle(bg, isActive);
        }

        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setBackground(bg);
        tile.setPadding(dp(4), dp(8), dp(4), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        tile.setLayoutParams(lp);
        tile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.onTileClicked(bg);
            }
        });

        TextView iconTv = new TextView(this);
        iconTv.setText(iconEmoji);
        iconTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        iconTv.setGravity(Gravity.CENTER);

        TextView labelTv = new TextView(this);
        labelTv.setText(label);
        labelTv.setTextColor(isDanger ? Color.parseColor("#FCA5A5") : Color.parseColor("#E2E8F0"));
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        labelTv.setTypeface(Typeface.DEFAULT_BOLD);
        labelTv.setGravity(Gravity.CENTER);
        labelTv.setPadding(0, dp(2), 0, 0);

        tile.addView(iconTv);
        tile.addView(labelTv);
        return tile;
    }

    public void updateTileStyle(GradientDrawable bg, boolean active) {
        if (active) {
            bg.setColor(Color.parseColor("#172B4D"));
            bg.setStroke(dp(1), Color.parseColor("#00F0FF"));
        } else {
            bg.setColor(Color.parseColor("#181F30"));
            bg.setStroke(dp(1), Color.parseColor("#28324B"));
        }
    }

    public TextView createMiniActionChip(String label, View.OnClickListener onClick) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1E293B"));
        bg.setCornerRadius((float) dp(8));
        bg.setStroke(dp(1), Color.parseColor("#38BDF8"));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(bg);
        tv.setPadding(dp(6), dp(5), dp(6), dp(5));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(onClick);
        return tv;
    }

    public void toggleCrosshair() {
        if (isCrosshairShown) {
            if (crosshairView != null) {
                try { windowManager.removeView(crosshairView); } catch (Throwable ignored) {}
                crosshairView = null;
            }
            isCrosshairShown = false;
            return;
        }

        CrosshairView chView = new CrosshairView(this);
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            dp(48),
            dp(48),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.CENTER;

        crosshairView = chView;
        windowManager.addView(chView, params);
        isCrosshairShown = true;
    }

    public void showSamsungStyleTouchCurtain() {
        if (touchCurtainView != null) return;

        final LinearLayout curtain = new LinearLayout(this);
        curtain.setOrientation(LinearLayout.VERTICAL);
        curtain.setBackgroundColor(Color.parseColor("#FC000000"));
        curtain.setGravity(Gravity.CENTER);
        curtain.setKeepScreenOn(true);

        GradientDrawable lockCardBg = new GradientDrawable();
        lockCardBg.setColor(Color.parseColor("#141A29"));
        lockCardBg.setCornerRadius((float) dp(20));
        lockCardBg.setStroke(dp(1), Color.parseColor("#334155"));

        LinearLayout lockBox = new LinearLayout(this);
        lockBox.setOrientation(LinearLayout.VERTICAL);
        lockBox.setGravity(Gravity.CENTER);
        lockBox.setBackground(lockCardBg);
        lockBox.setPadding(dp(24), dp(20), dp(24), dp(20));

        TextView infoTv = new TextView(this);
        infoTv.setText("🔒 وضع حماية اللمس وتبريد الشاشة\nاللعبة متصلة وتعمل بأمان في الخلفية بأقل حرارة\n\nالمس الشاشة مرتين لفتح القفل");
        infoTv.setTextColor(Color.parseColor("#94A3B8"));
        infoTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        infoTv.setGravity(Gravity.CENTER);

        lockBox.addView(infoTv);
        curtain.addView(lockBox);

        curtain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - lastCurtainClick < 450L) {
                    try { windowManager.removeView(curtain); } catch (Throwable ignored) {}
                    touchCurtainView = null;
                } else {
                    lastCurtainClick = now;
                }
            }
        });

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        );
        params.screenBrightness = 0.01f;

        touchCurtainView = curtain;
        windowManager.addView(curtain, params);
    }

    public void toggleDndMode() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (!nm.isNotificationPolicyAccessGranted()) {
            Toast.makeText(this, "يرجى منح صلاحية عدم الإزعاج لمعزز الألعاب", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }
        isDndEnabled = !isDndEnabled;
        if (isDndEnabled) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            Toast.makeText(this, "🔕 تم حجب الإشعارات والمكالمات المزعجة أثناء اللعب", Toast.LENGTH_SHORT).show();
        } else {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
            Toast.makeText(this, "🔔 تم استعادة الإشعارات", Toast.LENGTH_SHORT).show();
        }
    }

    public String getBatteryTempStr() {
        Intent bm = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int tenths = bm != null ? bm.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 330) : 330;
        return (tenths / 10.0f) + "°C";
    }

    public String getAvailRamShortStr() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) {
            am.getMemoryInfo(mi);
        }
        long availMb = mi.availMem / (1024L * 1024L);
        return "رام " + availMb + "M";
    }

    public void updateHudPingText() {
        String colorHex;
        if (currentPing < 65) {
            colorHex = "#10B981";
        } else if (currentPing < 95) {
            colorHex = "#F59E0B";
        } else {
            colorHex = "#EF4444";
        }
        if (hudPingText != null) {
            hudPingText.setText("بنغ " + currentPing + "ms");
            hudPingText.setTextColor(Color.parseColor(colorHex));
        }
        if (hudFpsText != null) {
            hudFpsText.setText(currentRealFps + " FPS");
        }
        if (hudTempText != null) {
            hudTempText.setText(getBatteryTempStr());
        }
        if (hudRamText != null) {
            hudRamText.setText(getAvailRamShortStr());
        }
        updateMiniFpsCapsule();
    }

    public void startTelemetryLoop() {
        isRunning = true;
        final SharedPreferences prefs = getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        Runnable task = new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // 1. قراءة الفريمات الحقيقية من SurfaceFlinger عبر Shizuku إن توفرت
                        int hwFps = ShizukuShellEngine.readTrueSurfaceFlingerFps();
                        if (hwFps > 0) {
                            currentRealFps = hwFps;
                        }
                        // 2. قياس البنغ الحقيقي الفعلي
                        int region = prefs.getInt("region_index", 0);
                        int p = NetPingHelper.measureTrueGamePing(region);
                        currentPing = p;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                updateHudPingText();
                            }
                        });
                    }
                }).start();
                handler.postDelayed(this, 2500L);
            }
        };
        handler.post(task);
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        Choreographer.getInstance().removeFrameCallback(vsyncFpsCallback);
        handler.removeCallbacksAndMessages(null);
        NetPingHelper.disableUltraNetworkEngine();
        if (miniCapsuleView != null) {
            try { windowManager.removeView(miniCapsuleView); } catch (Throwable ignored) {}
        }
        if (hudCardView != null) {
            try { windowManager.removeView(hudCardView); } catch (Throwable ignored) {}
        }
        if (crosshairView != null) {
            try { windowManager.removeView(crosshairView); } catch (Throwable ignored) {}
        }
        if (touchCurtainView != null) {
            try { windowManager.removeView(touchCurtainView); } catch (Throwable ignored) {}
        }
        super.onDestroy();
    }
}
