package rikka.shizuku;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import moe.shizuku.api.BinderContainer;

public class ShizukuProvider extends ContentProvider {

    public static final String METHOD_SEND_BINDER = "sendBinder";
    public static final String METHOD_GET_BINDER = "getBinder";
    public static final String EXTRA_BINDER = "moe.shizuku.privileged.api.intent.extra.BINDER";

    @Override
    public void attachInfo(Context context, ProviderInfo info) {
        super.attachInfo(context, info);
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (extras == null) {
            return null;
        }
        try {
            extras.setClassLoader(BinderContainer.class.getClassLoader());
        } catch (Throwable ignored) {}

        Bundle reply = new Bundle();
        if (METHOD_SEND_BINDER.equals(method)) {
            handleSendBinder(extras);
        } else if (METHOD_GET_BINDER.equals(method)) {
            IBinder b = Shizuku.getBinder();
            if (b != null && b.pingBinder()) {
                reply.putParcelable(EXTRA_BINDER, new BinderContainer(b));
            }
        }
        return reply;
    }

    public void handleSendBinder(Bundle extras) {
        if (Shizuku.pingBinder()) {
            return;
        }
        IBinder binder = null;
        try {
            BinderContainer container = extras.getParcelable(EXTRA_BINDER);
            if (container != null && container.binder != null) {
                binder = container.binder;
            }
        } catch (Throwable ignored) {}

        if (binder == null) {
            try {
                binder = extras.getBinder(EXTRA_BINDER);
            } catch (Throwable ignored) {}
        }

        if (binder != null) {
            Context ctx = getContext();
            String pkg = ctx != null ? ctx.getPackageName() : "com.daraa.codbooster";
            Shizuku.onBinderReceived(binder, pkg);
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
