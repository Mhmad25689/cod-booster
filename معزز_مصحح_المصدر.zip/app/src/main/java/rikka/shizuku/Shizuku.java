package rikka.shizuku;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import moe.shizuku.api.BinderContainer;

public class Shizuku {

    public interface OnRequestPermissionResultListener {
        void onRequestPermissionResult(int requestCode, int grantResult);
    }

    public static final String DESCRIPTOR_SERVICE = "moe.shizuku.server.IShizukuService";
    public static final String DESCRIPTOR_APP = "moe.shizuku.server.IShizukuApplication";
    public static final String DESCRIPTOR_REMOTE_PROC = "moe.shizuku.server.IRemoteProcess";

    public static volatile IBinder remoteBinder = null;
    public static volatile int serverUid = -1;
    public static volatile int serverApiVersion = 13;
    public static volatile boolean permissionGranted = false;
    public static final List<OnRequestPermissionResultListener> permListeners = new ArrayList<OnRequestPermissionResultListener>();
    public static final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static final Binder shizukuAppStub = new Binder() {
        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code == 2) {
                try {
                    data.enforceInterface(DESCRIPTOR_APP);
                    Bundle bundle = data.readBundle(BinderContainer.class.getClassLoader());
                    if (bundle != null) {
                        serverUid = bundle.getInt("moe.shizuku.privileged.api.intent.extra.SERVER_UID", 2000);
                        serverApiVersion = bundle.getInt("moe.shizuku.privileged.api.intent.extra.SERVER_VERSION", 13);
                        permissionGranted = bundle.getBoolean("moe.shizuku.privileged.api.intent.extra.PERMISSION_GRANTED", false);
                    }
                } catch (Throwable ignored) {}
                return true;
            } else if (code == 3) {
                try {
                    data.enforceInterface(DESCRIPTOR_APP);
                    final int reqCode = data.readInt();
                    Bundle bundle = data.readBundle(BinderContainer.class.getClassLoader());
                    boolean allowed = false;
                    if (bundle != null) {
                        allowed = bundle.getBoolean("moe.shizuku.privileged.api.intent.extra.ALLOWED", false);
                    }
                    permissionGranted = allowed;
                    final int result = allowed ? PackageManager.PERMISSION_GRANTED : PackageManager.PERMISSION_DENIED;
                    notifyPermissionResult(reqCode, result);
                } catch (Throwable ignored) {}
                return true;
            }
            return super.onTransact(code, data, reply, flags);
        }
    };

    public static void recyclePair(Parcel p1, Parcel p2) {
        if (p1 != null) {
            try { p1.recycle(); } catch (Throwable ignored) {}
        }
        if (p2 != null) {
            try { p2.recycle(); } catch (Throwable ignored) {}
        }
    }

    public static void onBinderReceived(IBinder binder, String packageName) {
        try {
            if (binder == null || !binder.pingBinder()) {
                return;
            }
            remoteBinder = binder;
            attachApplicationOnServer(binder, packageName != null ? packageName : "com.daraa.codbooster");
        } catch (Throwable ignored) {}
    }

    public static void attachApplicationOnServer(IBinder binder, String packageName) {
        boolean attached = false;
        Parcel data18 = Parcel.obtain();
        Parcel reply18 = Parcel.obtain();
        try {
            data18.writeInterfaceToken(DESCRIPTOR_SERVICE);
            data18.writeStrongBinder(shizukuAppStub);
            Bundle args = new Bundle();
            args.putString("moe.shizuku.privileged.api.intent.extra.PACKAGE_NAME", packageName);
            args.putInt("moe.shizuku.privileged.api.intent.extra.API_VERSION", 13);
            data18.writeInt(1);
            args.writeToParcel(data18, 0);
            if (binder.transact(18, data18, reply18, 0)) {
                reply18.readException();
                attached = true;
            }
        } catch (Throwable ignored) {}
        recyclePair(data18, reply18);

        if (!attached) {
            Parcel data17 = Parcel.obtain();
            Parcel reply17 = Parcel.obtain();
            try {
                data17.writeInterfaceToken(DESCRIPTOR_SERVICE);
                data17.writeStrongBinder(shizukuAppStub);
                data17.writeString(packageName);
                binder.transact(17, data17, reply17, 0);
                reply17.readException();
            } catch (Throwable ignored) {}
            recyclePair(data17, reply17);
        }
    }

    public static void tryRequestBinderFromProvider(Context context) {
        if (context == null) return;
        if (pingBinder()) return;
        try {
            Uri uri = Uri.parse("content://" + context.getPackageName() + ".shizuku");
            Bundle reply = context.getContentResolver().call(uri, "getBinder", null, new Bundle());
            if (reply != null) {
                reply.setClassLoader(BinderContainer.class.getClassLoader());
                BinderContainer container = reply.getParcelable("moe.shizuku.privileged.api.intent.extra.BINDER");
                if (container != null && container.binder != null && container.binder.pingBinder()) {
                    onBinderReceived(container.binder, context.getPackageName());
                    return;
                }
                IBinder b = reply.getBinder("moe.shizuku.privileged.api.intent.extra.BINDER");
                if (b != null && b.pingBinder()) {
                    onBinderReceived(b, context.getPackageName());
                }
            }
        } catch (Throwable ignored) {}
    }

    public static IBinder getBinder() {
        return remoteBinder;
    }

    public static boolean pingBinder() {
        try {
            IBinder b = remoteBinder;
            return b != null && b.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static int getUid() {
        IBinder b = remoteBinder;
        if (b == null) return -1;
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            if (b.pingBinder()) {
                data.writeInterfaceToken(DESCRIPTOR_SERVICE);
                if (b.transact(4, data, reply, 0)) {
                    reply.readException();
                    serverUid = reply.readInt();
                }
            }
        } catch (Throwable ignored) {}
        recyclePair(data, reply);
        return serverUid;
    }

    public static int checkSelfPermission() {
        IBinder b = remoteBinder;
        if (b == null) {
            return PackageManager.PERMISSION_DENIED;
        }
        if (permissionGranted) {
            return PackageManager.PERMISSION_GRANTED;
        }
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            if (b.pingBinder()) {
                data.writeInterfaceToken(DESCRIPTOR_SERVICE);
                if (b.transact(14, data, reply, 0)) {
                    reply.readException();
                    boolean granted = reply.readInt() != 0;
                    permissionGranted = granted;
                }
            }
        } catch (Throwable ignored) {}
        recyclePair(data, reply);
        return permissionGranted ? PackageManager.PERMISSION_GRANTED : PackageManager.PERMISSION_DENIED;
    }

    public static void requestPermission(final int requestCode) {
        IBinder b = remoteBinder;
        if (b == null) return;
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            if (b.pingBinder()) {
                data.writeInterfaceToken(DESCRIPTOR_SERVICE);
                data.writeInt(requestCode);
                b.transact(15, data, reply, 0);
                reply.readException();
            }
        } catch (Throwable ignored) {}
        recyclePair(data, reply);

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 12; i++) {
                    try { Thread.sleep(600L); } catch (Throwable ignored) {}
                    if (checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        notifyPermissionResult(requestCode, PackageManager.PERMISSION_GRANTED);
                        break;
                    }
                }
            }
        }).start();
    }

    public static void addRequestPermissionResultListener(OnRequestPermissionResultListener listener) {
        try {
            if (listener != null && !permListeners.contains(listener)) {
                permListeners.add(listener);
            }
        } catch (Throwable ignored) {}
    }

    public static void removeRequestPermissionResultListener(OnRequestPermissionResultListener listener) {
        try {
            permListeners.remove(listener);
        } catch (Throwable ignored) {}
    }

    public static void notifyPermissionResult(final int requestCode, final int grantResult) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int i = 0; i < permListeners.size(); i++) {
                        OnRequestPermissionResultListener l = permListeners.get(i);
                        if (l != null) {
                            l.onRequestPermissionResult(requestCode, grantResult);
                        }
                    }
                } catch (Throwable ignored) {}
            }
        });
    }

    public static String execRemoteShell(String command) {
        IBinder b = remoteBinder;
        if (b == null) return "";
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        IBinder procBinder = null;
        try {
            if (b.pingBinder()) {
                data.writeInterfaceToken(DESCRIPTOR_SERVICE);
                data.writeStringArray(new String[]{"sh", "-c", command});
                data.writeStringArray(null);
                data.writeString(null);
                if (b.transact(8, data, reply, 0)) {
                    reply.readException();
                    procBinder = reply.readStrongBinder();
                }
            }
        } catch (Throwable ignored) {}
        recyclePair(data, reply);

        if (procBinder == null) return "";

        StringBuilder output = new StringBuilder();
        Parcel pData = Parcel.obtain();
        Parcel pReply = Parcel.obtain();
        ParcelFileDescriptor stdoutPfd = null;
        try {
            pData.writeInterfaceToken(DESCRIPTOR_REMOTE_PROC);
            if (procBinder.transact(2, pData, pReply, 0)) {
                pReply.readException();
                if (pReply.readInt() != 0 && ParcelFileDescriptor.CREATOR != null) {
                    stdoutPfd = ParcelFileDescriptor.CREATOR.createFromParcel(pReply);
                }
            }
        } catch (Throwable ignored) {}
        recyclePair(pData, pReply);

        if (stdoutPfd != null) {
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new InputStreamReader(new ParcelFileDescriptor.AutoCloseInputStream(stdoutPfd)));
                String line = reader.readLine();
                while (line != null) {
                    output.append(line).append("\n");
                    line = reader.readLine();
                }
            } catch (Throwable ignored) {}
            if (reader != null) {
                try { reader.close(); } catch (Throwable ignored) {}
            }
        }

        Parcel wData = Parcel.obtain();
        Parcel wReply = Parcel.obtain();
        try {
            wData.writeInterfaceToken(DESCRIPTOR_REMOTE_PROC);
            procBinder.transact(4, wData, wReply, 0);
            wReply.readException();
        } catch (Throwable ignored) {}
        recyclePair(wData, wReply);

        Parcel dData = Parcel.obtain();
        Parcel dReply = Parcel.obtain();
        try {
            dData.writeInterfaceToken(DESCRIPTOR_REMOTE_PROC);
            procBinder.transact(6, dData, dReply, 0);
        } catch (Throwable ignored) {}
        recyclePair(dData, dReply);

        return output.toString().trim();
    }
}
