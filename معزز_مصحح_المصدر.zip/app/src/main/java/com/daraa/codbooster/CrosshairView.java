package com.daraa.codbooster;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class CrosshairView extends View {

    public int styleIndex = 0;
    public int colorIndex = 0;
    public float scaleFactor = 1.0f;

    public final int[] colors = new int[]{
        Color.parseColor("#00FF66"),
        Color.parseColor("#00F0FF"),
        Color.parseColor("#FF2A54"),
        Color.parseColor("#FFD600")
    };

    public final Paint strokePaint;
    public final Paint shadowPaint;
    public final Paint fillPaint;

    public CrosshairView(Context context) {
        super(context);
        strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeCap(Paint.Cap.ROUND);

        shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        shadowPaint.setStyle(Paint.Style.STROKE);
        shadowPaint.setColor(Color.parseColor("#AA000000"));
        shadowPaint.setStrokeCap(Paint.Cap.ROUND);

        fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setStyle(Paint.Style.FILL);
    }

    public void nextStyle() {
        styleIndex = (styleIndex + 1) % 4;
        invalidate();
    }

    public void nextColor() {
        colorIndex = (colorIndex + 1) % colors.length;
        invalidate();
    }

    public void cycleSize() {
        if (scaleFactor < 1.0f) {
            scaleFactor = 1.0f;
        } else if (scaleFactor < 1.3f) {
            scaleFactor = 1.35f;
        } else {
            scaleFactor = 0.75f;
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2.0f;
        float cy = getHeight() / 2.0f;
        float density = getResources().getDisplayMetrics().density;
        float s = density * scaleFactor;

        int activeColor = colors[colorIndex % colors.length];
        strokePaint.setColor(activeColor);
        fillPaint.setColor(activeColor);
        strokePaint.setStrokeWidth(2.0f * s);
        shadowPaint.setStrokeWidth(3.6f * s);

        if (styleIndex == 0) {
            float gap = 4.0f * s;
            float len = 11.0f * s;
            canvas.drawLine(cx - len, cy, cx - gap, cy, shadowPaint);
            canvas.drawLine(cx + gap, cy, cx + len, cy, shadowPaint);
            canvas.drawLine(cx, cy - len, cx, cy - gap, shadowPaint);
            canvas.drawLine(cx, cy + gap, cx, cy + len, shadowPaint);

            canvas.drawLine(cx - len, cy, cx - gap, cy, strokePaint);
            canvas.drawLine(cx + gap, cy, cx + len, cy, strokePaint);
            canvas.drawLine(cx, cy - len, cx, cy - gap, strokePaint);
            canvas.drawLine(cx, cy + gap, cx, cy + len, strokePaint);
            canvas.drawCircle(cx, cy, 1.8f * s, fillPaint);
        } else if (styleIndex == 1) {
            canvas.drawCircle(cx, cy, 3.8f * s, shadowPaint);
            canvas.drawCircle(cx, cy, 3.0f * s, fillPaint);
        } else if (styleIndex == 2) {
            float r = 9.0f * s;
            canvas.drawCircle(cx, cy, r, shadowPaint);
            canvas.drawCircle(cx, cy, r, strokePaint);
            canvas.drawCircle(cx, cy, 1.8f * s, fillPaint);
        } else {
            float gap = 3.5f * s;
            float len = 11.0f * s;
            canvas.drawLine(cx - len, cy, cx - gap, cy, shadowPaint);
            canvas.drawLine(cx + gap, cy, cx + len, cy, shadowPaint);
            canvas.drawLine(cx, cy + gap, cx, cy + len, shadowPaint);

            canvas.drawLine(cx - len, cy, cx - gap, cy, strokePaint);
            canvas.drawLine(cx + gap, cy, cx + len, cy, strokePaint);
            canvas.drawLine(cx, cy + gap, cx, cy + len, strokePaint);
            canvas.drawCircle(cx, cy, 1.6f * s, fillPaint);
        }
    }
}
