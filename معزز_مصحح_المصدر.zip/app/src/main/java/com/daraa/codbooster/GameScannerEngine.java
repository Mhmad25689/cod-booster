package com.daraa.codbooster;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.List;

public final class GameScannerEngine {

    public static class GameItem {
        public String packageName;
        public String label;
        public boolean isAutoDetectedGame;

        public GameItem(String packageName, String label, boolean isAutoDetectedGame) {
            this.packageName = packageName;
            this.label = label;
            this.isAutoDetectedGame = isAutoDetectedGame;
        }
    }

    public static final String[] KNOWN_GAME_SIGNATURES = new String[]{
        "callofduty", "codm", "activision",
        "tencent.ig", "pubg", "krafon", "battlegrounds",
        "dts.freefire", "freefire",
        "mobile.legends", "moonton",
        "konami.pesam", "efootball", "pes",
        "ea.gp.fifamobile", "easports", "fifa", "needforspeed",
        "mihoyo", "hoyoverse", "genshin", "honkai",
        "roblox",
        "supercell.brawlstars", "brawlstars",
        "supercell.clashofclans", "clashofclans",
        "supercell.clashroyale", "clashroyale",
        "supercell.hayday",
        "honorofkings", "tmgp.sgame", "levelinfinite",
        "netease", "bloodstrike",
        "farlight84", "miraclegames",
        "arenabreakout", "proximabeta",
        "standoff2", "axlebolt",
        "carxtech", "carx",
        "gameloft", "asphalt",
        "riotgames", "wildrift", "valorant",
        "mojang.minecraftpe", "minecraft",
        "innersloth.spacemafia", "amongus",
        "miniclip", "eightballpool",
        "kiloo.subwaysurf", "sybogames",
        "ludoking", "jawaker", "yalla",
        "dreamleague", "firsttouchgames",
        "criticalops", "madfinger", "shadowgun",
        "epicgames", "fortnite",
        "garena", "rovio", "angrybirds",
        "king.candycrush", "halfbrick", "imangi",
        "playrix", " Outfit7", "talkingtom",
        "rockstargames", "gtasa",
        "chess", "plarium", "igg.android", "lilithgame"
    };

    public static final List<GameItem> cachedGames = new ArrayList<GameItem>();

    public GameScannerEngine() {}

    public static boolean matchesKnownGameSignature(String pkgLower) {
        if (pkgLower == null) return false;
        for (int i = 0; i < KNOWN_GAME_SIGNATURES.length; i++) {
            String kw = KNOWN_GAME_SIGNATURES[i].toLowerCase().trim();
            if (kw.length() > 0 && pkgLower.contains(kw)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isCustomAddedGame(Context context, String pkg) {
        if (context == null || pkg == null) return false;
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        String csv = prefs.getString("custom_games_csv", "");
        if (csv == null || csv.length() == 0) return false;
        String token = "|" + pkg + "|";
        return csv.contains(token);
    }

    public static void addCustomGamePackage(Context context, String pkg) {
        if (context == null || pkg == null || pkg.length() == 0) return;
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        String csv = prefs.getString("custom_games_csv", "");
        if (csv == null) csv = "";
        String token = "|" + pkg + "|";
        if (!csv.contains(token)) {
            csv = csv + token;
            prefs.edit().putString("custom_games_csv", csv).apply();
        }
    }

    public static boolean isApplicationGame(Context context, ApplicationInfo app) {
        if (app == null || app.packageName == null) return false;
        String pkg = app.packageName;
        if (pkg.equals(context.getPackageName()) || pkg.contains("shizuku")) {
            return false;
        }
        if ((app.flags & ApplicationInfo.FLAG_IS_GAME) != 0) {
            return true;
        }
        if (app.category == ApplicationInfo.CATEGORY_GAME) {
            return true;
        }
        if (matchesKnownGameSignature(pkg.toLowerCase())) {
            return true;
        }
        if (isCustomAddedGame(context, pkg)) {
            return true;
        }
        return false;
    }

    public static List<GameItem> scanInstalledGames(Context context) {
        List<GameItem> result = new ArrayList<GameItem>();
        try {
            PackageManager pm = context.getPackageManager();
            List<ApplicationInfo> installed = pm.getInstalledApplications(0);
            if (installed != null) {
                for (int i = 0; i < installed.size(); i++) {
                    ApplicationInfo app = installed.get(i);
                    if (app == null || app.packageName == null) continue;
                    String pkg = app.packageName;
                    if (pkg.equals(context.getPackageName())) continue;

                    boolean isGame = isApplicationGame(context, app);
                    if (isGame) {
                        // Ensure it is launchable or a known game
                        Intent launch = pm.getLaunchIntentForPackage(pkg);
                        if (launch != null || matchesKnownGameSignature(pkg.toLowerCase())) {
                            String label = pkg;
                            try {
                                CharSequence cs = pm.getApplicationLabel(app);
                                if (cs != null && cs.toString().trim().length() > 0) {
                                    label = cs.toString().trim();
                                }
                            } catch (Throwable ignored) {}
                            result.add(new GameItem(pkg, label, true));
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}

        cachedGames.clear();
        for (int i = 0; i < result.size(); i++) {
            cachedGames.add(result.get(i));
        }

        // Auto-select first detected game if current selection is missing
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        String savedPkg = prefs.getString("selected_game_pkg", "");
        boolean savedExists = false;
        for (int i = 0; i < result.size(); i++) {
            if (result.get(i).packageName.equals(savedPkg)) {
                savedExists = true;
                break;
            }
        }
        if (!savedExists && !result.isEmpty()) {
            GameItem first = result.get(0);
            prefs.edit()
                .putString("selected_game_pkg", first.packageName)
                .putString("selected_game_name", first.label)
                .apply();
        }
        return result;
    }

    public static List<GameItem> listLaunchableNonGameApps(Context context) {
        List<GameItem> apps = new ArrayList<GameItem>();
        try {
            PackageManager pm = context.getPackageManager();
            List<ApplicationInfo> installed = pm.getInstalledApplications(0);
            if (installed != null) {
                for (int i = 0; i < installed.size(); i++) {
                    ApplicationInfo app = installed.get(i);
                    if (app == null || app.packageName == null) continue;
                    String pkg = app.packageName;
                    if (pkg.equals(context.getPackageName()) || pkg.contains("shizuku")) continue;
                    boolean isUser = (app.flags & ApplicationInfo.FLAG_SYSTEM) == 0 || (app.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                    if (!isUser) continue;
                    if (isApplicationGame(context, app)) continue;
                    Intent launch = pm.getLaunchIntentForPackage(pkg);
                    if (launch != null) {
                        String label = pkg;
                        try {
                            CharSequence cs = pm.getApplicationLabel(app);
                            if (cs != null && cs.toString().trim().length() > 0) {
                                label = cs.toString().trim();
                            }
                        } catch (Throwable ignored) {}
                        apps.add(new GameItem(pkg, label, false));
                    }
                }
            }
        } catch (Throwable ignored) {}
        return apps;
    }

    public static String getActiveGamePackage(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        String pkg = prefs.getString("selected_game_pkg", "");
        if (pkg != null && pkg.length() > 0) return pkg;
        if (!cachedGames.isEmpty()) {
            return cachedGames.get(0).packageName;
        }
        return "com.activision.callofduty.shooter";
    }

    public static String getActiveGameName(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        String name = prefs.getString("selected_game_name", "");
        if (name != null && name.length() > 0) return name;
        if (!cachedGames.isEmpty()) {
            return cachedGames.get(0).label;
        }
        return "اللعبة المختارة تلقائياً";
    }

    public static void setSelectedGame(Context context, String pkg, String label) {
        SharedPreferences prefs = context.getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE);
        prefs.edit()
            .putString("selected_game_pkg", pkg)
            .putString("selected_game_name", label)
            .apply();
    }

    public static boolean isProtectedGamePackage(Context context, String pkg) {
        if (pkg == null) return false;
        String lower = pkg.toLowerCase();
        if (matchesKnownGameSignature(lower)) return true;
        String active = getActiveGamePackage(context);
        if (pkg.equals(active)) return true;
        for (int i = 0; i < cachedGames.size(); i++) {
            if (pkg.equals(cachedGames.get(i).packageName)) return true;
        }
        return isCustomAddedGame(context, pkg);
    }

    public static Drawable loadGameIcon(Context context, String pkg) {
        try {
            if (pkg != null && pkg.length() > 0) {
                return context.getPackageManager().getApplicationIcon(pkg);
            }
        } catch (Throwable ignored) {}
        try {
            return context.getResources().getDrawable(R.drawable.cod_default_icon);
        } catch (Throwable e) {
            return context.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
        }
    }
}
