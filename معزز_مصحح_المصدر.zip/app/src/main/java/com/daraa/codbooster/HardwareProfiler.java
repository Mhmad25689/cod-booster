package com.daraa.codbooster;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;
import java.io.BufferedReader;
import java.io.FileReader;

public final class HardwareProfiler {

    public static final int OEM_UNIVERSAL = 0;
    public static final int OEM_SAMSUNG = 1;
    public static final int OEM_REALME_OPPO = 2;
    public static final int OEM_XIAOMI = 3;

    public HardwareProfiler() {}

    public static int detectOemFamily() {
        String m = getSafeStr(Build.MANUFACTURER).toLowerCase();
        String b = getSafeStr(Build.BRAND).toLowerCase();
        String combined = m + " " + b;
        if (combined.contains("samsung")) {
            return OEM_SAMSUNG;
        }
        if (combined.contains("realme") || combined.contains("oppo") || combined.contains("oneplus")) {
            return OEM_REALME_OPPO;
        }
        if (combined.contains("xiaomi") || combined.contains("redmi") || combined.contains("poco")) {
            return OEM_XIAOMI;
        }
        return OEM_UNIVERSAL;
    }

    public static String getSafeStr(String s) {
        return s != null ? s.trim() : "";
    }

    public static String getDeviceMarketingName() {
        String brand = getSafeStr(Build.BRAND);
        String model = getSafeStr(Build.MODEL);
        if (model.length() == 0) return "Android Device";
        if (brand.length() > 0 && !model.toLowerCase().startsWith(brand.toLowerCase())) {
            String capBrand = brand.substring(0, 1).toUpperCase() + brand.substring(1);
            return capBrand + " " + model;
        }
        return model;
    }

    public static String getAndroidOsLabel() {
        String rel = getSafeStr(Build.VERSION.RELEASE);
        if (rel.length() == 0) rel = "14+";
        int sdk = Build.VERSION.SDK_INT;
        int oem = detectOemFamily();
        String skin = "AOSP";
        if (oem == OEM_SAMSUNG) {
            skin = sdk >= 35 ? "One UI 7/8" : "One UI";
        } else if (oem == OEM_REALME_OPPO) {
            skin = "Realme UI / ColorOS";
        } else if (oem == OEM_XIAOMI) {
            skin = "HyperOS / MIUI";
        }
        return "Android " + rel + " (API " + sdk + " • " + skin + ")";
    }

    public static String getOemEngineBadge() {
        int oem = detectOemFamily();
        if (oem == OEM_SAMSUNG) {
            return "محرك Samsung One UI (إيقاف GOS & SDHMS + تسريع Mali GPU)";
        } else if (oem == OEM_REALME_OPPO) {
            return "محرك Realme UI / OPlus (إيقاف Athena + قفل شاشة 90Hz/120Hz)";
        } else if (oem == OEM_XIAOMI) {
            return "محرك Xiaomi HyperOS (إيقاف Joyose & PowerKeeper)";
        }
        return "محرك النواة الذكي العالمي (Universal Kernel & SurfaceFlinger Boost)";
    }

    public static String getSocAndAbiSummary() {
        String hw = getSafeStr(Build.HARDWARE);
        String board = getSafeStr(Build.BOARD);
        String abi = "arm64-v8a";
        try {
            if (Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0) {
                abi = Build.SUPPORTED_ABIS[0];
            }
        } catch (Throwable ignored) {}
        int cores = Runtime.getRuntime().availableProcessors();
        int maxFreqMhz = readCpuMaxFreqMhz();
        String freqTag = maxFreqMhz > 0 ? (" @ " + maxFreqMhz + "MHz") : "";
        String chip = hw.length() > 0 ? hw : board;
        if (chip.length() == 0) chip = "Octa-Core SoC";
        return chip + " (" + cores + " أنوية" + freqTag + " • " + abi + ")";
    }

    public static int readCpuMaxFreqMhz() {
        int maxKhz = 0;
        for (int core = 0; core < 8; core++) {
            String p = "/sys/devices/system/cpu/cpu" + core + "/cpufreq/cpuinfo_max_freq";
            String line = readFirstLine(p);
            if (line.length() > 0) {
                try {
                    int khz = Integer.parseInt(line.trim());
                    if (khz > maxKhz) maxKhz = khz;
                } catch (Throwable ignored) {}
            }
        }
        return maxKhz > 0 ? (maxKhz / 1000) : 2000;
    }

    public static int readDisplayRefreshRate(Context context) {
        try {
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                Display d = wm.getDefaultDisplay();
                if (d != null) {
                    int hz = Math.round(d.getRefreshRate());
                    if (hz >= 30 && hz <= 240) return hz;
                }
            }
        } catch (Throwable ignored) {}
        return 60;
    }

    public static long[] getRamStatsMb(Context context) {
        long availMb = 2048L;
        long totalMb = 6144L;
        long threshMb = 512L;
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                availMb = mi.availMem / (1024L * 1024L);
                totalMb = mi.totalMem / (1024L * 1024L);
                threshMb = mi.threshold / (1024L * 1024L);
            }
        } catch (Throwable ignored) {}
        long usedMb = totalMb > availMb ? (totalMb - availMb) : 0L;
        return new long[]{availMb, totalMb, usedMb, threshMb};
    }

    public static String getBatteryTelemetrySummary(Context context) {
        try {
            Intent bm = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bm != null) {
                int tenths = bm.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320);
                int level = bm.getIntExtra(BatteryManager.EXTRA_LEVEL, 80);
                int volt = bm.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 3950);
                float tempC = tenths / 10.0f;
                return tempC + "°C • شحن " + level + "% • " + volt + "mV";
            }
        } catch (Throwable ignored) {}
        return "32.0°C • شحن مستقر";
    }

    public static float getBatteryTempCelsius(Context context) {
        try {
            Intent bm = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bm != null) {
                int tenths = bm.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320);
                return tenths / 10.0f;
            }
        } catch (Throwable ignored) {}
        return 32.0f;
    }

    public static String getKernelVersionShort() {
        String v = readFirstLine("/proc/version");
        if (v.length() > 0) {
            if (v.length() > 58) {
                return v.substring(0, 58) + "...";
            }
            return v;
        }
        return "Linux Android Kernel Perf+";
    }

    public static String readFirstLine(String path) {
        BufferedReader br = null;
        String res = "";
        try {
            br = new BufferedReader(new FileReader(path));
            String line = br.readLine();
            if (line != null) res = line.trim();
        } catch (Throwable ignored) {}
        if (br != null) {
            try { br.close(); } catch (Throwable ignored) {}
        }
        return res;
    }
}
