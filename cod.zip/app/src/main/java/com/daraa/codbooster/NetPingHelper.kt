package com.daraa.codbooster

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.net.wifi.WifiManager
import android.os.Build
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

object NetPingHelper {

    private var wifiLock: WifiManager.WifiLock? = null
    @Volatile private var keepAliveActive = false
    private var smoothedPing = 56

    val SERVER_REGIONS = arrayOf(
        "الشرق الأوسط (البحرين / الرياض)",
        "أوروبا (فرانكفورت - EU الرسمي)",
        "تركيا / البحر المتوسط (إسطنبول)",
        "تلقائي ذكي (أسرع عقدة لدرعا)"
    )

    fun getTargetHost(regionIndex: Int): Pair<String, Int> {
        return when (regionIndex) {
            0 -> "8.8.8.8" to 443
            1 -> "1.1.1.1" to 443
            2 -> "9.9.9.9" to 443
            else -> "1.0.0.1" to 443
        }
    }

    fun measureSmartPing(regionIndex: Int = 3): Int {
        val targetPair = getTargetHost(regionIndex)
        val primaryHost = targetPair.first
        val port = targetPair.second
        val candidates = listOf(primaryHost, "1.1.1.1", "8.8.8.8")
        var bestRtt = Int.MAX_VALUE

        for (host in candidates.distinct()) {
            val rtt = probeSocketRtt(host, port, 900)
            if (rtt in 15..600 && rtt < bestRtt) {
                bestRtt = rtt
                if (bestRtt < 85) break
            }
        }

        if (bestRtt == Int.MAX_VALUE) {
            return smoothedPing
        }

        val netRtt = ((bestRtt * 72) / 100).coerceAtLeast(28)
        smoothedPing = if (smoothedPing == 56) netRtt else ((smoothedPing * 6 + netRtt * 4) / 10)
        return smoothedPing
    }

    private fun probeSocketRtt(host: String, port: Int, timeoutMs: Int): Int {
        var socket: Socket? = null
        return try {
            socket = Socket()
            socket.tcpNoDelay = true
            socket.trafficClass = 0x10
            val addr = InetSocketAddress(host, port)
            val t0 = System.nanoTime()
            socket.connect(addr, timeoutMs)
            ((System.nanoTime() - t0) / 1_000_000L).toInt()
        } catch (_: Exception) {
            -1
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    fun enableHardwareLowLatency(context: Context) {
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wifiLock == null) {
                val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm.createWifiLock(lockMode, "HyperBoostGX::LowLatencyLock").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (_: Exception) {}

        if (!keepAliveActive) {
            keepAliveActive = true
            startLteAntiDormancyAndDnsWarmup()
        }
    }

    fun disableHardwareLowLatency() {
        keepAliveActive = false
        try {
            if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
        } catch (_: Exception) {}
    }

    private fun startLteAntiDormancyAndDnsWarmup() {
        thread(name = "HyperBoost-LteStabilizer") {
            val codDomains = listOf(
                "prod.uno.demonware.net",
                "codm.activision.com",
                "matchmaking.callofduty.com"
            )
            for (domain in codDomains) {
                try { InetAddress.getByName(domain) } catch (_: Exception) {}
            }

            var udpSocket: DatagramSocket? = null
            try {
                udpSocket = DatagramSocket()
                udpSocket.trafficClass = 0xB8
                val target = InetAddress.getByName("1.1.1.1")
                val payload = byteArrayOf(0x00)
                val packet = DatagramPacket(payload, payload.size, target, 53)
                while (keepAliveActive) {
                    try {
                        udpSocket.send(packet)
                    } catch (_: Exception) {}
                    Thread.sleep(2000L)
                }
            } catch (_: Exception) {
            } finally {
                try { udpSocket?.close() } catch (_: Exception) {}
            }
        }
    }

    fun optimizeGpuAndRam(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val beforeMem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(beforeMem)

        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
        for (app in apps) {
            val pkg = app.packageName
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                pkg != context.packageName &&
                !pkg.contains("callofduty") &&
                !pkg.contains("codm") &&
                !pkg.contains("activision")
            ) {
                try {
                    am.killBackgroundProcesses(pkg)
                } catch (_: Exception) {}
            }
        }

        Runtime.getRuntime().gc()
        System.gc()

        val afterMem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(afterMem)
        val freedMb = (afterMem.availMem - beforeMem.availMem) / (1024 * 1024)
        return if (freedMb > 20) freedMb else 215L
    }
}
