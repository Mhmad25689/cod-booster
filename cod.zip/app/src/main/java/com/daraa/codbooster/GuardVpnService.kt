package com.daraa.codbooster

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.VpnService
import android.os.ParcelFileDescriptor

class GuardVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    companion object {
        const val ACTION_START = "com.daraa.codbooster.START_VPN"
        const val ACTION_STOP = "com.daraa.codbooster.STOP_VPN"

        private val NOISY_BG_KEYWORDS = listOf(
            "whatsapp", "facebook", "instagram", "tiktok", "zhiliaoapp",
            "telegram", "snapchat", "youtube", "twitter", "chrome",
            "vending", "browser", "kwai", "likee", "pinterest", "threads",
            "discord", "imo", "viber", "messenger"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        establishSmartFirewall()
        return START_STICKY
    }

    private fun establishSmartFirewall() {
        if (vpnInterface != null) return

        val prefs = getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE)
        val isolateBg = prefs.getBoolean("isolate_bg", true)
        if (!isolateBg) {
            stopSelf()
            return
        }

        val netMode = prefs.getInt("net_mode", 0)
        val optimalMtu = if (netMode == 1) 1452 else 1380

        try {
            val builder = Builder()
                .setSession("HyperBoost_GX_Shield")
                .setMtu(optimalMtu)
                .addAddress("10.215.173.1", 30)
                .addRoute("0.0.0.0", 0)

            val installed = packageManager.getInstalledApplications(0)
            var isolatedCount = 0

            for (app in installed) {
                val pkg = app.packageName.lowercase()
                val isCod = pkg.contains("callofduty") || pkg.contains("codm") || pkg.contains("activision")
                val isOurApp = app.packageName == packageName
                if (isCod || isOurApp) continue

                val isUserApp = (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                val isNoisyApp = NOISY_BG_KEYWORDS.any { pkg.contains(it) }

                if (isUserApp || isNoisyApp) {
                    try {
                        builder.addAllowedApplication(app.packageName)
                        isolatedCount++
                    } catch (_: Exception) {}
                }
            }

            if (isolatedCount > 0) {
                vpnInterface = builder.establish()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopVpn() {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        } finally {
            vpnInterface = null
        }
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
