package com.daraa.codbooster

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.util.TypedValue
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.abs

class FloatingBoosterService : Service() {

    private lateinit var windowManager: WindowManager
    private var miniCapsuleView: LinearLayout? = null
    private var miniPingText: TextView? = null
    private var miniDotView: View? = null

    private var hudCardView: View? = null
    private var crosshairView: CrosshairView? = null
    private var touchCurtainView: View? = null

    private var hudPingText: TextView? = null
    private var hudTempText: TextView? = null
    private var hudRamText: TextView? = null
    private var hudFpsText: TextView? = null
    private var crosshairBar: LinearLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var isCrosshairShown = false
    private var isDndEnabled = false
    private var isGpuTurboOn = true
    private var currentPing = 54

    private var lastFrameTimeNanos = 0L
    private var frameCount = 0
    private var measuredFps = 60
    private var isHudOpen = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isHudOpen) return
            if (lastFrameTimeNanos == 0L) {
                lastFrameTimeNanos = frameTimeNanos
            }
            frameCount++
            val diff = frameTimeNanos - lastFrameTimeNanos
            if (diff >= 1_000_000_000L) {
                measuredFps = ((frameCount * 1_000_000_000L) / diff).toInt().coerceIn(30, 120)
                frameCount = 0
                lastFrameTimeNanos = frameTimeNanos
                hudFpsText?.text = "$measuredFps FPS"
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        NetPingHelper.enableHardwareLowLatency(this)
        createSleekMiniCapsule()
        startTelemetryLoop()
    }

    private fun startForegroundNotification() {
        val channelId = "hyperboost_gx_hud"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "HyperBoost GX Game Turbo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "معزز الألعاب الفائق يعمل بأقل استهلاك رام"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle("HyperBoost GX نشط ⚡")
            .setContentText("وضع الأداء الأقصى وتثبيت البنغ مفعّل")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(202, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(202, notification)
        }
    }

    private fun createSleekMiniCapsule() {
        val capsuleBg = GradientDrawable().apply {
            setColor(Color.parseColor("#D90B0F19"))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#6600F0FF"))
        }

        val capsule = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = capsuleBg
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }

        val dotBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#10B981"))
        }
        val dot = View(this).apply {
            background = dotBg
            layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                setMargins(0, 0, dp(6), 0)
            }
        }
        miniDotView = dot

        val text = TextView(this).apply {
            text = "54ms"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
        }
        miniPingText = text

        capsule.addView(dot)
        capsule.addView(text)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(42)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isTap = false

        capsule.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    isTap = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        isTap = false
                    }
                    params.x = startX + dx
                    params.y = startY + dy
                    try { windowManager.updateViewLayout(capsule, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isTap) {
                        toggleCompactGameTurboHud()
                    }
                    true
                }
                else -> false
            }
        }

        miniCapsuleView = capsule
        windowManager.addView(capsule, params)
    }

    private fun toggleCompactGameTurboHud() {
        if (hudCardView != null) {
            closeCompactHud()
            return
        }

        val mainBg = GradientDrawable().apply {
            setColor(Color.parseColor("#EB0D121F"))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#4D00F0FF"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = mainBg
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(6))
        }

        val titleTv = TextView(this).apply {
            text = "⚡ HYPERBOOST GX"
            setTextColor(Color.parseColor("#00F0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#26FFFFFF"))
            cornerRadius = dp(10).toFloat()
        }
        val closeSmallBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.CENTER
            background = closeBtnBg
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
            setOnClickListener { closeCompactHud() }
        }

        topHeader.addView(titleTv)
        topHeader.addView(closeSmallBtn)
        root.addView(topHeader)

        val metricsStripBg = GradientDrawable().apply {
            setColor(Color.parseColor("#182032"))
            cornerRadius = dp(10).toFloat()
        }
        val metricsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = metricsStripBg
            setPadding(dp(6), dp(6), dp(6), dp(6))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 0, dp(8))
            layoutParams = lp
        }

        hudPingText = createMetricText("${currentPing}ms", "#10B981")
        hudFpsText = createMetricText("${measuredFps} FPS", "#00F0FF")
        hudTempText = createMetricText(getBatteryTempStr(), "#F59E0B")
        hudRamText = createMetricText(getAvailRamShortStr(), "#E2E8F0")

        metricsRow.addView(hudPingText)
        metricsRow.addView(createDividerDot())
        metricsRow.addView(hudFpsText)
        metricsRow.addView(createDividerDot())
        metricsRow.addView(hudTempText)
        metricsRow.addView(createDividerDot())
        metricsRow.addView(hudRamText)
        root.addView(metricsRow)

        val gridRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 3f
        }
        val gridRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 3f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, dp(6), 0, 0)
            layoutParams = lp
        }

        gridRow1.addView(createCompactTile("🚀", "تسريع GPU", isGpuTurboOn, false) { tileBg ->
            val freed = NetPingHelper.optimizeGpuAndRam(this)
            isGpuTurboOn = true
            updateTileStyle(tileBg, true)
            hudRamText?.text = getAvailRamShortStr()
            Toast.makeText(this, "⚡ تم تحرير $freed MB وتفريغ مسار Mali GPU", Toast.LENGTH_SHORT).show()
        })

        gridRow1.addView(createCompactTile("🎯", "التصويب", isCrosshairShown, false) { tileBg ->
            toggleCrosshair()
            updateTileStyle(tileBg, isCrosshairShown)
            crosshairBar?.visibility = if (isCrosshairShown) View.VISIBLE else View.GONE
        })

        gridRow1.addView(createCompactTile("📡", "تثبيت البنغ", true, false) { _ ->
            NetPingHelper.enableHardwareLowLatency(this)
            thread {
                val p = NetPingHelper.measureSmartPing(3)
                currentPing = p
                handler.post {
                    updatePingVisuals()
                    Toast.makeText(this, "🌐 تم تنشيط مسار الشبكة! البنغ الآن: ${p}ms", Toast.LENGTH_SHORT).show()
                }
            }
        })

        gridRow2.addView(createCompactTile("🔒", "قفل اللمس", false, false) { _ ->
            closeCompactHud()
            showSamsungStyleTouchCurtain()
        })

        gridRow2.addView(createCompactTile("🔕", "عدم إزعاج", isDndEnabled, false) { tileBg ->
            toggleDndMode()
            updateTileStyle(tileBg, isDndEnabled)
        })

        gridRow2.addView(createCompactTile("🛑", "إيقاف كلي", false, true) { _ ->
            stopService(Intent(this, GuardVpnService::class.java).setAction(GuardVpnService.ACTION_STOP))
            NetPingHelper.disableHardwareLowLatency()
            stopSelf()
        })

        root.addView(gridRow1)
        root.addView(gridRow2)

        crosshairBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = if (isCrosshairShown) View.VISIBLE else View.GONE
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, dp(8), 0, 0)
            layoutParams = lp
        }

        crosshairBar?.addView(createMiniActionChip("تغيير الشكل ┼") {
            crosshairView?.nextStyle()
        })
        crosshairBar?.addView(createMiniActionChip("تغيير اللون 🎨") {
            crosshairView?.nextColor()
        })
        crosshairBar?.addView(createMiniActionChip("الحجم ➕") {
            crosshairView?.cycleSize()
        })

        root.addView(crosshairBar)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            dp(268),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(76)
        }

        hudCardView = root
        isHudOpen = true
        lastFrameTimeNanos = 0L
        frameCount = 0
        Choreographer.getInstance().postFrameCallback(frameCallback)
        windowManager.addView(root, params)
    }

    private fun closeCompactHud() {
        isHudOpen = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        hudCardView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        hudCardView = null
    }

    private fun createMetricText(textStr: String, colorHex: String): TextView {
        return TextView(this).apply {
            text = textStr
            setTextColor(Color.parseColor(colorHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun createDividerDot(): TextView {
        return TextView(this).apply {
            text = " • "
            setTextColor(Color.parseColor("#475569"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        }
    }

    private fun createCompactTile(
        iconEmoji: String,
        label: String,
        isActive: Boolean,
        isDanger: Boolean,
        onClick: (GradientDrawable) -> Unit
    ): LinearLayout {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
        }
        if (isDanger) {
            bg.setColor(Color.parseColor("#2A1219"))
            bg.setStroke(dp(1), Color.parseColor("#7F1D1D"))
        } else {
            updateTileStyle(bg, isActive)
        }

        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(4), dp(8), dp(4), dp(8))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            layoutParams = lp
            setOnClickListener { onClick(bg) }
        }

        val iconTv = TextView(this).apply {
            text = iconEmoji
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
        }
        val labelTv = TextView(this).apply {
            text = label
            setTextColor(if (isDanger) Color.parseColor("#FCA5A5") else Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }

        tile.addView(iconTv)
        tile.addView(labelTv)
        return tile
    }

    private fun updateTileStyle(bg: GradientDrawable, active: Boolean) {
        if (active) {
            bg.setColor(Color.parseColor("#172B4D"))
            bg.setStroke(dp(1), Color.parseColor("#00F0FF"))
        } else {
            bg.setColor(Color.parseColor("#181F30"))
            bg.setStroke(dp(1), Color.parseColor("#28324B"))
        }
    }

    private fun createMiniActionChip(label: String, onClick: () -> Unit): TextView {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#1E293B"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.parseColor("#38BDF8"))
        }
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(6), dp(5), dp(6), dp(5))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun toggleCrosshair() {
        if (isCrosshairShown) {
            crosshairView?.let {
                try { windowManager.removeView(it) } catch (_: Exception) {}
            }
            crosshairView = null
            isCrosshairShown = false
            return
        }

        val chView = CrosshairView(this)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            dp(48),
            dp(48),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        crosshairView = chView
        windowManager.addView(chView, params)
        isCrosshairShown = true
    }

    private fun showSamsungStyleTouchCurtain() {
        if (touchCurtainView != null) return

        val curtain = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FC000000"))
            gravity = Gravity.CENTER
            keepScreenOn = true
        }

        val lockCardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#141A29"))
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), Color.parseColor("#334155"))
        }

        val lockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = lockCardBg
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }

        val infoTv = TextView(this).apply {
            text = "🔒 وضع حماية اللمس وتوفير الطاقة\nاللعبة تعمل بأمان في الخلفية بأقل حرارة\n\nالمس مرتين لفتح القفل"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
        }
        lockBox.addView(infoTv)
        curtain.addView(lockBox)

        var lastClick = 0L
        curtain.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastClick < 450) {
                try { windowManager.removeView(curtain) } catch (_: Exception) {}
                touchCurtainView = null
            } else {
                lastClick = now
            }
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        ).apply {
            screenBrightness = 0.01f
        }

        touchCurtainView = curtain
        windowManager.addView(curtain, params)
    }

    private fun toggleDndMode() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "يرجى تفعيل صلاحية عدم الإزعاج لـ HyperBoost GX", Toast.LENGTH_LONG).show()
            val intent = Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            return
        }
        isDndEnabled = !isDndEnabled
        if (isDndEnabled) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            Toast.makeText(this, "🔕 تم كتم الإشعارات المنبثقة أثناء اللعب", Toast.LENGTH_SHORT).show()
        } else {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            Toast.makeText(this, "🔔 تم استعادة الإشعارات", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getBatteryTempStr(): String {
        val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 330) ?: 330
        return "${tenths / 10.0}°C"
    }

    private fun getAvailRamShortStr(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val availMb = mi.availMem / (1024 * 1024)
        return "رام ${availMb}M"
    }

    private fun updatePingVisuals() {
        val colorHex = when {
            currentPing < 68 -> "#10B981"
            currentPing < 100 -> "#F59E0B"
            else -> "#EF4444"
        }
        miniPingText?.text = "${currentPing}ms"
        (miniDotView?.background as? GradientDrawable)?.setColor(Color.parseColor(colorHex))
        hudPingText?.text = "${currentPing}ms"
        hudPingText?.setTextColor(Color.parseColor(colorHex))
        hudTempText?.text = getBatteryTempStr()
        hudRamText?.text = getAvailRamShortStr()
    }

    private fun startTelemetryLoop() {
        isRunning = true
        val prefs = getSharedPreferences("hyperboost_prefs", Context.MODE_PRIVATE)
        val task = object : Runnable {
            override fun run() {
                if (!isRunning) return
                thread {
                    val region = prefs.getInt("region_index", 0)
                    val p = NetPingHelper.measureSmartPing(region)
                    currentPing = p
                    handler.post {
                        updatePingVisuals()
                    }
                }
                handler.postDelayed(this, 3500L)
            }
        }
        handler.post(task)
    }

    override fun onDestroy() {
        isRunning = false
        isHudOpen = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        handler.removeCallbacksAndMessages(null)
        NetPingHelper.disableHardwareLowLatency()
        miniCapsuleView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        hudCardView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        crosshairView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        touchCurtainView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
